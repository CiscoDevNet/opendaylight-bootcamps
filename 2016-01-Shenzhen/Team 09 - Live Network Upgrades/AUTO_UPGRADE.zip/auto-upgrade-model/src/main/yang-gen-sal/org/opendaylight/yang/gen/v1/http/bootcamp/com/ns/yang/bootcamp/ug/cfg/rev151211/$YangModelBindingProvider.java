package org.opendaylight.yang.gen.v1.http.bootcamp.com.ns.yang.bootcamp.ug.cfg.rev151211;

public final class $YangModelBindingProvider implements org.opendaylight.yangtools.yang.binding.YangModelBindingProvider {

    public org.opendaylight.yangtools.yang.binding.YangModuleInfo getModuleInfo() {
        return $YangModuleInfoImpl.getInstance();
    }
}
