/**
 * @author yongjie.wyj
 * @Email yongjie.wyj@alibaba-inc.com
 */
package com.bootcamp.sdn.isolation.api.service;

public interface IsolationService {

    public void doIsolation(IsolationConfiguration cfg);
}
