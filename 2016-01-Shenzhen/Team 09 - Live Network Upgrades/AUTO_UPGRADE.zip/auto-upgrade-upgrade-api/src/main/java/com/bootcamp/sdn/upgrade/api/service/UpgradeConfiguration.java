/**
 * @author yongjie.wyj
 * @Email yongjie.wyj@alibaba-inc.com
 */
package com.bootcamp.sdn.upgrade.api.service;

public class UpgradeConfiguration {

    private String key;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
    
}
