package cn.edu.sjtu.omnilab.provider;

import java.util.List;
import java.util.concurrent.Future;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.SettableFuture;
import org.opendaylight.controller.md.sal.binding.api.DataBroker;
import org.opendaylight.controller.md.sal.binding.api.WriteTransaction;
import org.opendaylight.controller.md.sal.common.api.data.LogicalDatastoreType;
import org.opendaylight.controller.sal.binding.api.NotificationProviderService;
import org.opendaylight.yang.gen.v1.opendaylight.sample.rev140407.SendStartInput;
import org.opendaylight.yang.gen.v1.opendaylight.sample.rev140407.SendStartInputBuilder;
import org.opendaylight.yang.gen.v1.opendaylight.sample.rev140407.TaskService;
import org.opendaylight.yang.gen.v1.opendaylight.sample.rev140407.SendStartOutput;
import org.opendaylight.yang.gen.v1.opendaylight.sample.rev140407.SendStartOutputBuilder;
import org.opendaylight.yangtools.yang.binding.InstanceIdentifier;
import org.opendaylight.yangtools.yang.common.RpcError.ErrorType;
import org.opendaylight.yangtools.yang.common.RpcResult;
import org.opendaylight.yangtools.yang.common.RpcResultBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This is a generated class based on the user inputs of application name
 * and fields json. This class implements a service created by yang model
 * @author harmansingh
 *
 */

public class TaskProvider implements TaskService, AutoCloseable {

    private static final Logger log = LoggerFactory.getLogger(TaskProvider.class);

    NotificationProviderService notificationProviderService;

    private DataBroker dataService;

    public DataBroker getDataService() {
      return dataService;
    }

    public void setDataService(DataBroker dataService) {
      this.dataService = dataService;
    }

    public TaskProvider() {
    }

    public void addNotification(NotificationProviderService notificationProviderService) {
        log.error("Add notification service!");
        this.notificationProviderService = notificationProviderService;
    }

     /**
     * This is an example to show how yang based RPC can be used to perform an operation.
     * Here this is saving data in data store. This code also gives insight into how we can
     * insert data into data store
     * @param input
     * @return
     */

    @Override
    public Future<RpcResult<SendStartOutput>> sendStart(SendStartInput input) {
        log.error("Recieve rpc");

        RpcResultBuilder<SendStartOutput> rpcResultOutput = null;
        SendStartOutput output = null;
        SendStartOutputBuilder outputBuilder = null;

        if(input == null || input.getCommand() == null) {
            log.error("Exit due to invalid input");
            rpcResultOutput = RpcResultBuilder.<SendStartOutput>failed().withError(ErrorType.APPLICATION, "Invalid input", "Input can't be null");
        } else if (!input.getCommand().equals("start")) {
            log.error("Exit due to invalid command");
            rpcResultOutput = RpcResultBuilder.<SendStartOutput>failed().withError(ErrorType.APPLICATION, "Invalid command", "Command can only be start");
        } else {
            log.error("Correct command. Ready to start receiver");
            Receiver recv = new Receiver(notificationProviderService);
            try {
                log.error("Start waiting!");
                long startTime = System.currentTimeMillis();
                while (System.currentTimeMillis() - startTime < 5000) {}
                recv.setFlag(false);
                log.error("Getting path!");
                outputBuilder = new SendStartOutputBuilder();
                log.error("outputBuiler!!!");
                outputBuilder.setPath(recv.getPath());
                recv.resetPath();
                log.error("Closing listener!");
                recv.close();
            } catch (Exception e){

            }

            if ((output = outputBuilder.build()) != null) {
                rpcResultOutput = RpcResultBuilder.<SendStartOutput>success(output);
                log.error("builder success!!!");
            } else {
                rpcResultOutput = RpcResultBuilder.<SendStartOutput>failed().withError(ErrorType.APPLICATION, "Invalid output value", "Output is null");
            }
        }

        return Futures.immediateFuture(rpcResultOutput.build());


//      // EntryBuilder will be used to build an Entry object
//      // We will store entry object in data store
//      EntryBuilder entryBuilder = new EntryBuilder();
//      entryBuilder.setKey(new EntryKey(new EntryId(input.getEntryId())));
//      List<EntryField> entryFields = input.getEntryField();
//
//      for(EntryField field : entryFields) {
//        String key = field.getKey();
//        String value = field.getValue();
//        if(key == null || value == null) {
//          continue;
//        }
//        switch(key) {
//                    case "title" :
//            entryBuilder.setTitle(value);
//            break;
//                    case "desc" :
//            entryBuilder.setDesc(value);
//            break;
//                  }
//      }
//      final Entry entry = entryBuilder.build();
//      final SettableFuture<RpcResult<Void>> futureResult = SettableFuture.create();
//      addEntry(entry, futureResult);
//      return futureResult;
    }

//    private void addEntry(final Entry entry, final SettableFuture<RpcResult<Void>> futureResult) {
//            // Each entry will be identifiable by a unique key, we have to create that identifier
//            InstanceIdentifier.InstanceIdentifierBuilder<Entry> entryIdBuilder =
//                    InstanceIdentifier.<Task>builder(Task.class)
//                        .child(Entry.class, entry.getKey());
//            InstanceIdentifier<Entry> path = entryIdBuilder.toInstance();
//            // Place entry in data store tree
//            WriteTransaction tx = dataService.newWriteOnlyTransaction();
//            tx.put(LogicalDatastoreType.OPERATIONAL, path, entry, true);
//            Futures.addCallback(tx.submit(), new FutureCallback<Void>() {
//                @Override
//                public void onSuccess(final Void result) {
//                    futureResult.set(RpcResultBuilder.<Void>success().withResult(result).build());
//                }
//
//                @Override
//                public void onFailure(final Throwable t) {
//                    futureResult.set( RpcResultBuilder.<Void> failed()
//                        .withError(RpcError.ErrorType.APPLICATION, t.getMessage() ).build() );
//                }
//            });
//
//        }

    @Override
        public void close() throws Exception {
        }

}