package cn.edu.sjtu.omnilab.provider;

import java.util.ArrayList;
import java.util.List;

import org.opendaylight.controller.sal.binding.api.NotificationProviderService;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeConnectorRef;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.PacketProcessingListener;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.PacketReceived;
import org.opendaylight.yangtools.concepts.Registration;
import org.opendaylight.yangtools.yang.binding.InstanceIdentifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by acrophy on 16/1/22.
 */
public class Receiver implements PacketProcessingListener, AutoCloseable {
    private static final Logger log = LoggerFactory.getLogger(Receiver.class);
    protected Registration listenerRegistration;
    private List<String> path;
    boolean flag;
    int counter;

    public Receiver(NotificationProviderService notificationProviderService) {
        log.error("enter Receiver. Calling constructor");
        listenerRegistration = notificationProviderService.registerNotificationListener(this);
        path = new ArrayList<String>();
        log.error("Listener registration");
        flag = true;
        counter = 2;
    }


    public void onPacketReceived(PacketReceived packetReceived) {
    	if (flag){
    		log.error("enter onPacketReceived");
//    		int etherType = -1;
    		log.error(packetReceived.toString());
//    		if (packetReceived.getPayload() == null) log.error("No PayLoad!!!!!");
    		if (packetReceived != null) {
//    			try {
//    				etherType = extractIpProtocol(packetReceived.getPayload());
//    				log.error("IP protocol: " + etherType);
//    			}
//    			catch (Exception e) {}
//    			if ( etherType == 1) {
    				NodeConnectorRef ncref = packetReceived.getIngress();
    				InstanceIdentifier ii = ncref.getValue();
    				log.error(ii.toString());
    				if (ii.toString().split("openflow:").length >1) {
    					String id = ii.toString().split("openflow:")[1].substring(0, 1);
    					if (!path.contains(id) && path.size() <= 3) path.add(id);
    				}
//    			}
    		}
    	}
    }

    public int extractIpProtocol(byte[] payload) throws Exception {
        return BitBufferHelper.getInt(BitBufferHelper.getBits(payload, 184, 8));
    }

    public String getPath() {
    	String finalPath = "";
    	for (int i = 0; i < path.size(); i++) {
    		finalPath = finalPath + path.get(i) + "->";
        }
    	return finalPath.substring(0, finalPath.length() - 2);
    }

    public void resetPath() {
    	path.clear();
    }

    public void setFlag(boolean flag) {
    	this.flag = flag;
    }

    public boolean getFlag() {return flag;}

    public void close () throws Exception {
        log.error("Closing listener");
        if(listenerRegistration != null) {
            listenerRegistration.close();
        }
    }

}
