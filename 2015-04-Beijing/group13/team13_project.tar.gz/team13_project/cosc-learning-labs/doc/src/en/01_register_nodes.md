Register all network devices with the ODL server.

<<(../../../src/learning_lab/01_register_nodes.py)