List the names of ethernet interfaces for each network device.

<<(../../../src/learning_lab/02_interface_names.py)