Éste es el paso de progresión 1 en el learning lab.
Registre los elementos de la red con el servidor de ODL.

<<(../../../src/learning_lab/01_register_nodes.py)