'''
Created on Apr 22, 2015

@author: vinllen-gs
'''

from Queue import PriorityQueue
from MapNode import mapEdge2Number

'''use the SPFA to calculate the path'''
def calculatePathBetweenTwoNodes(edge, src, dst, n):
    '''input:edge output:path algorithm:spfa'''
    INF = 1 << 30
    dis = [INF] * n
    dis[src] = 0
    father = [-1] * n
    vis = [0] * n
    
    def dis_compare(x, y):
        if dis[x] < dis[y]: return 1
        elif dis[x] == dis[y]: return 0
        else: return -1
        
    q = PriorityQueue(dis_compare)
    q.put(src)
    vis[src] = 1
    while(q.empty() == False):
        top = q.get()
        if top == dst :
            break
        for i in range(len(edge[top])):
            son = edge[top][i]
            #print top, son
            if dis[son] > dis[top] + 1 :
                dis[son] = dis[top] + 1 
                father[son] = top
                if vis[son] == 0 :
                    q.put(son)
                    vis[son] = 1
    
    tmp = dst
    path = []
    while(tmp != -1) :
        path.append(tmp)
        tmp = father[tmp]
    
    return path[::-1]

'''calculate all the path without one edge'''        
def calculatePath(link, src, dst, n):
    shortPath = calculatePathBetweenTwoNodes(getTopo(link, -1, n), src, dst, n)
    mark = [0] * n * n
    #print shortPath
    #print len(shortPath)
    for i in range(1, len(shortPath)) :
        edge = mapEdge2Number(shortPath[i - 1], shortPath[i], n)
        mark[edge] = 1 # mark as import edge which is locate at short path
        
    dict = {}
    dict[0] = shortPath # add the short path
    for i in range(len(link)) :
        tmp = mapEdge2Number(link[i][0], link[i][1], n)
        if(mark[tmp] == 0): # useless edge
            continue
        mark[tmp] = 1
        print i, link[i]
        #add the short path without the given edge
        dict[tmp] = calculatePathBetweenTwoNodes(getTopo(link, i, n), src, dst, n) 
    return dict

'''use the link to build the edge'''
def getTopo(inputLink, index, n): 
    '''input the link between two nodes, return topo list[list]'''
    edge = [[] for i in range(0, n + 1)]
    #print len(edge)
    for i in range(len(inputLink)):
        a = inputLink[i][0]
        b = inputLink[i][1]
        #print a, b
        if a == b or index == i:
            continue
        edge[a].append(b)
        edge[b].append(a)
    return edge
        
       
if __name__ == '__main__':
    src = 0
    dst = 1
    n = 3
    link = []
    link.append((0, 1))
    link.append((1, 2))
    link.append((2, 0))
    dict = calculatePath(link, src, dst, n + 1)
    print dict
     