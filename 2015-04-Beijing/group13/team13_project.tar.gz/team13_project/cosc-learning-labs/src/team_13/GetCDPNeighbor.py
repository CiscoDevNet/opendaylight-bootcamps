#from __future__ import print_function as _print_function
try:
    from urllib import quote_plus
except ImportError:
    from urllib.parse import quote_plus
from basics.http import json_loads, json_dumps
from basics.interface import management_interface
from basics.odl_http import odl_http_get, odl_http_post

_cdp_enable_interface_url_suffix = 'config/opendaylight-inventory:nodes/node/{node-id}/yang-ext:mount/Cisco-IOS-XR-ifmgr-cfg:interface-configurations/'

url_neighbours = 'operational/opendaylight-inventory:nodes/node/{node-id}/yang-ext:mount/Cisco-IOS-XR-cdp-oper:cdp'

_cdp_enable_interface_request_content = '''
{"Cisco-IOS-XR-ifmgr-cfg:interface-configuration":[
{
"active":"act",
"interface-name":"%s",
"Cisco-IOS-XR-cdp-cfg:cdp" : {"enable" : ""}
}]}
'''

link_set = {}
link_set_test = {'xrvr-3': set([('xrvr-3', 'GigabitEthernet0/0/0/1', 'iosxrv-2', 'GigabitEthernet0/0/0/2'), ('xrvr-3', 'GigabitEthernet0/0/0/0', 'iosxrv-1', 'GigabitEthernet0/0/0/2')]), 'xrvr-2': set([('xrvr-2', 'GigabitEthernet0/0/0/2', 'iosxrv-3', 'GigabitEthernet0/0/0/1'), ('xrvr-2', 'GigabitEthernet0/0/0/1', 'iosxrv-1', 'GigabitEthernet0/0/0/1')]), 'xrvr-1': set([('xrvr-1', 'GigabitEthernet0/0/0/1', 'iosxrv-2', 'GigabitEthernet0/0/0/1'), ('xrvr-1', 'GigabitEthernet0/0/0/2', 'iosxrv-3', 'GigabitEthernet0/0/0/0')])}



def getNeighbors(device_name):
    neighbor_set = set()
    response = odl_http_get(url_neighbours.format(**{'node-id': quote_plus(device_name), }),
                            'application/json',
                            expected_status_code=(200, 404)
                            )
    j = json_loads(response.text)
    container = j["cdp"]["nodes"]["node"][0]
    #print(json_dumps(container, indent=2))
    mgmt_name = management_interface(device_name)
    if "neighbors" in container:
        neighbors = container["neighbors"]
    
        if "summaries" in neighbors:
            summary = neighbors["summaries"]["summary"]
            for device_info in summary:
                neighbor_id = device_info["device-id"]
                neighbor_interface = device_info["cdp-neighbor"][0]["port-id"]
                device_interface = device_info["interface-name"]
                if device_interface in mgmt_name:
                    continue
                neighbortuple = (device_name, device_interface.encode('utf8'), neighbor_id.encode('utf8'), neighbor_interface.encode('utf8'))
                #print neighbortuple
                neighbor_set.add(neighbortuple)
            return neighbor_set

def checkLinkChange():
    difference_set = set()
    #print inventory_connected()
    for device_name in inventory_connected():
        new_neighbor_set = getNeighbors(device_name)
        old_neighbor_set = link_set[device_name]
        print "new_neighbor_set:", new_neighbor_set
        print "old_neighbor_set:", old_neighbor_set
        defference_set = old_neighbor_set - new_neighbor_set
        if len(defference_set) != 0:
            print "in check:", difference_set
            return defference_set
    
    return difference_set
    
    
def cdp_enable_interface(device_name, interface_name):
    print('cdp_enable_interface(%s,%s)' % (device_name, interface_name))
    url_suffix = _cdp_enable_interface_url_suffix.format(**{'node-id': quote_plus(device_name), })
    request_content = _cdp_enable_interface_request_content % (interface_name)
    return odl_http_post(url_suffix, 'application/json', request_content)

from basics.interface import interface_names
def cdp_enable_device(device_name):
    mgmt_name = management_interface(device_name)
    for interface_name in interface_names(device_name):
        if interface_name in mgmt_name:
            continue
        cdp_enable_interface(device_name, interface_name)
        
from basics.inventory import inventory_connected
def cdp_enable_network():
    for device_name in inventory_connected():
        cdp_enable_device(device_name)

def demonstrate_cdp():
    #cdp_enable_network()
    for device_name in inventory_connected():
        neighbor = getNeighbors(device_name)
        link_set[device_name] = neighbor
    #print link_set

