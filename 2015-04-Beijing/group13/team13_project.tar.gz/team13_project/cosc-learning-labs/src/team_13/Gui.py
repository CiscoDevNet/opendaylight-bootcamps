'''
Created on Apr 23, 2015

@author: vinllen-gs
'''

#!/bin/python 

import matplotlib.pyplot as plt
import networkx as nx
from MapNode import dictNode2Number
import random

def startGUI(link, n, srcNode, dstNode):
    G=nx.binomial_graph(0, 0.3, directed=False)
    srcServer = n 
    dstServer = n + 1
    for i in range(0, n + 2) :
        G.add_node(i)
    for i in range(len(link)) :
        G.add_edge(link[i][0], link[i][1])
    G.add_edge(srcServer, srcNode)
    G.add_edge(dstNode, dstServer)

    layout = nx.spring_layout(G)
    #plt.figure(1)
    #nx.draw(G, pos=layout, node_color='y')
    
    pr=[1] * 7
    print(pr)
    
    
    plt.figure(random.randint(1, 10000))
    nx.draw(G, pos=layout, node_size=[pr[x] * 1000 for x in range(len(pr))], node_color='m',with_labels=True)
    plt.show()
   

if __name__ == '__main__':
    link = []
    link.append((0, 1))
    link.append((0, 2))
    link.append((2, 1))
    startGUI(link, 3, 0, 2)
