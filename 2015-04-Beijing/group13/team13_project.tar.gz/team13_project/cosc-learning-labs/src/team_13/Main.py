'''
Created on Apr 22, 2015

@author: vinllen-gs
'''

from Routing import calculatePath
from basics import topology
from MapNode import mapNode2Number
from MapNode import dictNode2Number
from MapNode import dictNumber2Node
from MapNode import dictEdgeNumber2Link
from MapNode import mapInterface2Ip
from MapNode import mapEdge2Number
from MapNode import dictNewInterfaceMap
from GetCDPNeighbor import getNeighbors
from GetCDPNeighbor import checkLinkChange
from GetCDPNeighbor import demonstrate_cdp
from Forwarding import ForwardingRules
import time
from basics.routes import static_route_list
from basics.routes import static_route_create
from Forwarding import existRules
from Forwarding import deleteRules
from Gui import startGUI
from threading import Thread
import thread

def Main():  
    '''0. create GUI'''
    #startGUI()
     
    '''1. get the map from name <=> number and the port <=> number'''
    nodes = topology.connected_nodes() #get all the connected nodes
    n = len(nodes) + 1  #number + 1
    mapNode2Number(nodes)  #use dict to map between node <=> number
    #print "nodes:", nodes
    mapInterface2Ip()  #map interface+device to ip
    demonstrate_cdp()  #init cdp
    
    src = "10.0.0.16"  #init src, dst and mask 
    dst = "10.0.0.20"
    netmask = 30
    
    '''2.get the link from the CDP'''
    link = []  #all the edge: u--v, no repeat v--u
    #print dictNode2Number
    vis = [[0 for col in range(n)] for row in range(n)]  #just used as mark
    for i in range(len(nodes)):
        nameLink = getNeighbors(nodes[i]) #return list of (interface_a, device_a, interface_b, device_b) from the cdp
        u = dictNode2Number[nodes[i]]  #get one node id
        #print i, nameLink
        for linktuple in nameLink:
            vv = linktuple[2] #device name
            v = dictNode2Number[vv]  #get another node id
            if vis[u][v] == 1 or vis[v][u] == 1 :  #to avoid repeat edge
                continue
            vis[u][v] = vis[v][u] = 1
            link.append((u, v))  #add the edge in the link
            edgeNumber = mapEdge2Number(u, v, n)  #map the edge to a number
            #node1 = str(linktuple[0]) + str(linktuple[1])
            #node2 = str(linktuple[2]) + str(linktuple[3])
            node1 = str(linktuple[1])
            node2 = str(linktuple[3])
            if node1 > node2 :
                tmp = node1
                node1 = node2
                node2 = tmp
            dictEdgeNumber2Link[edgeNumber] = (node1, node2)  #use dict to map the edge number to link
            
            new_name1 = linktuple[1] + str(u)  #interface + node number
            new_name2 = linktuple[3] + str(v)
            dictNewInterfaceMap[new_name1] = new_name2  #map the opposite edge side
            dictNewInterfaceMap[new_name2] = new_name1
            #print "new_name1,2", new_name1, new_name2
            
    '''
    3.calculate the short path in the Routing, return the dictionary of list of shortpath
    dict[0] is the shortpath
    others are the shortpath without given edge
    we should input the src and node route
    '''
    srcNode = dictNode2Number["iosxrv-1"]
    dstNode = dictNode2Number["iosxrv-2"]
    #print "link:", link
    dictPath = calculatePath(link, srcNode, dstNode, n)  #calculate routing 
    #print "dictPath:", dictPath
    
    '''
    4.Build the topology in GUI with networkx
    '''
    thread.start_new_thread(startGUI, (link, n - 1, srcNode, dstNode))
    
    '''
    5.Forwarding, include following two steps:
        4.1 forwarding the short path
        4.2 if received the link down message from cdp, reforwarding second path
    '''
    ForwardingRules(dictPath[0], src, dst, netmask, n) #forwarding the short path
    while 1 :
        #print "xxx"
        time.sleep(0.5) #check twice for every minute
        edge_set = checkLinkChange() #return changed edge (node_a, interface_a, node_b, interface_b)
        #print edge_set
        for edge in edge_set:
            if edge is not None:
                #print "edge", edge
                u = dictNode2Number[edge[0]]
                v = dictNode2Number[edge[2]]
                #print u, v
                edgeNumber = mapEdge2Number(u, v, n)
                
                print edgeNumber
                if dictPath[edgeNumber] is not None:
                    #print "edge is modify"
                    for k in range(len(nodes)) : #delete old rules with the src and dst
                        if existRules(dictNumber2Node[k], src, netmask):
                            deleteRules(dictNumber2Node[k], src, netmask)
                        if existRules(dictNumber2Node[k], dst, netmask):
                             deleteRules(dictNumber2Node[k], dst, netmask)
                    #print "here!"
                    if((u, v) in link) :
                        link.remove((u, v))
                    if((v, u) in link) :
                        link.remove((v, u))
                    thread.start_new_thread(startGUI, (link, n - 1, srcNode, dstNode))
                    ForwardingRules(dictPath[edgeNumber], src, dst, netmask, n) #forwarding second shortest path
                    return 
    return

if __name__ == '__main__':
    Main()