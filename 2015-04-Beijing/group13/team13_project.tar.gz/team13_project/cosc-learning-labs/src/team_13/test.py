from basics.routes import static_route_list
from basics.routes import static_route_create
from basics.routes import to_ip_network
from basics.routes import static_route_create, inventory_static_route, to_ip_network
from importlib import import_module
static_route_fixture = import_module('learning_lab.04_static_route_fixture')
from basics.routes import static_route_delete
from basics.routes import static_route_exists

'''use to delete flowed rules'''
def deleteRules(devicename, net, netmask):
    interface_network = to_ip_network(net, netmask)
    static_route_delete(devicename, interface_network)
    
def existRules(devicename, net, netmask):
    interface_network = to_ip_network(net, netmask)
    flag = static_route_exists(devicename, interface_network)
    return flag

if existRules('iosxrv-1', '10.0.0.20', 30) == True :
    deleteRules('iosxrv-1', '10.0.0.20', 30)
    print "success"

if existRules('iosxrv-1', '10.0.0.16', 30) == True :
    deleteRules('iosxrv-1', '10.0.0.16', 30)
    print "success"
    
if existRules('iosxrv-2', '10.0.0.16', 30) == True :
    deleteRules('iosxrv-2', '10.0.0.16', 30)
    print "success"
    
if existRules('iosxrv-2', '10.0.0.20', 30) == True :
    deleteRules('iosxrv-2', '10.0.0.20', 30)
    print "success"
        
if existRules('iosxrv-3', '10.0.0.16', 30) == True :
    deleteRules('iosxrv-3', '10.0.0.16', 30)
    print "success"

if existRules('iosxrv-3', '10.0.0.20', 30) == True :
    deleteRules('iosxrv-3', '10.0.0.20', 30)
    print "success"