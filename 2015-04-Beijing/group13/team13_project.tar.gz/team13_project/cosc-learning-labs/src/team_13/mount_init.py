from __future__ import print_function
import pydoc
from basics import topology
import settings
import time

def dismount_device(device_name):
    """Dismount a single device by removing from the NETCONF topology."""
    print('device_dismount(' + device_name, end=')\n')
    topology.dismount(device_name)



def dismount_all_devices():
    print(pydoc.plain(pydoc.render_doc(topology.mount)))
    mounted_list = topology.mounted_nodes()
    if mounted_list:
        for device_name in mounted_list:
            dismount_device(device_name)
    else:
        print('There are no mounted devices to dismount.')

def mount_device(device_name):
    """Mount a single device by inserting in the NETCONF topology."""
    device_config = settings.config['network_device'][device_name]
    print('device_mount(' + device_name, *device_config.values(), sep=', ', end=')\n')
    topology.mount(
        device_name,
        device_config['address'],
        device_config['port'],
        device_config['username'],
        device_config['password'])

def mount_all_devices():
    print(pydoc.plain(pydoc.render_doc(topology.mount)))
    unmounted_list = topology.unmounted_nodes()
    if unmounted_list:
        for device_name in unmounted_list:
            mount_device(device_name)
    else:
        print('There are no (configured) devices unmounted.')


def mount_init():
    dismount_all_devices()
    time.sleep(5)
    mount_all_devices()

#mount_init()