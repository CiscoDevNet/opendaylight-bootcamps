config = {
 'network_device': {'xrvr-1':{
                     'address': '172.16.1.65',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'xrvr-2':{
                     'address': '172.16.1.66',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'xrvr-999':{
                     'address': '172.16.1.999',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'}},
 'odl_server': {'address': '172.16.1.64',
                'port': 8181,
                'password': 'admin',
                'username': 'admin'}}
