config = {
 'network_device': {'iosxrv-1':{
                     'address': '172.16.231.162',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'iosxrv-2':{
                     'address': '172.16.231.160',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'iosxrv-3':{
                     'address': '172.16.231.161',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'}},
 'odl_server': {'address': '127.0.0.1',
                'port': 8181,
                'password': 'admin',
                'username': 'admin'}}
