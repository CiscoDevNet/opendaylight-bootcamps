#!/bin/bash
pylint ../src/basics/*.py
pylint ../src/learning_labs/*.py
pylint ../test/*.py
