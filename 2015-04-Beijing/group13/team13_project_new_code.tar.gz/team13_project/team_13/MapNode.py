'''
Created on Apr 22, 2015

@author: vinllen-gs
'''

#from __future__ import print_function as _print_function
from basics.interface import management_interface
from basics.interface_configuration import interface_address_netmask
from basics.interface_names import interface_names
from basics.inventory import inventory_connected
from basics.render import print_rich

dictNode2Number = {}
dictNumber2Node = {}  
dictEdgeNuber2Net = {}
dictInterface2IP = {}
dictEdgeNumber2Link = {}
dictNewInterfaceMap = {}

'''map the node <=> number'''
def mapNode2Number(nodes):
    '''input: nodes(lists), output: node_number(dist)'''
    for i in range(len(nodes)):
        dictNode2Number[nodes[i]] = i
        dictNumber2Node[i] = nodes[i]
    return

'''map interface+device <=> ip'''
def mapInterface2Ip():
    for device_name in inventory_connected():
        #print device_name
        mgmt_name = management_interface(device_name)
        for interface_name in interface_names(device_name):
            # Choose interface on 'data plane' not 'control plane'.
            if interface_name == mgmt_name:
                continue
            #get the address
            address = interface_address_netmask(device_name, interface_name)

            #map interface+device <=> ip
            dictInterface2IP[str(interface_name) + str(dictNode2Number[device_name])] = address
            
    return

'''map the edge to a number'''
def mapEdge2Number(u, v, n):
    mi = min(u, v)
    mx = max(u, v)
    return mi * n + mx

if __name__ == "__main__":
    print mapInterface2Ip()
