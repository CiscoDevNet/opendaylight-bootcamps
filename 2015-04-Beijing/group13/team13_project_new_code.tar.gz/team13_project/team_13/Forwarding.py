'''
Created on Apr 22, 2015

@author: vinllen-gs
'''

from MapNode import dictNode2Number
from MapNode import dictNumber2Node
from MapNode import mapEdge2Number
from MapNode import dictEdgeNumber2Link
from MapNode import dictNewInterfaceMap #interface + nodes => interface
from MapNode import dictInterface2IP
from basics.routes import static_route_list
from basics.routes import static_route_create
from basics.routes import static_route_delete
from basics.routes import static_route_exists
from basics.routes import to_ip_network

'''trigger the bandwith modify'''
def ForwardingTriggeredByGui() :
    return

def createRules(devicename, net, netmask, nethoop):
    print devicename, net, netmask, nethoop
    interface_network = to_ip_network(net, netmask)
    static_route_create(devicename, interface_network, nethoop)
    
def deleteRules(devicename, net, netmask):
    interface_network = to_ip_network(net, netmask)
    static_route_delete(devicename, interface_network)
    
def existRules(devicename, net, netmask):
    interface_network = to_ip_network(net, netmask)
    flag = static_route_exists(devicename, interface_network)
    return flag
    
def ForwardingRules(path, srcNet, dstNet, netmask, n): #all of the netmask is same
    print "path:", path
    for i in range(1, len(path)) :
        u = path[i - 1]
        v = path[i]
        print "u, v", u, v
        edgeNumber = mapEdge2Number(u, v, n)
        interfaceLink = dictEdgeNumber2Link[edgeNumber]
        node1 = interfaceLink[0]
        node2 = interfaceLink[1]
        #print "interfaceLink", interfaceLink
        new_name1 = node1 + str(u)
        #print new_name
        if dictNewInterfaceMap.has_key(new_name1) == True :                
            otherInterface = dictNewInterfaceMap[new_name1]
            new_name2 = node2 + str(v)
            ip = "0"
            if otherInterface == new_name2: 
                ip = dictInterface2IP[otherInterface]
                print "ip:", ip
                if existRules(dictNumber2Node[u], dstNet, netmask) == True :
                    deleteRules(dictNumber2Node[u], dstNet, netmask)
                createRules(dictNumber2Node[u], dstNet, netmask, ip)
                
                new_name = node2 + str(v)
                otherInterface = dictNewInterfaceMap[new_name]
                ip = dictInterface2IP[otherInterface]
                print "ip:", ip
                if existRules(dictNumber2Node[v], srcNet, netmask) == True :
                    deleteRules(dictNumber2Node[v], srcNet, netmask)
                createRules(dictNumber2Node[v], srcNet, netmask, ip)
            
        else :
            new_name = node1 + str(v)
            otherInterface = dictNewInterfaceMap[new_name]
            ip = dictInterface2IP[otherInterface]
            if existRules(dictNumber2Node[v], srcNet, netmask) == True :
                deleteRules(dictNumber2Node[v], srcNet, netmask)
            createRules(dictNumber2Node[v], srcNet, netmask, ip)
            
            new_name = node2 + str(u)
            otherInterface = dictNewInterfaceMap[new_name]
            ip = dictInterface2IP[otherInterface]
            if existRules(dictNumber2Node[u], dstNet, netmask) == True :
                deleteRules(dictNumber2Node[u], dstNet, netmask)
            createRules(dictNumber2Node[u], dstNet, netmask, ip)
'''            
if __name__ == '__main__':
    path = []
    ForwardingRules(path)
'''