import struct
import socket
def ip2uint(ip):
    return struct.unpack("!I",socket.inet_aton(ip))[0]

def uint2ip(i):
    return socket.inet_ntoa(struct.pack('!I',i))

def GenerateIPwithNetmask(ip, netmask):
    ip_u = ip2uint(ip)
    netmask_u = ip2uint(netmask)
    ipwithnetmask_u = ip_u & netmask_u
    ipwithnetmask = uint2ip(ipwithnetmask_u)
    return ipwithnetmask
def PrefixToNetmask(prefix):
    n = prefix
    i = 31
    netmask_u = 0
    netmask = ''
    while i > 31-n:
        netmask_u = netmask_u + 2 ** i
        i = i - 1
    netmask = uint2ip(netmask_u)
    return netmask
netmask =PrefixToNetmask(24)
ip = GenerateIPwithNetmask('192.168.24.164', netmask)
print ip
