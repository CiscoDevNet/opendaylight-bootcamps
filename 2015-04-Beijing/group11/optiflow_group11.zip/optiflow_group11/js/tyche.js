/* utils */
// check if obj is an empty object, i.e. {}
function isEmptyObject(obj) {
    for (var name in obj) {
        if (obj.hasOwnProperty(name)) {
            return false;
        }
    }
    return true;
}

// construct local datetime string according to str (in UTC)
function toDatetime(str) {
    if (str.slice(-1) != 'Z') str += '.000Z';
    var datetime = new Date(str);
    datetime = new Date(datetime.getTime() + 8 * 3600 * 1000);
    var month = datetime.getUTCMonth() + 1;
    if (month < 10) month = '0' + month;
    var day = datetime.getUTCDate();
    if (day < 10) day = '0' + day;
    var hour = datetime.getUTCHours();
    if (hour < 10) hour = '0' + hour;
    var minute = datetime.getUTCMinutes();
    if (minute < 10) minute = '0' + minute;
    var second = datetime.getUTCSeconds();
    if (second < 10) second = '0' + second;
    str = datetime.getUTCFullYear() + '.' + month + '.' + day;
    str += ' ' + hour + ':' + minute + ':' + second;
    return str;
}

// dump an object for its properties, only for debug
function dump_obj(myObject) {
    var s = "";
    for (var property in myObject) {
        s = s + "\n " + property + ": " + myObject[property];
    }
    alert(s);
}

function min(a, b) {
    if (a < b) return a;
    else return b;
}

function max(a, b) {
    if (a > b) return a;
    else return b;
}

/* end utils */

// define initial objects
timers = {
    taskTimer: null
}
user = {};
initNavigationState = {
    gid: null,
    tid: null,
    pid: null
};
// deep copy of initNavigationState
navigationState = $.extend({}, initNavigationState);

(function () {
    // listen for popstate event (for hash change or back/forward button)
    window.addEventListener('popstate', function (e) {
        if (history.state) {
            if (e.state == null) return;
            var state = e.state;
            navigationState = state;
            var url = state.url;
            setBreadcrumb();
            $("#container").load(url);
        }
    }, false);

    /*$(window).on('beforeunload', function(e) {
		return "离开或刷新本页面可能导致浏览状态信息丢失";
	});*/

    // get user info from current session
    getJSON("user/UserFetchSetting", function (data) {
        var url = location.hash;
        if (data.status == "success") {
            $("#user_menu").html(data.user.name);
            user = data.user;
            $("#logout_menu").show();

            if (user.newUser) {
                loadContent("html/NewUser.html");
            } else if (url.substr(0, 2) == "#!") {
                var href = url.substr(2).split("&");
                for (var i in href) {
                    if (i == 0) continue;
                    var pair = href[i].split("=");
                    navigationState[pair[0]] = pair[1];
                }
                loadContent(href[0], $.extend({}, navigationState));
            } else {
                loadContent("html/GroupList.html");
            }
        } else if (url != "#!html/Login.html") {
            alert(url);
            requireLogin();
        }
    });
})();

function requireLogin() {
    $("#logout_menu").hide();
    $("#user_menu").html('');
    loadContent("html/Login.html");
}

// a simple wrapper of $.getJSON()
function getJSON(url, success) {
    if (!$("#page_dimmer").dimmer("is animating"))
        $("#page_dimmer").dimmer('show');
    return $.getJSON(url, function (data) {
        if (data.status == 'login') requireLogin();
        success(data);
        $("#page_dimmer").dimmer('hide');
    });
}

/* load(url, [newNavigationState]) */
function load(url) {
    if (arguments.length == 1) {
        navigationState = $.extend(navigationState, {
            url: url
        });
        window.history.pushState(navigationState, "TycheJudge", "#!" + url);
    } else if (arguments.length == 2) {
        navigationState = $.extend({}, initNavigationState, arguments[1], {
            url: url
        });
        var url_string = "#!" + url;
        for (var property in arguments[1]) {
            if (property == "url" || arguments[1][property] == null) continue;
            url_string += "&" + property + "=" + arguments[1][property];
        }
        window.history.pushState(navigationState, "TycheJudge", url_string);
    }
    setBreadcrumb(url);
    $("#container").load(url);
}
loadContent = load;

// set top navigation bar (needs improvment or redesign!)
function setBreadcrumb(url) {
    var manage = false;
    //if (url.indexOf('Manage') != -1) manage = true;
    $("#breadcrumb").html('<a class="section" id="home_page"><i class="home icon"></i> Tyche</a>');
    $("#home_page").click(function() {
        loadContent("html/GroupList.html", {});
    });
    var divider = '<div class="divider"><i class="inverted right arrow icon" style="margin:0"></i></div>';
    if ($.isNumeric(navigationState.gid)) {
        $("#breadcrumb").append(divider);
        $("#breadcrumb").append('<a class="section" id="group_page" gid=' + navigationState.gid + '>回到本课程</a>');
        $("#group_page").click(function () {
            var gid = $(this).attr('gid');
            loadContent("html/Group.html", {gid:gid});
        });
    }
    if ($.isNumeric(navigationState.tid) && !manage) {
        $("#breadcrumb").append(divider);
        $("#breadcrumb").append('<a class="section" id="task_page" tid=' + navigationState.tid
                                + ' gid=' + navigationState.gid + '>回到本作业</a>');
        $("#task_page").click(function () {
            var gid = $(this).attr('gid');
            var tid = $(this).attr('tid');
            loadContent("html/Task.html", {gid:gid, tid:tid});
        });
    }
    if ($.isNumeric(navigationState.pid) && !manage) {
        $("#breadcrumb").append(divider);
        if ($.isNumeric(navigationState.tid))
            $("#breadcrumb").append('<a class="section" id="problem_page" pid=' + navigationState.pid
                                + ' gid=' + navigationState.gid + ' tid=' + navigationState.tid + '>回到本题目</a>');
        else
            $("#breadcrumb").append('<a class="section" id="problem_page" pid=' + navigationState.pid
                                + ' gid=' + navigationState.gid + '>回到本题目</a>');            
        $("#problem_page").click(function () {
            var gid = $(this).attr('gid');
            var pid = $(this).attr('pid');
            if ($.isNumeric($(this).attr('tid')))
                loadContent("html/Problem.html", {gid:gid, pid:pid, tid:$(this).attr('tid')});
            else
                loadContent("html/Problem.html", {gid:gid, pid:pid});
        });
    }
}

// convert status number to result string
function resultString(result, score) {
    var str;
    switch (result) {
        case 0:
            str = '<span class="ui result label">等待评测';
            break;
        case 1:
            str = '<span class="ui red result label">正在运行';
            break;
        case 2:
            str = '<span class="ui green result label">评测通过';
            break;
        case 3:
            str = '<span class="ui green result label">部分通过';
            break;
        case 4:
            str = '<span class="ui result label">格式错误';
            break;
        case 5:
            str = '<span class="ui result label">空间超限';
            break;
        case 6:
            str = '<span class="ui result label">时间超限';
            break;
        case 7:
            str = '<span class="ui result label">输出超限';
            break;
        case 8:
            str = '<span class="ui red result label">没有输出';
            break;
        case 9:
            str = '<span class="ui red result label">答案错误';
            break;
        case 10:
            str = '<span class="ui red result label">运行错误';
            break;
        case 11:
            str = '<span class="ui black result label">非法调用';
            break;
        case 12:
            str = '<span class="ui black result label">比对失败';
            break;
        case 13:
            str = '<span class="ui black result label">编译错误';
            break;
        default:
            str = '<span class="ui black result label">系统错误';
    }
    if (result >= 2 && score >= 0) {
        str += ' (<strong>' + score + '</strong>)';
    }
    str += '</span>';
    return str;
}

// build a pagination div
// buildPagination(total count, current page, item per page, class to be added for each button)
function buildPagination(count, page, itemPerPage, btnClass) {
    if (count <= itemPerPage) return '';
    var s = '<div class = "ui segment pagination">';
    var maxPage = Math.floor((count - 1) / itemPerPage) + 1;
    if (Math.abs(1 - page) >= 8)
        s += '<div class="' + btnClass + ' ui tiny button" data-value="' + 1 + '"><<</div> ';
    for (var i = 1; i <= maxPage; i++) {
        if (i == page) {
            s += '<div class="' + btnClass + ' ui tiny green button" data-value="' + i + '">' + i + '</div> ';
        } else if (Math.abs(i - page) < 8) {
            s += '<div class="' + btnClass + ' ui tiny button" data-value="' + i + '">' + i + '</div> ';
        }
    }
    if (Math.abs(maxPage - page) >= 8)
        s += '<div class="' + btnClass + ' ui tiny button" data-value="' + maxPage + '">>></div> ';
    s += '</div>';
    return s;
}
