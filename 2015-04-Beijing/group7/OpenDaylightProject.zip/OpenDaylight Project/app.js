// set up SVG for D3
var ctrltag=false;
var width  = 960,
    height = 500,
    colors = d3.scale.category20();

var svg = d3.select('#slate')
  .append('svg')
  .attr('width', width)
  .attr('height', height);

// set up initial nodes and links
//  - nodes are known by 'id', not by index in array.
//  - reflexive edges are indicated on the node (as a bold black circle).
//  - links are always source < target; edge directions are set by 'left' and 'right'.
var nodes = [
    {id: 0, reflexive: false, vn:'xrv-1'},
    {id: 1, reflexive: false, vn:'xrv-2'},
    {id: 2, reflexive: false, vn:'iosv-3'},
    {id: 3, reflexive: false, vn:'iosv-4'},
    {id: 4, reflexive: false, vn:'iosv-5'},
    {id: 5, reflexive: false, vn:'host-6'},
    {id: 6, reflexive: false, vn:'host-7'}
  ],
  lastNodeId = 5,
  links = [
    {source: nodes[0], target: nodes[2], left: false, right: false, down: false },
    {source: nodes[0], target: nodes[3], left: false, right: false, down: false  },
    {source: nodes[0], target: nodes[4], left: false, right: false, down: false  },
    {source: nodes[1], target: nodes[3], left: false, right: false, down: false  },
    {source: nodes[1], target: nodes[4], left: false, right: false, down: false  },
    {source: nodes[3], target: nodes[5], left: false, right: false, down: false  },
    {source: nodes[2], target: nodes[6], left: false, right: false, down: false  }
  ],
  arrlinks=[],
  topo=[
     [0,  2], 
     [0,  3], 
     [0,  4],
     [1,  3],
     [1,  4],
     [3,  5], 
     [2,  6] 
  ];
var ctopo=topo.slice();
// init D3 force layout
var force = d3.layout.force()
    .nodes(nodes)
    .links(links)
    .size([width, height])
    .linkDistance(150)
    .charge(-600)
    .on('tick', tick)

// define arrow markers for graph links
svg.append('svg:defs').append('svg:marker')
    .attr('id', 'end-arrow')
    .attr('viewBox', '0 -5 10 10')
    .attr('refX', 6)
    .attr('markerWidth', 3)
    .attr('markerHeight', 3)
    .attr('orient', 'auto')
  .append('svg:path')
    .attr('d', 'M0,-5L10,0L0,5')
    .attr('fill', '#000');

svg.append('svg:defs').append('svg:marker')
    .attr('id', 'start-arrow')
    .attr('viewBox', '0 -5 10 10')
    .attr('refX', 4)
    .attr('markerWidth', 3)
    .attr('markerHeight', 3)
    .attr('orient', 'auto')
  .append('svg:path')
    .attr('d', 'M10,-5L0,0L10,5')
    .attr('fill', '#000');

// line displayed when dragging new nodes
var drag_line = svg.append('svg:path')
  .attr('class', 'link dragline hidden')
  .attr('d', 'M0,0L0,0');

// handles to link and node element groups
var path = svg.append('svg:g').selectAll('path'),
    circle = svg.append('svg:g').selectAll('g');

// mouse event vars
var selected_node = null,
    selected_link = null,
    mousedown_link = null,
    mousedown_node = null,
    mouseup_node = null;

function resetMouseVars() {
  mousedown_node = null;
  mouseup_node = null;
  mousedown_link = null;
}

// update force layout (called automatically each iteration)
function tick() {
  // draw directed edges with proper padding from node centers
  path.attr('d', function(d) {
    var deltaX = d.target.x - d.source.x,
        deltaY = d.target.y - d.source.y,
        dist = Math.sqrt(deltaX * deltaX + deltaY * deltaY),
        normX = deltaX / dist,
        normY = deltaY / dist,
        sourcePadding = d.left ? 30 : 24,
        targetPadding = d.right ? 30 : 24,
        sourceX = d.source.x + (sourcePadding * normX),
        sourceY = d.source.y + (sourcePadding * normY),
        targetX = d.target.x - (targetPadding * normX),
        targetY = d.target.y - (targetPadding * normY);
    return 'M' + sourceX + ',' + sourceY + 'L' + targetX + ',' + targetY;
  });

  circle.attr('transform', function(d) {
    return 'translate(' + d.x + ',' + d.y + ')';
  });
}
function scolor(d){
    if(d.down)return 'red';
    if(d.left||d.right)return 'green';
    return 'black';
}
var tag=true;
// update graph (called when needed)
function restart() {
   //if (tag)return;
  // path (link) group

  // add new links

  path = path.data(links);
  // update existing links
  path.attr('stroke',function(d){return scolor(d);}) 
      .classed('selected', function(d) { return d === selected_link; })
    .style('marker-start', function(d) { return d.left ? 'url(#start-arrow)' : ''; })
    .style('marker-end', function(d) { return d.right ? 'url(#end-arrow)' : ''; });

  // add new links
  path.enter().append('svg:path')
     .attr('stroke', function(d){return scolor(d);}) 
    .attr('class', 'link')
    .classed('selected', function(d) { return d === selected_link; })
    .style('marker-start', function(d) { return d.left ? 'url(#start-arrow)' : ''; })
    .style('marker-end', function(d) { return d.right ? 'url(#end-arrow)' : ''; })
    .on('mousedown', function(d) {
      if(d3.event.ctrlKey||ctrltag) return;

      // select link
      mousedown_link = d;
      if(mousedown_link === selected_link) selected_link = null;
      else selected_link = mousedown_link;
      selected_node = null;
      restart();
    });
  // remove old links
  path.exit().remove();


  // circle (node) group
  // NB: the function arg is crucial here! nodes are known by id, not by index!
  circle = circle.data(nodes, function(d) { return d.id; });

  // update existing nodes (reflexive & selected visual states)
  circle.selectAll('circle')
    .style('fill', function(d) { return (d === selected_node) ? d3.rgb(colors(d.id)).brighter().toString() : colors(d.id); })
    .classed('reflexive', function(d) { return d.reflexive; });

  // add new nodes
  var g = circle.enter().append('svg:g');

  g.append('svg:circle')
    .attr('class', 'node')
    .attr('r', 24)
    .style('fill', function(d) { return (d === selected_node) ? d3.rgb(colors(d.id)).brighter().toString() : colors(d.id); })
    .style('stroke', function(d) { return d3.rgb(colors(d.id)).darker().toString(); })
    .classed('reflexive', function(d) { return d.reflexive; })
    .on('mouseover', function(d) {
      if(!mousedown_node || d === mousedown_node) return;
      // enlarge target node
      d3.select(this).attr('transform', 'scale(2.1)');
    })
    .on('mouseout', function(d) {
      if(!mousedown_node || d === mousedown_node) return;
      // unenlarge target node
      d3.select(this).attr('transform', '');
    })
    .on('mousedown', function(d) {
      if(d3.event.ctrlKey||ctrltag) return;

      // select node
      mousedown_node = d;
      if(mousedown_node === selected_node) selected_node = null;
      else selected_node = mousedown_node;
      selected_link = null;

      // reposition drag line
      drag_line
        .style('marker-end', 'url(#end-arrow)')
        .classed('hidden', false)
        .attr('d', 'M' + mousedown_node.x + ',' + mousedown_node.y + 'L' + mousedown_node.x + ',' + mousedown_node.y);

      restart();
    })
    .on('mouseup', function(d) {
      if(!mousedown_node) return;

      // needed by FF
      drag_line
        .classed('hidden', true)
        .style('marker-end', '');

      // check for drag-to-self
      mouseup_node = d;
      if(mouseup_node === mousedown_node) { resetMouseVars(); return; }

      // unenlarge target node
      d3.select(this).attr('transform', '');

      // add link to graph (update if exists)
      // NB: links are strictly source < target; arrows separately specified by booleans
      var source, target, direction;
      if(mousedown_node.id < mouseup_node.id) {
        source = mousedown_node;
        target = mouseup_node;
        direction = 'right';
      } else {
        source = mouseup_node;
        target = mousedown_node;
        direction = 'left';
      }

      var link;
      link = links.filter(function(l) {
        return (l.source === source && l.target === target);
      })[0];

//	alert(direction);
      if(link) {
        link['right'] = false;
	link['left'] = false;
	link[direction]=true;
      } else {
        link = {source: source, target: target, left: false, right: false};
        link[direction] = true;
	var t=true;
	for(var x=0; x<topo.length; x++){
	    if(topo[x][0] === source.id && topo[x][1] === target.id){
	   	t=false;break;
	   }
	}
	if(!t){links.push(link);}
	else{pathload(djk(ctopo,mousedown_node.id,mouseup_node.id,6));restart();}

      }

      // select new link
      selected_link = link;
      selected_node = null;
      restart();
    });

  // show node IDs
  g.append('svg:text')
      .attr('x', 0)
      .attr('y', 4)
      .attr('class', 'id')
      .text(function(d) { return d.vn; })
      .style("font-size","24px")
      .style("font-family","Papyrus, fantasy");

  // remove old nodes
  circle.exit().remove();

  // set the graph in motion
  force.start();
}

function mousedown() {
  // prevent I-bar on drag
  //d3.event.preventDefault();
  
  // because :active only works in WebKit?
  svg.classed('active', true);

  if(d3.event.ctrlKey||ctrltag || mousedown_node || mousedown_link) return;

  // insert new node at point

  restart();
}

function mousemove() {
  if(!mousedown_node) return;

  // update drag line
  drag_line.attr('d', 'M' + mousedown_node.x + ',' + mousedown_node.y + 'L' + d3.mouse(this)[0] + ',' + d3.mouse(this)[1]);

  restart();
}

function mouseup() {
  if(mousedown_node) {
    // hide drag line
    drag_line
      .classed('hidden', true)
      .style('marker-end', '');
  }

  // because :active only works in WebKit?
  svg.classed('active', false);

  // clear mouse event vars
  resetMouseVars();
}

function spliceLinksForNode(node) {
  var toSplice = links.filter(function(l) {
    return (l.source === node || l.target === node);
  });
  toSplice.map(function(l) {
    links.splice(links.indexOf(l), 1);
  });
}

// only respond once per keydown
var lastKeyDown = -1;
function keydown() {
  d3.event.preventDefault();

  if(lastKeyDown !== -1) return;
  lastKeyDown = d3.event.keyCode;

  // ctrl
  if(d3.event.keyCode === 17) {
    circle.call(force.drag);
    svg.classed('ctrl', true);
  }

  if(!selected_node && !selected_link) return;
  switch(d3.event.keyCode) {
    case 8: // backspace
    case 46: // delete
      if(selected_link) {
        // set link direction to both left and right
        selected_link.left = false;
        selected_link.right = false;
      }
      restart();
      break;
    case 76: // L
      if(selected_link) {
        // set link direction to left only
        selected_link.left = true;
        selected_link.right = false;
      }
      restart();
      break;
    case 82: // R
      if(selected_node) {
        // toggle node reflexivity
        selected_node.reflexive = !selected_node.reflexive;
      } else if(selected_link) {
        // set link direction to right only
        selected_link.left = false;
        selected_link.right = true;
      }
      restart();
      break;
  }
}

function keyup() {
  lastKeyDown = -1;

  // ctrl
  if(d3.event.keyCode === 17) {
    circle
      .on('mousedown.drag', null)
      .on('touchstart.drag', null);
    svg.classed('ctrl', false);
  }
}
function pathload(pl){
    for(i=0;i<pl.length-1; i++){
        if(pl[i]>pl[i+1]){ 
             for(j=0; j<links.length; j++){
	     	if(links[j]['source'].id == pl[i+1] && links[j]['target'].id == pl[i]){        
			links[j]['left']=false;
			links[j]['right']=true;}
	     }
	}else
             for( j=0; j<links.length; j++){
	     	if(links[j]['source'].id == pl[i] && links[j]['target'].id == pl[i+1]){
			links[j]['right']=false;
			links[j]['left']=true;}
	 
    	}
    }
}
function next(g,v,x){
     p=[];
	for(var i=0; i<g.length; i++){
    	   if(g[i][0] == v)p.push([g[i][1],x]);
	   else if(g[i][1] == v)p.push([g[i][0],x]);
    }
    return p;
}
function merg(a,b){
	for(i=0;i<b.length;i++){
		tag=true
		for(j=0; j<a.length;j++)
			if(a[j][0]==b[i][0])tag=false;
		if(tag)a.push(b[i]);}
}
function fdvex(list, vex){
	for(i=0;i<list.length;i++)
		if(list[i][0] === vex)return i;
	return -1;
}
function djk(g,s,d,vsize){
    var path=[];
    var inv=[[s,-1]];
    var p=0;
    //console.log(g);
    for(var i=0; i<vsize; i++){
	lth=inv.length;
	while(p<lth){
		cur=inv[p][0];
		tmp=next(g,inv[p][0],p);
		var idx=fdvex(tmp,d);
		if(idx == -1){
			merg(inv,tmp)
		}else{
			path.push(d);
			while((a=inv[p][0])!=s&&a!=-1){
				path.push(inv[p][0]); p=inv[p][1];
			}
			path.push(s);
			//console.log(path);
			return path;
		}
		p++;
       }
    }
    //console.log(path);
    return path;
}
// app starts here
setInterval(function(){
	$.getJSON("query", function(d) {
	   if(d['tag']){
		 ctopo=topo.slice(); 
		 for(i=0;i<links.length;i++){
		// console.log(links[i]['down']);
			links[i]['down']=false;}
		  lk=d['ln'].sort();
		  //console.log(d['ln'])  
		  while(lk.length){
			  t=lk.pop();
			  links[t]['down']=true;
			  ctopo.splice(t,1);
		  pathload(djk(ctopo,topo[t][0],topo[t][1],6));}
		  restart();
	  } 
	  
	});
        },
       	3000);
svg.on('mousedown', mousedown)
  .on('mousemove', mousemove)
  .on('mouseup', mouseup);
restart();
