function next(g,v,x){
     p=[];
	for(var i=0; i<g.length; i++){
    	   if(g[i][0] == v)p.push([g[i][1],x]);
	   else if(g[i][1] == v)p.push([g[i][0],x]);
    }
    return p;
}
function merg(a,b){
	for(i=0;i<b.length;i++){
		tag=true
		for(j=0; j<a.length;j++)
			if(a[j][0]==b[i][0])tag=false;
		if(tag)a.push(b[i]);}
}
function fdvex(list, vex){
	for(i=0;i<list.length;i++)
		if(list[i][0] === vex)return i;
	return -1;
}
function djk(g,s,d,vsize){
    var path=[];
    var inv=[[s,-1]];
    var p=0;
    for(var i=0; i<vsize; i++){
	lth=inv.length;
	while(p<lth){
		cur=inv[p][0];
		tmp=next(g,inv[p][0],p);
		var idx=fdvex(tmp,d);
		if(idx == -1){
			merg(inv,tmp)
		}else{
			path.push(d);
			while((a=inv[p][0])!=s&&a!=-1){
				path.push(inv[p][0]); p=inv[p][1];
			}
			path.push(s);
			return path;
		}
		p++;
       }
    }
    return path;
}
topo=[
     [0,  1], 
     [0,  4], 
     [1,  2],
     [1,  3],
     [2,  3],
     [4,  5] 
  ];
  topo.splice(3,1);
  console.log(djk(topo,2,3,6));
  console.log(djk(topo,4,3,6));
  console.log(djk(topo,5,3,6));
