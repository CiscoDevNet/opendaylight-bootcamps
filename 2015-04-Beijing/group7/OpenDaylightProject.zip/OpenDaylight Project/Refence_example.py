config = {
 'network_device': {'xrvr-1':{
                     'address': '172.16.171.62',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'xrvr-2':{
                     'address': '172.16.171.63',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'xrvr-3':{
                     'address': '172.16.171.64',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'}},
  #'odl_server': {'address': '10.0.2.15',
  'odl_server': {'address': '192.168.255.8',
                'port': 8181,
                'password': 'admin',
                'username': 'admin'}}
