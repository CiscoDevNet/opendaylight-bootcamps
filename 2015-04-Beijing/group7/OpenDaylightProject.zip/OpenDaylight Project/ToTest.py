import sys
import requests
import json

_url = 'http://192.168.255.8:8181/restconf/operational/opendaylight-inventory:nodes/node/xrvr-1/yang-ext:mount/Cisco-IOS-XR-cdp-oper:cdp/nodes/node/0%2F0%2FCPU0/neighbors'
_url_network_topology='http://192.168.255.8:8181/restconf/config/network-topology:network-topology'
response = requests.get(_url, auth = ('admin', 'admin'))
#response1 = requests.get(_url_network_topology, auth = ('admin', 'admin'))
#print response1
#print response1.json()
#print response.json().keys().encode("utf-8")
print 'Response of CDP is,',response,'\n'
for i in range(0, 3):
    print "cdp-neighbor information for ",i,",show them seperatively!!!\n",response.json()['neighbors']["details"]["detail"][i]["cdp-neighbor"][0]["detail"]["network-addresses"]["cdp-addr-entry"],"\n\n"



