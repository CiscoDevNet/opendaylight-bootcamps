import test__init__
import sys
import Network_Aware
import Path_Selection

Time_period = 10

def poll:
    end_time = time.time() + Time_period
    while True:
        remaining_time = end_time - time.time()
        if remaining_time < 0:
            ret = Network_Aware.(XXYY)
            if ret == None:
                do something to let Front Know that nothing happens.
            else:
                do something to let Front Know that something happens.


def route_add:
    read.... somefiles ... FROM front
    static_route_create()
    
