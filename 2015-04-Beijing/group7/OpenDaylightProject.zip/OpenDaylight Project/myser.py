import BaseHTTPServer
import time
import Network_Aware

HOST_NAME = 'example.net' # !!!REMEMBER TO CHANGE THIS!!!
PORT_NUMBER = 8080 # Maybe set this to 9000.
def match(x):
	if(x[0]=='L'):
		s1=x[1]>'5' and 'host-' or( x[1]<'3' and 'xrv-') or 'iosv-'
		s2=x[2]>'5' and 'host-' or x[2]<'3' and 'xrv-' or 'iosv-'
		return 'Node: '+s1+x[1]+' ---> '+'Node: '+s2+x[2]

class MyHandler(BaseHTTPServer.BaseHTTPRequestHandler):
    def do_HEAD(s):
	s.send_response(200)
	if s.path.endswith('js'):
		s.send_header("Content-type", "text/javascript")
	elif s.path.endswith('css'):
		s.send_header("Content-type", "text/css")
	s.end_headers()
    def do_POST(s):
	    MyHandler.do_GET(s)
    def do_GET(s):
        """Respond to a GET request."""
	MyHandler.do_HEAD(s)
        if not s.path.startswith('/installer'):
	   if s.path == '/':
             s.path = '/index.html'
	   try:
	       f=open(s.path[1:],'r');
	       while 1:
		   sf = f.read()
                   if sf=='':
		      break;
                   s.wfile.write(sf)
	       if s.path == '/query':
		   Network_Aware.Network_Aware_Pro();
	   except IOError:
	       print "No this file: "+s.path[1:]
        else:
	    tl=s.path[1:].split('/')
            print 'Start router '+tl[1]+' ....'
	    if tl[1] == 'setup':
		    print 'use static_route_updata(ip,mask,next) setup route'
	    elif tl[1] == 'withdraw':
		    print 'use static_route_updata(ip,mask,next) withdraw route'    
	    for i in tl[3:]:
		  print match(i)

if __name__ == '__main__':
    Network_Aware.Network_Aware_Pro()
    server_class = BaseHTTPServer.HTTPServer
    httpd = server_class(('', PORT_NUMBER), MyHandler)
    print time.asctime(), "Server Starts - %s:%s" % (HOST_NAME, PORT_NUMBER)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    httpd.server_close()
    print time.asctime(), "Server Stops - %s:%s" % (HOST_NAME, PORT_NUMBER)
