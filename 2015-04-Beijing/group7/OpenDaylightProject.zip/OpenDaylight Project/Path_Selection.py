_bgp_url_suffix = 'operational/bgp-rib:bgp-rib/rib/example-bgp-rib/loc-rib/tables/bgp-linkstate:linkstate-address-family/bgp-linkstate:linkstate-subsequent-address-family'

_static_route_url_template = 'config/opendaylight-inventory:nodes/node/%s/yang-ext:mount/Cisco-IOS-XR-ip-static-cfg:router-static/default-vrf/address-family/vrfipv4/vrf-unicast/vrf-prefixes'

_static_route_uni_url_template = _static_route_url_template + '/vrf-prefix/%s'


uril3 = 'http://192.168.255.8:8181/restconf/config/opendaylight-inventory:nodes/node/xrvr-1/yang-ext:mount/Cisco-IOS-XR-ip-static-cfg:router-static/'

def static_route_delete(device_name, destination_network):
    """ Delete the specified 'static route' from the specified device.
    
        No value is returned.
        An exception is raised if the static route does not exist on the device.
    """
    assert isinstance(destination_network, _BaseNetwork)
    url_suffix = _static_route_uni_url_template % (device_name, destination_network)
    response = odl_http_delete(url_suffix, expected_status_code=[200, 500])
    if response.status_code != 200:
        raise Exception(_error_message(response.json()))

_static_route_content_template = \
'''{"Cisco-IOS-XR-ip-static-cfg:vrf-prefix": [
        {
            "prefix": "%s",
            "prefix-length": %s,
            "vrf-route": {
                "vrf-next-hops": {
                    "next-hop-address": [
                        {
                            "next-hop-address": "%s",
                            "description": "%s"
                        }
                    ]
                }
            }
        }
    ]
}'''

def static_route_create(device_name, destination_network, next_hop_address, description=None):
    """ Create the specified 'static route' on the specified network device. """
    if not description:
        description = 'static route to %s via %s' % (destination_network , next_hop_address)
    request_content = _static_route_content_template % (destination_network.network_address, destination_network.prefixlen, next_hop_address, description)
    url_suffix = _static_route_url_template % device_name
    return odl_http_post(url_suffix, contentType='application/json', content=request_content)

