import sys
import json
import threading
from threading import Condition
import time
from odl_http import odl_http_get, odl_http_post, odl_http_put, odl_http_delete
from test__init__ import Topology, config
import requests

#_url1 = 'http://192.168.255.8:8181/restconf/operational/opendaylight-inventory:nodes/node/xrvr-1/yang-ext:mount/Cisco-IOS-XR-cdp-oper:cdp/nodes/node/0%2F0%2FCPU0/neighbors/details'

#_url2 = 'http://192.168.255.8:8181/restconf/operational/opendaylight-inventory:nodes/node/xrvr-2/yang-ext:mount/Cisco-IOS-XR-cdp-oper:cdp/nodes/node/0%2F0%2FCPU0/neighbors/details'

request_url1 = 'operational/opendaylight-inventory:nodes/node/iosxrv-1/yang-ext:mount/Cisco-IOS-XR-cdp-oper:cdp/nodes/node/0%2F0%2FCPU0/neighbors'
request_url2 = 'operational/opendaylight-inventory:nodes/node/iosxrv-2/yang-ext:mount/Cisco-IOS-XR-cdp-oper:cdp/nodes/node/0%2F0%2FCPU0/neighbors'
Num = 7
timeout=5
time_cv = Condition()
default_timeout = 3

#response1 = requests.get(_url1, auth = {'admin', 'admin'})
#response2 = requests.get(_url2, auth = {'admin', 'admin'})

def timed_wait(time_cv, timeout=-1):
    if timeout == -1:
        timeout = default_timeout
    end_time = time.time() + timeout
    while True:
        response1 = odl_http_get(request_url1, 'application/json', expected_status_code=[200, 400])
        response2 = odl_http_get(request_url2, 'application/json', expected_status_code=[200, 400])
        if response1.status_code == 200 and response2.status_code == 200:
            return [response1, response2]
        remaining_time = end_time - time.time()
        time_cv.wait(remaining_time)
        if time.time() > end_time:
            return None

#Poll function here
def Network_Aware_Pro():
    CONFIG = config
    TOPOLOGY = Topology
    for key in TOPOLOGY.keys():
        TOPOLOGY[key] = 0
    
    with time_cv:
        ret =  timed_wait(time_cv, timeout)
    if ret == None:
        print "Test failure!"
        sys.exit(-1)
    for key in CONFIG['network_device'].keys():
        CONFIG['network_device'][key]['aLive'] = 0

    for i in range(0, Num):
        if ret[0].json()['neighbors']["details"]['detail'][i]['interface-name']=='MgmtEth0/0/CPU0/0':
            device_id = ret[0].json()['neighbors']["details"]['detail'][i]['device-id']
            IPv4_addr = ret[0].json()['neighbors']["details"]["detail"][i]["cdp-neighbor"][0]["detail"]["network-addresses"]["cdp-addr-entry"][0]["address"]["ipv4-address"]
            CONFIG["network_device"][device_id]["address"] = IPv4_addr
            CONFIG['network_device'][device_id]['aLive'] = 1
        else:
            if ret[0].json()['neighbors']["details"]['detail'][i]['device-id'] == 'iosv-3':
                TOPOLOGY["L13"] = 1
            if ret[0].json()['neighbors']["details"]['detail'][i]['device-id'] == 'iosv-2':
                TOPOLOGY["L14"] = 1
            if ret[0].json()['neighbors']["details"]['detail'][i]['device-id'] == 'iosv-1':
                TOPOLOGY["L15"] = 1

    for i in range(0, Num-1):
        if ret[1].json()['neighbors']["details"]['detail'][i]['interface-name']=='MgmtEth0/0/CPU0/0':
            True
#            device_id = ret[1].json()['neighbors']["details"]['detail'][i]['device-id']
#            IPv4_addr = ret[1].json()['neighbors']["details"]["detail"][i]["cdp-neighbor"][0]["detail"]["network-addresses"]["cdp-addr-entry"][0]["address"]["ipv4-address"]
#            CONFIG["network_device"][device_id]["address"] = IPv4_addr
        else:
            if ret[1].json()['neighbors']["details"]['detail'][i]['device-id'] == 'iosv-2':
                TOPOLOGY["L24"] = 1
            if ret[1].json()['neighbors']["details"]['detail'][i]['device-id'] == 'iosv-1':
                TOPOLOGY["L25"] = 1
    print 'Topology is:',TOPOLOGY  ,'CONFIG is:',CONFIG
    mapl={'L13':0,'L14':1,'L15':2,'L24':3,'L25':4}
    f=open("last",'r')
    last=f.read();
    f.close();
    f=open("query","w");
    tmp={}
    ls=[]
    tag=1;
    for i in Topology:
        if Topology[i] == 0:
            ls.append(mapl[i])
    ls.sort();
    if ls == last:
        tag=0
    tmp['tag']=tag
    tmp['ln']=ls
    print >>f,tmp
    f.close()
    f=open('last','w')
    print >> f, ls
    f.close()
if __name__ == "__main__":
    Network_Aware_Pro()
