config= {
 'network_device': {'iosxrv-1':{
                     'address': '172.16.171.53',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco',
                     'aLive' : 1},
                    'iosxrv-2':{
                     'address': '172.16.171.51',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco',
                     'aLive' : 1},
                    'iosv-1':{
                     'address': '172.16.171.52',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco',
                     'aLive' : 1},
                    'iosv-2':{
                     'address': '172.16.171.126',
                     'port': 830,
                     'password': 'cisco',
                     'username':'cisco',
                     'aLive' : 1},
                    'iosv-3':{
                     'address': '172.16.171.54',
                     'port': 830,
                     'password':'cisco',
                     'username':'cisco',
                     'aLive' : 1}
                    },
  #'odl_server': {'address': '10.0.2.15',
  'odl_server': {'address': '192.168.255.8',
                'port': 8181,
                'password': 'admin',
                'username': 'admin'},}

Topology= {
    "L13" : 1,
    "L15" : 1,
    "L14" : 1,
    "L25" : 1,
    "L24" : 1}

