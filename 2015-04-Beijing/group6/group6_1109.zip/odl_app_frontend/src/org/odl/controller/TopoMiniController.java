package org.odl.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.odl.service.TopoMiniService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value= "topoMiniController")
public class TopoMiniController {
	
	@Resource(name = "topoMiniService")
	private TopoMiniService topoService;
	
    @RequestMapping(value = "topoMini")
    public ModelAndView topoMini(){
    	String topo = topoService.getTopoData();
    	HashMap<String, String> map = new HashMap<String, String>();
    	map.put("topoData", topo);
    	return new ModelAndView("/topoMini", map);
    }
    
    @RequestMapping(value = "skip2EditNode")
    public ModelAndView skip2EditNode(){
    	return new ModelAndView("editNode");
    }
    
    @RequestMapping(value = "skip2EditLink")
    public ModelAndView skip2EditLink(){
    	return new ModelAndView("editLink");
    }
    
    @RequestMapping(value = "skip2AddNode")
    public ModelAndView skip2AddNode(){
    	return new ModelAndView("addNode");
    }
    
    @RequestMapping(value = "skip2AddLink")
    public ModelAndView skip2AddLink(){
    	return new ModelAndView("addLink");
    }
    
    @RequestMapping(value = "getTopoData")
	public void getTopoData(HttpServletResponse response) throws IOException{
    	PrintWriter pw = response.getWriter();
    	String topo = topoService.getTopoData();
    	pw.print(topo);
    	pw.flush();
    }
    
    @RequestMapping(value = "addNode")
    public void addNode(HttpServletResponse response, String node_name, String category, String loc) throws IOException{
    	PrintWriter pw = response.getWriter();
    	String topo = topoService.addNode(category, node_name);
    	pw.print(topo);
    	pw.flush();
    }
    
    @RequestMapping(value = "editNode")
    public void editNode(HttpServletResponse response, String key, String loc) throws IOException{
    	PrintWriter pw = response.getWriter();
    	String topo = topoService.editNode(key, loc);
    	pw.print(topo);
    	pw.flush();
    }
	
    @RequestMapping(value = "deleteNode")
	public void deleteNode(HttpServletResponse response, String key) throws IOException{
    	PrintWriter pw = response.getWriter();
    	String topo = topoService.deleteNode(key);
    	pw.print(topo);
    	pw.flush();
    }
	
    @RequestMapping(value = "addLink")
	public void addLink(HttpServletResponse response, String from, String to, String curve) throws IOException{
    	PrintWriter pw = response.getWriter();
    	String topo = topoService.addLink(from, to, curve);
    	pw.print(topo);
    	pw.flush();
    }
	
    @RequestMapping(value = "editLink")
	public void editLink(HttpServletResponse response, String link_id, String curve) throws IOException{
    	PrintWriter pw = response.getWriter();
    	String topo = topoService.editLink(link_id, curve);
    	pw.print(topo);
    	pw.flush();
    }
	
    @RequestMapping(value = "deleteLink")
	public void deleteLink(HttpServletResponse response, String link_id) throws IOException{
    	PrintWriter pw = response.getWriter();
    	String topo = topoService.deleteLink(link_id);
    	pw.print(topo);
    	pw.flush();
    }
    
    @RequestMapping(value = "startNet")
    public void startNet(){
    	System.out.println("start net ...");
    	topoService.startNet();
    }
    
    @RequestMapping(value = "pingAll")
    public void pingAll(){
    	System.out.println("ping all ...");
    	topoService.pingAll();
    }
	
}
