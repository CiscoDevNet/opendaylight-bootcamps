package org.odl.service;


public interface TopoMiniService {
	
	public String getTopoData();
	
	public String addNode(String category, String node_name);
	
	public String editNode(String node_id, String loc);
	
	public String deleteNode(String node_id);
	
	public String addLink(String source_node_id, String dest_node_id, String curve);
	
	public String editLink(String link_id, String curve);
	
	public String deleteLink(String link_id);
	
	public String startNet();
	
	public String pingAll();
	
}
