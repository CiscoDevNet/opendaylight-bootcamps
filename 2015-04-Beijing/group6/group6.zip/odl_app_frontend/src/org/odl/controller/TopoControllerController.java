package org.odl.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.odl.service.TopoControllerService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value= "topoControllerController")
public class TopoControllerController {
	
	@Resource(name = "topoControllerService")
	private TopoControllerService topoService;
	
    @RequestMapping(value = "topoController")
    public ModelAndView topoController(){
    	String topo = topoService.getTopoData();
    	HashMap<String, String> map = new HashMap<String, String>();
    	map.put("topoData", topo);
    	return new ModelAndView("/controller/topoController", map);
    }
    
    @RequestMapping(value = "skip2EditNode")
    public ModelAndView skip2EditNode(){
    	return new ModelAndView("/controller/editNode");
    }
    
    @RequestMapping(value = "skip2EditLink")
    public ModelAndView skip2EditLink(){
    	return new ModelAndView("/controller/editLink");
    }
    
    @RequestMapping(value = "editNode")
	public void editNode(HttpServletResponse response, String key, String node_name, String loc) throws IOException{
    	PrintWriter pw = response.getWriter();
    	String topo = topoService.editNode(key, node_name, loc);
    	pw.print(topo);
    	pw.flush();
    }
	
    @RequestMapping(value = "editLink")
	public void editLink(HttpServletResponse response, String link_id, String curve, String cost) throws IOException{
    	PrintWriter pw = response.getWriter();
    	String topo = topoService.editLink(link_id, curve, cost);
    	pw.print(topo);
    	pw.flush();
    }
	
    @RequestMapping(value = "getBestPath")
	public void getBestPath(HttpServletResponse response, String weight, String source_node_id, String dest_node_id) throws IOException{
    	PrintWriter pw = response.getWriter();
    	String topo = topoService.getBestPath(weight, source_node_id, dest_node_id);
    	pw.print(topo);
    	pw.flush();
    }
    
}
