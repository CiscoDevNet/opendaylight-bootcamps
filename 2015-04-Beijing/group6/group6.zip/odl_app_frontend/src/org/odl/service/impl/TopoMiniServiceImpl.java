package org.odl.service.impl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URLEncoder;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.cookie.CookiePolicy;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.odl.service.TopoMiniService;
import org.springframework.stereotype.Repository;

@Repository(value = "topoMiniService")
public class TopoMiniServiceImpl implements TopoMiniService {

	@Override
	public String getTopoData() {
		return this.loadFromRemote("mininet/get/topology");
	}

	@Override
	public String addNode(String category, String node_name){
		String loc = URLEncoder.encode("0 0");
		return this.loadFromRemote("mininet/add/node?category=" + category + "&node_name=" + node_name + "&loc=" + loc);
	}

	@Override
	public String editNode(String node_id, String loc) {
		loc = URLEncoder.encode(loc);
		return this.loadFromRemote("mininet/update/node?id=" + node_id + "&loc=" + loc);
	}

	@Override
	public String deleteNode(String node_id) {
		return this.loadFromRemote("mininet/delete/node?id=" + node_id);
	}

	@Override
	public String addLink(String source_node_id, String dest_node_id, String curve) {
		return this.loadFromRemote("mininet/add/link?source_node_id=" + source_node_id + "&dest_node_id=" + dest_node_id + 
				"&curve=" + curve);
	}

	@Override
	public String editLink(String link_id, String curve) {
		return this.loadFromRemote("mininet/update/link?id=" + link_id + "&curve=" + curve);
	}

	@Override
	public String deleteLink(String link_id) {
		return this.loadFromRemote("mininet/delete/link?id=" + link_id);
	}

	private String loadFromRemote(String url){
		final String REMOTE_URL_PREFIX = "http://192.168.255.7:8000/";
		url = REMOTE_URL_PREFIX + url;
		final String DEFAULT_TOPO_DATA = "{\"code\":999, \"msg\":\"远程请求失败\",\"class\": \"go.GraphLinksModel\",\"nodeDataArray\": [],\"linkDataArray\": []}";
		
		HttpClient httpClient = new HttpClient();
		httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(1000 * 10);
		GetMethod get = new GetMethod(url);
		get.setRequestHeader("Referer", "http://www.baidu.com/");
		get.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
		get.getParams().setParameter(HttpMethodParams.SO_TIMEOUT, 1000 * 60);
		get.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, new DefaultHttpMethodRetryHandler());
		get.getParams().setParameter("http.protocol.cookie-policy", CookiePolicy.IGNORE_COOKIES);
		get.getParams().setParameter(HttpMethodParams.USER_AGENT, "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; Trident/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727)");			
		get.setFollowRedirects(true);
		
		try {
			int statusCode = httpClient.executeMethod(get);
			if (statusCode != HttpStatus.SC_OK) {
				String msg = get.getStatusLine().toString();
				System.err.println("远程获取拓扑失败:" + msg);
				return DEFAULT_TOPO_DATA;
			}
			
			StringBuffer resultBuffer = new StringBuffer();
			BufferedReader in = new BufferedReader(new InputStreamReader(get.getResponseBodyAsStream(), get.getResponseCharSet()));

			String inputLine = null;
			while ((inputLine = in.readLine()) != null) {
				resultBuffer.append(inputLine);
			}

			String result = resultBuffer.toString();
			result = result.replace("\"id\"", "\"key\"").replace("source_node_id", "from").replace("dest_node_id", "to");
			return result;
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			get.releaseConnection();
		}
		return DEFAULT_TOPO_DATA;
	}

	@Override
	public String startNet() {
		return this.loadFromRemote("mininet/start/net");
	}

	@Override
	public String pingAll() {
		return this.loadFromRemote("mininet/ping/all");
	}
}
