package org.odl.service;


public interface TopoControllerService {
	
	public String getTopoData();
	
	public String editNode(String node_id, String node_name, String loc);
	
	public String editLink(String link_id, String curve, String cost);
	
	public String getBestPath(String weight, String source_node_id, String dest_node_id);
}
