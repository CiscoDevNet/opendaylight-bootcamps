获取拓扑数据：
	方法签名：getTopoData
	返回格式：
	{ 
		"code":200,
		"msg":"失败原因",
		"class": "go.GraphLinksModel",
		"nodeDataArray": [
			{"category":"switch", "loc":"143 -130", "node_id":"id1", "node_name":"name1"},
			{"category":"server", "loc":"0 0", "node_id":"id2", "node_name":"name2"}
		],
		"linkDataArray": [
			{"link_id":"link", "source_node_id":"id1", "source_node_name":"name1", "dest_node_id":"id2", "dest_node_name":"name2", "load_s2d":"10Mbps", "load_d2s":"1Mbps", "color":"#01DF01", "curve":0}
		]
	}
	注： 	node_id为节点主键，唯一，不为空
		node_name为节点名称，由用户提供，也不能重复
	 	link_id为链路主键，唯一，不为空
	 	source_node_id对应源端node-id，source_node_name对应源端node_name
	 	dest_node_id对应目的端node-id, dest_node_name对应源端node_name
	 	load_s2d为源端到目的端的负载，load_d2s为目的端到源端的负载：包含单位Mbps
	 	color为链路颜色，由load决定
	 	curve为链路弧度
	
添加节点：
	方法签名：addNode(category, node_name)
	返回格式：见“获取拓扑数据”

修改节点：
	方法签名：editNode(node_id, 更改后的 node_name, 更改后的 category, 更改后的 loc)
	返回格式：见“获取拓扑数据”
	
删除节点：
	方法签名：deleteNode(node_id)
	返回格式：见“获取拓扑数据”
	
添加链路：
	方法签名：addLink(source_node_name, dest_node_name, curve)
	返回格式：见“获取拓扑数据”
	
修改链路：
	方法签名：editLink(link_id, 更改后的 source_node_name, 更改后的 dest_node_name, 更改后的 curve)
	返回格式：见“获取拓扑数据”

删除链路：
	方法签名：deleteLink(link_id)
	返回格式：见“获取拓扑数据”
	
获取最优路径数据：
	方法签名：getBestPath(double loadWeight, source_node_id, dest_node_id)
	返回格式：与"获取拓扑数据"格式相比，被选中的最优链路，有一个单独的属性：category，值为bestPath;其它链路没有这个属性
	{
		"code":200,
		"msg":"失败原因",
		"class": "go.GraphLinksModel",
		"nodeDataArray": [
			{"category":"server", "loc":"143 -130", "node_id":"server1", "node_name":"xxx"}
		],
		"linkDataArray": [
			{"category":"bestPath", "link_id":"link", "source_node_id":"server1", "source_node_name":"xxx", "dest_node_id":"switch-1", "dest_node_name":"xxx", "load_s2d":"10Mbps", "load_d2s":"1Mbps", "color":"#01DF01", "curve":0}
		]
	}