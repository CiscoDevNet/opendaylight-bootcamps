# Copyright 2015 G8.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
# the License. You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
# an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the License.


#!/usr/bin/env python

import os
import ConfigParser
import ipaddress
import json
try:
    from urllib import quote_plus
except ImportError:
    from urllib.parse import quote_plus

from basics.acl import acl_create_port_grant, acl_list, acl_json, acl_delete, _url_template
from basics.acl_apply import acl_apply_packet_filter
from basics.odl_http import odl_http_get, odl_http_post
from basics.inventory import inventory_connected
from basics import topology


_acl_route_request_content_out_to_in = '''
{
    "Cisco-IOS-XR-ipv4-acl-cfg:access": [
        {
            "access-list-name": "RULE-OUT-TO-IN",
             "access-list-entries": {
                 "access-list-entry": [
                    {
                        "sequence-number": 2000,
                        "grant": "permit"
                    },
                    {
                        "sequence-number": 10,
                        "destination-network": {
                           "destination-wild-card-bits": "0.255.255.255",
                           "destination-address": "10.0.0.0"
                        },
                       "grant": "permit",
                       "next-hop": {
                            "next-hop-1": {
                                "next-hop": "1.1.1.1"
                            },
                            "next-hop-type": "regular-next-hop"
                        }
                    }
                ]
            }
        }
    ]
}

'''

_acl_route_request_content_in_to_out = '''
{
    "Cisco-IOS-XR-ipv4-acl-cfg:access": [
        {
            "access-list-name": "RULE-IN-TO-OUT",
             "access-list-entries": {
                 "access-list-entry": [
                    {
                        "sequence-number": 2000,
                        "grant": "permit"
                    },
                    {
                        "sequence-number": 10,
                        "source-network": {
                           "source-wild-card-bits": "0.255.255.255",
                           "source-address": "10.0.0.0"
                        },
                       "grant": "permit",
                       "next-hop": {
                            "next-hop-1": {
                                "next-hop": "1.1.1.1"
                            },
                            "next-hop-type": "regular-next-hop"
                        }
                    }
                ]
            }
        }
    ]
}

'''

cfgfile = os.getcwd() + "/" + "g8.cfg"
logfile = os.getcwd() + "/" + "g8.log"
VERSION=0.1
prompt = ">>> "

topo = { }
path = { }

menu_msg =  """
(S|s) : set flow path
(D|d) : split flow path
(C|c) : change flow path
(T|t) : display network topology
(M|m) : monitor the entire network
(Q|q) : quit
(H|h) : display help info

"""


def is_valid_ip_network(ip_nk):
    """if ip is a valid ip address return True or return False"""
    try:
        ipaddress.ip_network(ip_nk.decode())
    except (ValueError):
        return False
    return True


def check_path_info(path_info):
    if path_info is None:
        print "input none path info"
        return False

    global topo

    if path_info[1] not in topo.keys() or "node" not in path_info[1]:
        print "invalid node name or the node not in the topology"
        return False

    if not is_valid_ip_network(path_info[0]):
        print "invalid ip network"
        return False

    return True


def get_device_name():
    for device_name in inventory_connected():
        if device_name is not None:
            return device_name



_acl_route_request_content_in_to_out_header = '''
{
    "Cisco-IOS-XR-ipv4-acl-cfg:access": [
        {
            "access-list-name": "RULE-IN-TO-OUT",
             "access-list-entries": {
                 "access-list-entry": [
                    {
                        "sequence-number": 2000,
                        "grant": "permit"
                    },
'''
_acl_route_request_content_in_to_out_acl_entry_temple = '''
                    {
                        "sequence-number": "%s",
                        "source-network": {
                           "source-wild-card-bits": "%s",
                           "source-address": "%s"
                        },
                       "grant": "permit",
                       "next-hop": {
                            "next-hop-1": {
                                "next-hop": "%s"
                            },
                            "next-hop-type": "regular-next-hop"
                        }
                    }
'''

_acl_route_request_content_in_to_out_end = '''
                ]
            }
        }
    ]
}'''


def build_policy():

    device_name = get_device_name()
    print('using device', device_name)

    url_suffix = (_url_template + '/accesses') % quote_plus(device_name)
    contentType = 'application/json'
    accept = contentType
    expected_status_code = [204, 409]

    _acl_route_request_content_in_to_out_header

    seq = 100
    for each in path.keys():
        source_address = each.split('/')[0]
        source_wild_card_bits = ipaddress.ip_network(each.decode()).hostmask

        in_to_out_next_hop = topo[path[each]]['inside_ip']
        out_to_in_next_hop = topo[path[each]]['outside_ip']

        content = _acl_route_request_content_in_to_out_acl_entry_temple % (seq,source_wild_card_bits, source_address, in_to_out_next_hop )

        seq = seq + 1
        
    _acl_route_request_content_in_to_out_end

    access_list_name = "RULE-IN-TO-OUT"

    content = _acl_route_request_content_in_to_out_acl_entry_temple % (seq,source_wild_card_bits, source_address, in_to_out_next_hop )

    response = odl_http_post(url_suffix, contentType, content, accept, expected_status_code)
    if response.status_code != 204:
        print(response)
        print "job failed"
        return
    else:
        print('ACLs:', acl_list(device_name))
        print(json.dumps(acl_json(device_name, access_list_name), indent=2))

    access_list_name = "RULE-OUT-TO-IN"

    content = _acl_route_request_content_out_to_in
    response = odl_http_post(url_suffix, contentType, content, accept, expected_status_code)
    if response.status_code != 204:
        print(response)
        print "job failed"
        return
    else:
        print('ACLs:', acl_list(device_name))
        print(json.dumps(acl_json(device_name, access_list_name), indent=2))

def set_flow_path( ):
    """set flow path"""
    print "please input flow path info such as: 10.0.0.0/9 node"

    try:
        info = raw_input("info: ").split()
    except (EOFError, KeyboardInterrupt):
        print " Invalid input"
        return

    if not check_path_info(info):
        return

    print "Job starting......"


    device_name = get_device_name()
    print('using device', device_name)

    url_suffix = (_url_template + '/accesses') % quote_plus(device_name)
    contentType = 'application/json'
    accept = contentType
    expected_status_code = [204, 409]

    if info[0] in path.keys():
        print "exist, return"
        return
    path[info[0]] = info[1]

    # FIXME, we will call build_policy latter

    source_address = info[0].split('/')[0]
    source_wild_card_bits = ipaddress.ip_network(info[0].decode()).hostmask

    in_to_out_next_hop = topo[info[1]]['inside_ip']
    out_to_in_next_hop = topo[info[1]]['outside_ip']




    access_list_name = "RULE-IN-TO-OUT"

    content = _acl_route_request_content_in_to_out
    response = odl_http_post(url_suffix, contentType, content, accept, expected_status_code)
    if response.status_code != 204:
        print(response)
        print "job failed"
        return
    else:
        print('ACLs:', acl_list(device_name))
        print(json.dumps(acl_json(device_name, access_list_name), indent=2))

    access_list_name = "RULE-OUT-TO-IN"

    content = _acl_route_request_content_out_to_in
    response = odl_http_post(url_suffix, contentType, content, accept, expected_status_code)
    if response.status_code != 204:
        print(response)
        print "job failed"
        return
    else:
        print('ACLs:', acl_list(device_name))
        print(json.dumps(acl_json(device_name, access_list_name), indent=2))


    print "Job done......"

def split_flow_path( ):
    """split flow path and assign parts of them to other nodes"""
    print "please input flow path info and src node , dst node"
    try:
        info = raw_input("info:").split()
    except (EOFError, KeyboardInterrupt):
        print " Invalid input"

    global topo
    print "Job started......"


def change_flow_path():
    """move flow path from one node to another node"""
    print "please input flow path info(src node, dst node)"
    try:
        info = raw_input("info: ").split()
    except (EOFError, KeyboardInterrupt):
        print "Invalid input"
        return

    global topo



def monitor( ):
    print "Sorry, have no idea to implement it for now!"
    return


def display_topology( ):
    """display current network topology"""
    global topo
    for each in topo.keys():
        if "vrf" in each:
            print each.upper() + ": " + topo[each]['interface_side'] +\
                  " connected " + topo[each]['type'].upper() + " network"

            for eachnode in topo[each]['interface_node'].split(','):
                eachnode.strip()
                print "           connected " + eachnode + "(" + topo[eachnode]['inside_ip'] + ")"

            print "\n"



def display_flow_path(ip_prefix):
    for each in ip_prefix.keys():
        print each + " ------> " + ip_prefix[each]




def quit( ):
    """quit running"""
    print "stop running!"
    exit(0)

def show_menu( ):
    """show operation menu list"""
    print menu_msg


def parse_config(cfg_file):
    """parse g8.cfg and return a dict contains all info"""
    config = ConfigParser.ConfigParser()
    config.read(cfg_file)

    cfg = {}
    sections = config.sections()

    for each in sections:
        ddict = dict((x, y) for x, y in config.items(each))
        cfg[each] = ddict

    return cfg



operations = {"s": set_flow_path,
              "d": split_flow_path,
              "c": change_flow_path,
              "t": display_topology,
              "m": monitor,
              "q": quit,
              "h": show_menu}

op_list = ["s", "d", "c", "t", "m", "q", "h"]



def worker(op):
    operations[op]()


def main_loop():
    print "H|h for help"
    global topo
    topo = parse_config(cfgfile)

    while True:
        try:
            op = raw_input(prompt).lower()

        except (EOFError, KeyboardInterrupt):
            show_menu()
            continue

        if not op:
            continue

        if op not in op_list:
            print "\nInvalid operation, H|h for help\n"
            continue

        worker(op)



if __name__ == "__main__":
    main_loop()
