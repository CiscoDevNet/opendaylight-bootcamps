config = {
 'network_device': {'xrvr-1':{
                     'address': '172.16.181.53',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'}
                    },
 'odl_server': {'address': '192.168.255.9',
                'port': 8181,
                'password': 'admin',
                'username': 'admin'}}
