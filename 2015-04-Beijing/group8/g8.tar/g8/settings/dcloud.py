config = {
 'network_device': {'kcy':{
                     'address': '198.18.1.50',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'lax':{
                     'address': '198.18.1.51',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'min':{
                     'address': '198.18.1.52',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'por':{
                     'address': '198.18.1.53',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'san':{
                     'address': '198.18.1.54',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'sea':{
                     'address': '198.18.1.55',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'sfc':{
                     'address': '198.18.1.56',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'sjc':{
                     'address': '198.18.1.57',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'xrvr-999':{
                     'address': '198.18.1.999',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'}},
 'odl_server': {'address': '198.18.1.25',
                'port': 8181,
                'password': 'admin',
                'username': 'adminadmin'}}
