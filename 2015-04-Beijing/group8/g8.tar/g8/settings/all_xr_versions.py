config = {
 'network_device': {'xrvr-511-53U':{
                     'address': '172.16.1.79',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'xrvr-531':{
                     'address': '172.16.1.80',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'xrvr-530':{
                     'address': '172.16.1.81',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'}},
 'odl_server': {'address': '127.0.0.1',
                'port': 8181,
                'password': 'admin',
                'username': 'admin'}}
