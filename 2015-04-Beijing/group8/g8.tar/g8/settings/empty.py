config = {
 'network_device': {},
 'odl_server': {'address': 'localhost',
                'port': 8181,
                'password': 'admin',
                'username': 'admin'}}
