#-*- coding:utf-8 -*-
import sys, traceback
from base import app
from flask.ext import admin
from flask import request
from flask import render_template
from flask import redirect
from flask import jsonify
from flask_debugtoolbar import DebugToolbarExtension
import json
import urllib2

app.debug = False
app.config['SECRET_KEY'] = "123456"
app.config['DEBUG_TB_INTERCEPT_REDIRECTS'] = False
toolbar = DebugToolbarExtension(app)



#Blueprint导入

#注册bp



#Flask Admin




@app.route('/')
def hello_world():
    return redirect("/static/index.html")


JSON_PATH1 = "http://192.168.255.99/topo/1.json"
JSON_PATH2 = "http://192.168.255.99/topo/1.json"

@app.route('/get_json')
def get_json():
    topo = request.args.get("topo", "")
    if topo == "topo1":
        path = JSON_PATH1
    else:
        path = JSON_PATH2

    fd = urllib2.urlopen(path)
    js = json.load(fd)
    return jsonify(js)

@app.before_request
def before_request():
    print "-- in blue_print app"

@app.errorhandler(Exception)
def exception_handler(e):
    exc_type, exc_value, exc_traceback = sys.exc_info()
    info = traceback.format_exception(exc_type, exc_value, exc_traceback)
    err_msg = "\n".join(info)
    print err_msg

@app.errorhandler(404)
def page_not_found(e):
        return render_template('404.html'), 404

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5005)
