# -*- coding:utf-8 -*-
import os

DEBUG = False
ROOT_DIR = os.path.dirname(os.path.abspath("__file__"))
LOG_DIR = "%s/log" % ROOT_DIR







