
$(document).ready(function(){
	$('.pic a').lightBox({
		imageLoading: 'images/lightbox/loading.gif',
		imageBtnClose: 'images/lightbox/close.gif',
		imageBtnPrev: 'images/lightbox/prev.gif',
		imageBtnNext: 'images/lightbox/next.gif'
	});
});