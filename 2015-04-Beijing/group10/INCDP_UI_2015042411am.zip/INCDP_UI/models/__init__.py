#-*- coding:utf-8 -*-
from flask.ext.sqlalchemy import SQLAlchemy
from base import app
db = SQLAlchemy(app)