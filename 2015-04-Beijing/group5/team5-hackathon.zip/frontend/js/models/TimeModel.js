window.TimeModel = Backbone.Model.extend({
    defaults : {
        timeValue : 0,
        sourceNodeID : 0,
        destIP : 0,
        targetNodeID : 0,
    },
});
