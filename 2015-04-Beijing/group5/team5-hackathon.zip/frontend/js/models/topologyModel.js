window.TopologyModel = Backbone.Model.extend(
{
    defaults : {
        all_nodes : {}, all_links : [],
    },
    initialize : function ()
    {
        var self = this;
        console.log("creating topology");
        self.all_nodes = [ {
            "name" : "iosxrv-1", "group" : 1
        },
        {
            "name" : "iosxrv-2", "group" : 1
        },
        {
            "name" : "iosv-1", "group" : 2
        },
        {
            "name" : "iosv-2", "group" : 2
        },
        {
            "name" : "iosv-3", "group" : 2
        },
        {
            "name" : "server-1", "group" : 3
        },
        {
            "name" : "server-2", "group" : 3
        },
        ];
        var data = [ {
            "src-switch" : "server-1", "dst-switch" : "iosxrv-1"
        },
        {
            "src-switch" : "iosxrv-1", "dst-switch" : "iosv-1"
        },
        {
            "src-switch" : "iosxrv-1", "dst-switch" : "iosv-2"
        },
        {
            "src-switch" : "iosxrv-1", "dst-switch" : "iosv-3"
        },
        {
            "src-switch" : "iosxrv-2", "dst-switch" : "iosv-1"
        },
        {
            "src-switch" : "iosxrv-2", "dst-switch" : "iosv-2"
        },
        {
            "src-switch" : "iosxrv-2", "dst-switch" : "iosv-3"
        },
        {
            "src-switch" : "iosxrv-2", "dst-switch" : "server-2"
        },
        ];
        var nodes_names = ["iosxrv-1", "iosxrv-2", "iosv-1", "iosv-2", "iosv-3", "server-1", "server-2"];
        // build array of links in format D3 expects
        self.all_links = [];
        _.each(data, function (l)
        {
            self.all_links.push(
            {
                source : nodes_names.indexOf(l['src-switch']),
                target : nodes_names.indexOf(l['dst-switch']),
                value : 10
            });
        });
        self.trigger('change');
    },
});
