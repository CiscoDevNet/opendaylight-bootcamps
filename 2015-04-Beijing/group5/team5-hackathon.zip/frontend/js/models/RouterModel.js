window.RouterModel = Backbone.Model.extend({
    defaults : {
        nodeID : 0,
        nodeIP : 0,
        nodeInterfaces : 0,
    },
});
