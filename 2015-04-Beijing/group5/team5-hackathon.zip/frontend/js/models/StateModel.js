window.StateModel = Backbone.Model.extend({
    defaults : {
        downNodeID1 : 0,
        downNodeID2 : 0,
        sourceNodeID : 0,
        destIP : 0,
        targetNodeID : 0,
    },
});
