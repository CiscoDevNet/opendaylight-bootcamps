window.ControllerStatusModel = Backbone.Model.extend(
{
    defaults : {
        controllerID : 'NA',
        controllerIP : 'NA',
        reachability : 'false',
    },
    fetch : function ()
    {
        var self = this;
        console.log("fetching controller status");
        $.ajax(
        {
            url : hackBase + "http://localhost:5000/api/v1/info/get_controller_info",
            dataType : "json",
            success : function (data)
            {
                console.log("fetched controller info: ");
                console.log(data);
                self.set("reachability", data.reachability);
                self.set("controllerID", data.serverID);
                self.set("controllerIP", data.serverIP);
                self.trigger("change");
            },
        });
    }
});
