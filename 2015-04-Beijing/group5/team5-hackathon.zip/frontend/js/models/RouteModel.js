window.RouteModel = Backbone.Model.extend({
    defaults : {
        sourceNodeID : 0,
        destIP : 0,
        targetNodeIP : 0,
    },
});
