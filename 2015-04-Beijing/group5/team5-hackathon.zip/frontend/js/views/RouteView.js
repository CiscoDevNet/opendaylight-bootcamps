window.RouteListItemView = Backbone.View.extend(
{
    tagName : "tr",
    initialize : function ()
    {
        this.template = _.template(tpl.get('route-list-item'));
        this.model.bind("change", this.render, this);
    },
    render : function (eventName)
    {
        $(this.el).html(this.template(this.model.toJSON()));
        return this;
    }
});
window.RouteListView = Backbone.View.extend(
{
    initialize : function ()
    {
        this.template = _.template(tpl.get('route-list'));
        this.model.bind("change", this.render, this);
        this.model.bind("remove", this.render, this);
    },
    render : function (eventName)
    {
        $(this.el).html(this.template());
        _.each(this.model.models, function (sw)
        {
            $(this.el).find('table.route-table > tbody') .append(new RouteListItemView({
                model : sw
            }).render().el);
        }, this);
        return this;
    },
});
