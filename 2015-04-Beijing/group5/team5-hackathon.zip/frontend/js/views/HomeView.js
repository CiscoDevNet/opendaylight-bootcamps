window.HomeView = Backbone.View.extend(
{
    initialize : function ()
    {
        console.log('Initializing Home View');
        this.template = _.template(tpl.get('home'));
    },
    render : function (eventName)
    {
        $(this.el).html(this.template());
        $(this.el).find('#controller-status').html(new ControllerStatusView({
            model : controller
        }).render().el);
        $(this.el).find('#router-list').html(new RouterListView({
            model : switchList
        }).render().el);
        $(this.el).find('#route-list').html(new RouteListView({
            model : routeList
        }).render().el);
        return this;
    },
});
