window.RouterListItemView = Backbone.View.extend(
{
    tagName : "tr",
    initialize : function ()
    {
        this.template = _.template(tpl.get('router-list-item'));
        this.model.bind("change", this.render, this);
    },
    render : function (eventName)
    {
        $(this.el).html(this.template(this.model.toJSON()));
        return this;
    }
});
window.RouterListView = Backbone.View.extend(
{
    initialize : function ()
    {
        this.template = _.template(tpl.get('router-list'));
        this.model.bind("change", this.render, this);
        this.model.bind("remove", this.render, this);
    },
    render : function (eventName)
    {
        console.log("Generating RouterListView");
        $(this.el).html(this.template({
            nswitches : switchList.length
        }));
        _.each(this.model.models, function (sw)
        {
            $(this.el).find('table.router-table > tbody') .append(new RouterListItemView({
                model : sw
            }).render().el);
        }, this);
        return this;
    },
});
