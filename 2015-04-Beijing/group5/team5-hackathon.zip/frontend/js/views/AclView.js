window.AclListItemView = Backbone.View.extend(
{
    tagName : "tr",
    initialize : function ()
    {
        this.template = _.template(tpl.get('acl-list-item'));
        this.model.bind("change", this.render, this);
    },
    render : function (eventName)
    {
        $(this.el).html(this.template(this.model.toJSON()));
        return this;
    }
});
window.AclListView = Backbone.View.extend(
{
    events : {
        "click #acl-submit" : "submit"
    },
    initialize : function ()
    {
        this.template = _.template(tpl.get('acl-list'));
        this.model.bind("change", this.render, this);
        this.model.bind("remove", this.render, this);
    },
    render : function (eventName)
    {
        $(this.el).html(this.template({
            ntimes : aclPolicies.length
        }));
        _.each(this.model.models, function (sw)
        {
            $(this.el).find('table.acl-table > tbody') .append(new AclListItemView({
                model : sw
            }).render().el);
        }, this);
        return this;
    },
    submit : function ()
    {
        // get all the data
        var sid = $("#acl-sourceNodeID").val();
        var dip = $("#acl-destIP").val();
        var tid = $("#acl-targetNodeID").val();
        // form json
        var msg = {
            "sourceNodeID" : sid, "destIP" : dip, "targetNodeID" : tid
        };
        // get the place to put new data.
        var tablePlace = $(this.el).find('table.acl-table > tbody');
        // send msg to server
        $.ajax(
        {
            type : 'POST',
            url : "http://localhost:5000/api/v1/push_route/push_static_route",
            contentType : "application/json",
            dataType : "json",
            data : JSON.stringify(msg),
            success : function (data)
            {
                console.log("acl policy add success: " + data);
                if (data == true)
                {
                    console.log("about to add acl...");
                    sw = new AclModel();
                    sw.set("sourceNodeID", sid);
                    sw.set("destIP", dip);
                    sw.set("targetNodeID", tid);
                    console.log(sw);
                    tablePlace.append(new AclListItemView({
                        model : sw
                    }).render().el);
                }
            }
        });
    },
});
