window.StateListItemView = Backbone.View.extend(
{
    tagName : "tr",
    initialize : function ()
    {
        this.template = _.template(tpl.get('state-list-item'));
        this.model.bind("change", this.render, this);
    },
    render : function (eventName)
    {
        $(this.el).html(this.template(this.model.toJSON()));
        return this;
    }
});
window.StateListView = Backbone.View.extend(
{
    events : {
        "click #state-submit" : "submit"
    },
    initialize : function ()
    {
        this.template = _.template(tpl.get('state-list'));
        this.model.bind("change", this.render, this);
        this.model.bind("remove", this.render, this);
    },
    render : function (eventName)
    {
        $(this.el).html(this.template({
            ntimes : statePolicies.length
        }));
        _.each(this.model.models, function (sw)
        {
            $(this.el).find('table.state-table > tbody') .append(new StateListItemView({
                model : sw
            }).render().el);
        }, this);
        return this;
    },
    submit : function ()
    {
        // get all the data
        var dn1 = $("#state-downNodeID1").val();
        var dn2 = $("#state-downNodeID2").val();
        var sid = $("#state-sourceNodeID").val();
        var dip = $("#state-destIP").val();
        var tid = $("#state-targetNodeID").val();
        // form json
        var msg =
        {
            "downNodeID1" : dn1, "downNodeID2" : dn2, "sourceNodeID" : sid, "destIP" : dip, "targetNodeID" : tid
        };
        // get the place to put new data.
        var tablePlace = $(this.el).find('table.state-table > tbody');
        // send msg to server
        $.ajax(
        {
            type : 'POST',
            url : "http://localhost:5000/api/v1/push_route/push_static_route",
            contentType : "application/json",
            dataType : "json",
            data : JSON.stringify(msg),
            success : function (data)
            {
                console.log("state policy add success: " + data);
                if (data == true)
                {
                    console.log("about to add state...");
                    sw = new StateModel();
                    sw.set("downNodeID1", dn1);
                    sw.set("downNodeID2", dn2);
                    sw.set("sourceNodeID", sid);
                    sw.set("destIP", dip);
                    sw.set("targetNodeID", tid);
                    console.log(sw);
                    tablePlace.append(new StateListItemView({
                        model : sw
                    }).render().el);
                }
            }
        });
    },
});
