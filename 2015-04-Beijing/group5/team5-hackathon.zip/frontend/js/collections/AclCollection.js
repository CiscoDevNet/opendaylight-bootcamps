window.AclCollection = Backbone.Collection.extend(
{
    model : AclModel,
    fetch : function ()
    {
        var self = this;
        console.log("fetching acl list");
        $.ajax(
        {
            url : "http://localhost:5000/api/v1/push_route/get_direct_route",
            dataType : "json",
            success : function (data)
            {
                console.log("fetched acl list: " + data.length);
                console.log(data);
                self.reset();
                _.each(data, function (sw)
                {
                    self.add(
                    {
                        sourceNodeID : sw.sourceNodeID,
                        destIP : sw.destIP,
                        targetNodeID : sw.targetNodeID
                    });
                });
                self.trigger("change");
            },
        });
    },
});
