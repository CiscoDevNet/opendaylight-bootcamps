window.RouterCollection = Backbone.Collection.extend(
{
    model : RouterModel,
    fetch : function ()
    {
        var self = this;
        console.log("fetching router list");
        $.ajax(
        {
            url : "http://localhost:5000/api/v1/info/get_route_info",
            dataType : "json",
            success : function (data)
            {
                console.log("fetched router list: " + data.length);
                console.log(data);
                self.reset();
                _.each(data, function (sw)
                {
                    self.add(
                    {
                        nodeID : sw.nodeID,
                        nodeIP : sw.nodeIP,
                        nodeInterfaces : sw.nodeInterfaces
                    });
                });
                self.trigger("change");
            },
        });
    },
});
