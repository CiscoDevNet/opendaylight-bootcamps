window.TimeCollection = Backbone.Collection.extend(
{
    model : TimeModel,
    fetch : function ()
    {
        var self = this;
        console.log("fetching time list");
        $.ajax(
        {
            url : "http://localhost:5000/api/v1/push_route/get_time_route",
            dataType : "json",
            success : function (data)
            {
                console.log("fetched time list: " + data.length);
                console.log(data);
                self.reset();
                _.each(data, function (sw)
                {
                    self.add(
                    {
                        timeValue : sw.timeValue,
                        sourceNodeID : sw.sourceNodeID,
                        destIP : sw.destIP,
                        targetNodeID : sw.targetNodeID
                    });
                });
                self.trigger("change");
            },
        });
    },
});
