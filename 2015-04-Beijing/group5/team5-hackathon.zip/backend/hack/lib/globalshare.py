#!/usr/bin/env python2.7
# -*-encoding:utf-8-*-

from multiprocessing import Queue

pod5_queue = Queue()