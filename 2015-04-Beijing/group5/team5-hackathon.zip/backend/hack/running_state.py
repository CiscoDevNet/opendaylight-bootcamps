# -*- coding:utf-8 -*-

# element type. eg. ['timeValue', 'soureceNodeId', 'destIP', 'targetNodeID']
# [[], []]
setted_time_strategy = []
# element type. eg. ['downNodeID1', 'downNodeID2', 'soureceNodeID', 'destIP', targetNodeID']
# [[], []]
setted_link_strategy = []
# element type. eg. ['soureceNodeID', 'destIP', 'targetNodeID']
# [[], []]
setted_direct_strategy = []

running_route = {
'iosxrv-1': [  # eg. {'destIP':'destNetwork', 'targetNodeIP':'nexthopIP'}
],

'iosxrv-2': [  # eg. {'destIP':'destNetwork', 'targetNodeIP':'nexthopIP'}
]
}