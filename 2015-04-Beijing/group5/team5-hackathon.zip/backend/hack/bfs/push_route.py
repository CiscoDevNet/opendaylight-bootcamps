# -*- coding:utf-8 -*-
from flask import Blueprint, request
from info import get_mounted_route
from bf_config import *
import requests
import json
from config import MID_SERVERS
import running_state
from lib.globalshare import pod5_queue


MOD_NAME = "push_route"
blue_print = Blueprint(MOD_NAME, MOD_NAME, template_folder="templates", static_folder="static")

# add START
def store_time_strategy(timeValue, sourceNodeID, destIP, targetNodeID):
    running_state.setted_time_strategy.append([timeValue, sourceNodeID, destIP, targetNodeID])


def store_link_strategy(downNodeID1, downNodeID2, sourceNodeID, destIP, targetNodeID):
    running_state.setted_link_strategy.append([downNodeID1, downNodeID2, sourceNodeID, destIP, targetNodeID])


def store_direct_strategy(sourceNodeID, destIP, targetNodeID):
    running_state.setted_direct_strategy.append([sourceNodeID, destIP, targetNodeID])


@blue_print.before_request
def before_request():
    print '---in blue_print %s' % MOD_NAME


@blue_print.route("/")
def root_index():
    return "Mod Name:%s" % MOD_NAME


@blue_print.route("/test", methods=["GET", "POST"])
def test():
    return "test"


@blue_print.route("/push_time_route", methods=["POST"])
def push_time_route():
    try:
        data = request.json
        nl, cl = get_mounted_route()
        if data.get('sourceNodeID', '') and data.get('sourceNodeID') in nl and data.get('destIP', '') and data.get(
                'targetNodeID', '') and data.get('timeValue', ''):
            store_time_strategy(data['timeValue'], data['sourceNodeID'], data['destIP'], data['targetNodeID'])

            put_data = {
                'type': 'time',
                'value': [data['sourceNodeID'], data['timeValue'], data['destIP'], data['targetNodeID']]
            }
            pod5_queue.put(put_data)
            print "success"
            return 'true'
        else:
            return 'false'
    except Exception as ex:
        print ex
        return 'false'


# put_data = {
#    'type': 'time',
#    'value': ['iosxrv-1', '2', '2.2.2.2/24', 'iosv-1']
#}
#pod5_queue.put(put_data)
#store_time_strategy(xxxx, xxxx, xxx, xxxx)


@blue_print.route("/push_static_route", methods=["POST"])
def push_static_route():
    try:
        data = request.json
        nl, cl = get_mounted_route()
        if data.get('sourceNodeID', '') and data.get('sourceNodeID') in nl and data.get('destIP', '') and data.get(
                'targetNodeID', ''):
            # store_direct_strategy(data['sourceNodeID'], data['destIP'], data['targetNodeID'])
            #
            # destip_list = data['destIP'].strip().split('/')
            # length = destip_list[-1] if len(destip_list) == 2 else '32'
            #
            # # Put new route entry into msg body
            # post_data = STATIC_ROUTE_CONTENT % (
            #     destip_list[0], length, MID_SERVERS[data['targetNodeID']])
            #
            # route_list = running_state.running_route.get(data['sourceNodeID'], [])
            # if route_list:
            #     for entry in route_list:
            #         print "=======", entry
            #         destip_list2 = entry['destIP'].strip().split('/')
            #         length = destip_list2[-1] if len(destip_list2) == 2 else '32'
            #         post_data = post_data + STATIC_ROUTE_CONTENT % (destip_list2[0], length, entry['targetNodeIP'])
            #
            # # Form the entire msg
            # post_data = STATIC_ROUTE_HEADER + post_data + STATIC_ROUTE_FOOTER
            #
            # print post_data
            #
            # url = POST_ROUTE_URL % data['sourceNodeID']
            # print url

            store_direct_strategy(data['sourceNodeID'], data['destIP'], data['targetNodeID'])
            destip_list = data['destIP'].strip().split('/')
            length = destip_list[-1] if len(destip_list) == 2 else '32'
            post_data = STATIC_ROUTE_CONTENT % (destip_list[0], length, MID_SERVERS[data['targetNodeID']], 'add static route from %s' % destip_list[0])
            url = POST_ROUTE_URL % data['sourceNodeID']
            print post_data
            print url

            response = requests.post(url, headers={"Content-Type": "application/json", "Accept": "application/json"},
                                    data=post_data, auth=('admin','admin'))
            print response.status_code, response.text
            return 'true'
        else:
            return 'false'
    except Exception as ex:
        print ex
        return 'false'


@blue_print.route("/get_time_route", methods=["GET"])
def get_time_route():
    result = []
    for time_strategy in running_state.setted_time_strategy:
        if len(time_strategy) > 0:
            result.append({'timeValue': time_strategy[0], 'sourceNodeID': time_strategy[1], 'destIP': time_strategy[2],
                           'targetNodeID': time_strategy[3]})
    return json.dumps(result)


@blue_print.route("/get_link_route", methods=["GET"])
def get_link_route():
    result = []
    for link_strategy in running_state.setted_link_strategy:
        if len(link_strategy) > 0:
            result.append(
                {'downNodeID1': link_strategy[0], 'downNodeID2': link_strategy[1], 'sourceNodeID': link_strategy[2],
                 'destIP': link_strategy[3], 'targetNodeID': link_strategy[4]})
    return json.dumps(result)


@blue_print.route("/get_direct_route", methods=["GET"])
def get_direct_route():
    result = []
    for direct_strategy in running_state.setted_direct_strategy:
        if len(direct_strategy) > 0:
            result.append(
                {'sourceNodeID': direct_strategy[0], 'destIP': direct_strategy[1], 'targetNodeID': direct_strategy[2]})
    return json.dumps(result)