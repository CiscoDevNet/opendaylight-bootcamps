#-*- coding:utf-8 -*-
from flask import Blueprint, request
from info import get_mounted_route
from bf_config import *
import requests, json, os
from config import MID_SERVERS
from lib.globalshare import pod5_queue

MOD_NAME = "push_route"
blue_print = Blueprint(MOD_NAME, MOD_NAME, template_folder="templates", static_folder="static")


@blue_print.before_request
def before_request():
    print '---in blue_print %s' % MOD_NAME

@blue_print.route("/")
def root_index():
    return "Mod Name:%s" % MOD_NAME

@blue_print.route("/test",  methods=["GET", "POST"])
def test():
    return "test"

@blue_print.route("/push_time_route", methods=["GET"])
def push_time_oute():
    try:
        data = request.json
        put_data = {
            'type': 'time',
            'value': [data['sourceNodeId'], data['timeValue'], data['destIP'], data['targetNodeID']]
        }
        # put_data = {
        #     'type': 'time',
        #     'value': ['iosxrv-1', '2', '2.2.2.2/24', 'iosv-1']
        # }
        pod5_queue.put(put_data)
        with open(TIME_ROUTE_FILE, 'a') as writefile:
            mes = json.dumps(data) + '\n'
            writefile.write(mes.encode('utf-8'))
        return 'true'
    except Exception as ex:
        print ex
        return 'false'

@blue_print.route("/get_time_route", methods=["GET"])
def get_time_route():
    result = []
    if os.path.isfile(TIME_ROUTE_FILE):
        with open(TIME_ROUTE_FILE, 'r') as infile:
            for line in infile:
                result.append(line.strip())
    return json.dumps(result)

@blue_print.route("/push_static_route", methods=["POST"])
def push_static_route():
    try:
        data = request.json
        nl, cl = get_mounted_route()
        if data.get('sourceNodeID', '') and data.get('sourceNodeID') in nl and data.get('destIP', '') and data.get('targetNodeID', ''):
            destip_list = data['destIP'].strip().split('/')
            length = destip_list[-1] if len(destip_list) == 2 else '32'
            post_data = STATIC_ROUTE_CONTENT % (destip_list[0], length, MID_SERVERS[data['targetNodeID']], 'add static route from %s' % destip_list[0])
            url = POST_ROUTE_URL % data['sourceNodeID']
            response = requests.put(url, headers=HEADERS, data=post_data, auth=AUTH)
            # print response.status_code, response.text
            if response.status_code == 200:
                with open(STATIC_ROUTE_FILE, 'a') as writefile:
                    mes = json.dumps(data) + '\n'
                    writefile.write(mes.encode('utf-8'))
                    return 'true'
            else:
                return 'false'
        else:
            return 'false'
    except Exception as ex:
        print ex
        return 'false'

@blue_print.route("/get_static_route", methods=["GET"])
def get_static_route():
    result = []
    if os.path.isfile(STATIC_ROUTE_FILE):
        with open(STATIC_ROUTE_FILE, 'r') as infile:
            for line in infile:
                result.append(line.strip())
    return json.dumps(result)