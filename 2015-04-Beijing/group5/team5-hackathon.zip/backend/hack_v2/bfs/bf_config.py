#-*- code:utf-8 -*-
from config import NETWORK_DEVICE
HEADERS = {'content-type': 'application/json', 'Accept': 'application/json'}
AUTH = (NETWORK_DEVICE['odl_server']['username'], NETWORK_DEVICE['odl_server']['password'])

URL_PRE = "http://%s:8181/" % NETWORK_DEVICE['odl_server']['address']
GET_NT_URL = URL_PRE + "restconf/config/network-topology:network-topology/"
GET_NODE_URL = URL_PRE + "restconf/config/opendaylight-inventory:nodes"
GET_INT_URL = URL_PRE + "restconf/operational/opendaylight-inventory:nodes/node/%s/yang-ext:mount/Cisco-IOS-XR-ifmgr-oper:interface-properties"
GET_ROUTE_URL = URL_PRE + 'restconf/config/opendaylight-inventory:nodes/node/%s/yang-ext:mount/Cisco-IOS-XR-ip-static-cfg:router-static/default-vrf/address-family/vrfipv4/vrf-unicast/vrf-prefixes'

POST_ROUTE_URL = URL_PRE + 'restconf/config/opendaylight-inventory:nodes/node/%s/yang-ext:mount/Cisco-IOS-XR-ip-static-cfg:router-static/default-vrf/address-family/vrfipv4/vrf-unicast/vrf-prefixes'

STATIC_ROUTE_CONTENT = \
"""
{"vrf-prefix": [
        {
            "prefix": "%s",
            "prefix-length": %s,
            "vrf-route": {
                "vrf-next-hops": {
                    "next-hop-address": [
                        {
                            "next-hop-address": "%s",
                            "description": "%s"
                        }
                    ]
                }
            }
        }
    ]
}
"""