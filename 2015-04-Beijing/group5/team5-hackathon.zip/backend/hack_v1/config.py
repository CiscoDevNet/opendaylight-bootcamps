#-*- coding:utf-8 -*-
DEBUG = False
SECRET_KEY = "dev_key_of_hack"
SESSION_COOKIE_NAME = "hack-dashboard"
PERMANENT_SESSION_LIFETIME = 3600 * 24 * 30
SITE_COOKIE = "hack"

NETWORK_DEVICE = {
    'network_device': {
        'iosxrv-1': {
            'address': '172.16.151.88',
            'port': 830,
            'password': 'cisco',
            'username': 'cisco'
        },
        'iosxrv-2': {
            'address': '172.16.151.89',
            'port': 830,
            'password': 'cisco',
            'username': 'cisco'
        }
    },
    'odl_server': {
        'address': '192.168.255.6',
        'port': 8181,
        'password': 'admin',
        'username': 'admin'
    }
}
