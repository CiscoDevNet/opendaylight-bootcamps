#-*- coding:utf-8
from flask import Flask
from flask.ext.cors import CORS

app = Flask(__name__)
CORS(app, resources=r'/api/*', allow_headers='Content-Type')
app.config.from_object("config")

#Blueprint导入
from bfs.info import blue_print as info_bp
from bfs.push_route import blue_print as pr_bp
from bfs.topology import blue_print as tp_bp

#注册bp
app.register_blueprint(info_bp, url_prefix="/api/v1/info")
app.register_blueprint(pr_bp, url_prefix="/api/v1/push_route")
app.register_blueprint(tp_bp, url_prefix="/api/v1/topology")

@app.route('/')
def hello_world():
    return 'Hello World!'


if __name__ == '__main__':
    app.run()
