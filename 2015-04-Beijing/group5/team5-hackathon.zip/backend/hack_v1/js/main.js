var hackBase = ""; // put a URL here to access a different REST server
var switchList = new RouterCollection();
var routeList = new RouteCollection();
var timePolicies = new TimeCollection();
var statePolicies = new StateCollection();
var aclPolicies = new AclCollection();

var AppRouter = Backbone.Router.extend({

    routes:{
        "":"home",
        "topology":"genTopology",
        "pushroute":"pushRoutes",
    },

    initialize:function () {
        $('.header').html(new HeaderView().render().el);
        this.route("", "home");
    },

    home:function () {
        console.log("Inside home function");
        $('#content').html(new HomeView().render().el);
    },

    genTopology:function () {
        var topo = new TopologyModel();
        $('#content').html(new TopologyView({model:topo}).render().el);
    },

    pushRoutes:function () {
        //console.log("switching [sic] to switch list view");
        $('#content').html(new PushRouteView().render().el);
    },
});

tpl.loadTemplates([ 'header', 'home', 'topology', 'push-route',
                    'controller-status',
                    'router-list', 'router-list-item',
                    'route-list', 'route-list-item',
                    'time-list', 'time-list-item',
                    'state-list', 'state-list-item',
                    'acl-list', 'acl-list-item'],
            function () {
                app = new AppRouter();
                Backbone.history.start({pushState: true});
                //console.log("started history")

                $(document).ready(function () {
                    // trigger Backbone routing when clicking on links, thanks to Atinux and pbnv
                    app.navigate("", true);

                    window.document.addEventListener('click', function(e) {
                        e = e || window.event
                        var target = e.target || e.srcElement
                        if ( target.nodeName.toLowerCase() === 'a' ) {
                            e.preventDefault()
                            var uri = target.getAttribute('href')
                            app.navigate(uri.substr(1), true)
                        }
                    });
                    window.addEventListener('popstate', function(e) {
                        app.navigate(location.pathname.substr(1), true);
                    });

                    // wait for the page to be rendered before loading any data
                    // switchList.fetch();
                    routeList.fetch();
                    // timePolicies.fetch();
                    // statePolicies.fetch();
                    // aclPolicies.fetch();
                });
            });