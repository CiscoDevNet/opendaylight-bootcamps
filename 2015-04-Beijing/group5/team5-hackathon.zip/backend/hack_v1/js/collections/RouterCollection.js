window.RouterCollection = Backbone.Collection.extend({

    model:RouterModel,

    fetch:function () {
		var self = this;
		console.log("fetching router list")
		$.ajax({
		    url:hackBase + "/wm/core/controller/switches/json",
		    dataType:"json",
		    success:function (data) {
			    console.log("fetched router list: " + data.length);
			    console.log(data);
			    self.reset();

			    _.each(data, function(sw) {
			           self.add({nodeID: sw.nodeID,
			           			nodeIP: sw.nodeIP,
			                    nodePortNumber: sw.nodePortNumber});
		       	});
		    },
	    });
	    self.trigger("change");
	},
});