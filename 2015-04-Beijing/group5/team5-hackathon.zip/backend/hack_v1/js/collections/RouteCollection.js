window.RouteCollection = Backbone.Collection.extend({

    model:RouteModel,

	fetch:function () {
		var self = this;
		console.log("fetching route list")
		$.ajax({
		    url: "http://localhost:5000/api/v1/info_bp/get_static_route",
		    dataType:"json",
		    success:function (data) {
			    console.log("fetched route list: " + data.length);
			    console.log(data);
			    self.reset();

			    _.each(data, function(sw) {
			           self.add({sourceNodeID: sw.sourceNodeID,
			           			destIP: sw.destIP,
			                    targetNodeIP: sw.targetNodeIP});
		       	});
			},
	    });
	    self.trigger("change");
	},
});