window.StateCollection = Backbone.Collection.extend({

    model:StateModel,

	fetch:function () {
		var self = this;
		console.log("fetching state list")
		$.ajax({
		    url:hackBase + "/wm/core/controller/switches/json",
		    dataType:"json",
		    success:function (data) {
			    console.log("fetched state list: " + data.length);
			    console.log(data);
			    self.reset();

			    _.each(data, function(sw) {
			           self.add({sourceNodeID: sw.sourceNodeID,
			           			destIP: sw.destIP,
			                    targetNodeID: sw.targetNodeID});
		       	});
		    },
	    });
	    self.trigger("change");
	},
});