window.AclModel = Backbone.Model.extend({

    defaults: {
        sourceNodeID:  0,
        destIP:  0,
        targetNodeID:  0,
    },
});