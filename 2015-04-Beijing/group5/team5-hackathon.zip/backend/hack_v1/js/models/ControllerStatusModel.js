window.ControllerStatusModel = Backbone.Model.extend({
    defaults: {
        controllerID: 'NA',
        controllerIP: 'NA',
        reachability: 'false',
    },

    initialize:function () {
        var self = this;
        console.log("fetching controller status");
        $.ajax({
            url:hackBase + "/wm/core/controller/switches/json",
            dataType:"json",
            success:function (data) {
                console.log("fetched controller info: " + data);

                self.controllerID = data.controllerID;
                self.controllerIP = data.controllerIP;
                self.reachability = data.reachability;
            },
        });
    }
});