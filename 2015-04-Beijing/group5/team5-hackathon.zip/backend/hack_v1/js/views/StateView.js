window.StateListItemView = Backbone.View.extend({

    tagName:"tr",

    initialize:function () {
        this.template = _.template(tpl.get('state-list-item'));
        this.model.bind("change", this.render, this);
    },

    render:function (eventName) {
        $(this.el).html(this.template(this.model.toJSON()));
        return this;
    }

});

window.StateListView = Backbone.View.extend({

    initialize:function () {
        this.template = _.template(tpl.get('state-list'));
        this.model.bind("change", this.render, this);
        this.model.bind("remove", this.render, this);
    },

    render:function (eventName) {
        $(this.el).html(this.template({ntimes:statePolicies.length}));
        _.each(this.model.models, function (sw) {
            $(this.el).find('table.state-table > tbody')
                .append(new StateListItemView({model:sw}).render().el);
        }, this);
        return this;
    },

});