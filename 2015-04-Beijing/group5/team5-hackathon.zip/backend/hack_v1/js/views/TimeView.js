window.TimeListItemView = Backbone.View.extend({

    tagName:"tr",

    initialize:function () {
        this.template = _.template(tpl.get('time-list-item'));
        this.model.bind("change", this.render, this);
    },

    render:function (eventName) {
        $(this.el).html(this.template(this.model.toJSON()));
        return this;
    }

});

window.TimeListView = Backbone.View.extend({

    initialize:function () {
        this.template = _.template(tpl.get('time-list'));
        this.model.bind("change", this.render, this);
        this.model.bind("remove", this.render, this);
    },

    render:function (eventName) {
        $(this.el).html(this.template({ntimes:timePolicies.length}));
        _.each(this.model.models, function (sw) {
            $(this.el).find('table.time-table > tbody')
                .append(new TimeListItemView({model:sw}).render().el);
        }, this);
        return this;
    },

});