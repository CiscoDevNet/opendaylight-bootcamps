window.PushRouteView = Backbone.View.extend({

    initialize:function () {
        console.log('Initializing push route View');
        this.template = _.template(tpl.get('push-route'));
    },

    render:function (eventName) {
        $(this.el).html(this.template());
        var stats = new ControllerStatusModel();
        $(this.el).find('#time-list').html(new TimeListView({model:timePolicies}).render().el);
        $(this.el).find('#state-list').html(new StateListView({model:statePolicies}).render().el);
        $(this.el).find('#acl-list').html(new AclListView({model:aclPolicies}).render().el);
        return this;
    },
});