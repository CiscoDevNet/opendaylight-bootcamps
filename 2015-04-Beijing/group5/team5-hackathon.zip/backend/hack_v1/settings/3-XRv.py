config = {
 'network_device': {'xrvr-1':{
                     'address': '172.16.151.78',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'xrvr-2':{
                     'address': '172.16.151.81',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'xrvr-3':{
                     'address': '172.16.151.80',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'}},
 'odl_server': {'address': '192.168.255.6',
                'port': 8181,
                'password': 'admin',
                'username': 'admin'}}
