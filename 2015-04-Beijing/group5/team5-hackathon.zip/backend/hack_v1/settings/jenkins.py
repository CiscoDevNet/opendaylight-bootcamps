config = {
 'network_device': {'xrvr-999':{
                     'address': '172.16.1.999',
                     'port': 830,
                     'password': 'test',
                     'username': 'test'},
                    'xrvr-61':{
                     'address': '172.16.1.61',
                     'port': 830,
                     'password': 'test',
                     'username': 'test'},
                    'xrvr-62':{
                     'address': '172.16.1.62',
                     'port': 830,
                     'password': 'test',
                     'username': 'test'},
                    'xrvr-63':{
                     'address': '172.16.1.63',
                     'port': 830,
                     'password': 'test',
                     'username': 'test'}},
 'odl_server': {'address': 'localhost',
                'port': 8181,
                'password': 'admin',
                'username': 'admin'}}
