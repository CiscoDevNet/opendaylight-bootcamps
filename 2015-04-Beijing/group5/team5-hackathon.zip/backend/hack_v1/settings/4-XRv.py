config = {
 'network_device': {'xrvr-1':{
                     'address': '172.16.1.50',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'xrvr-2':{
                     'address': '172.16.1.51',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'xrvr-3':{
                     'address': '172.16.1.52',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'xrvr-4':{
                     'address': '172.16.1.53',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'}},
 'odl_server': {'address': '192.168.255.6:8181',
                'port': 8181,
                'password': 'admin',
                'username': 'admin'}}
