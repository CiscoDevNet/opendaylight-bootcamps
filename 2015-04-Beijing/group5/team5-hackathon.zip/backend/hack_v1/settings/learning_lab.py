config = {
 'network_device': {'xrvr-1':{
                     'address': '172.16.1.76',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'xrvr-2':{
                     'address': '172.16.1.75',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'}},
 'odl_server': {'address': '127.0.0.1',
                'port': 8181,
                'password': 'admin',
                'username': 'admin'}}
