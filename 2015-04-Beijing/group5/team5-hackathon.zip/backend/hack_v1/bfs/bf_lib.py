#-*- code:utf-8 -*-
def handle_response(res):
    if res.status_code/200 == 1:
        res_json = res.json()
        if res_json.has_key('errors'):
            msg = 'Got a error from %s \n error-type: %s, error-tag: %s, error-mes: %s' % \
                  (res.url, res_json['errors']['error'][0]['error-type'], res_json['errors']['error'][0]['error-tag'],
                   res_json['errors']['error'][0]['error-message'])
            raise Exception(msg)
        else:
            return res_json
    else:
        msg = 'Expected HTTP error, got %d, response: %s' % (res.status_code, res.text)
        raise Exception(msg)

