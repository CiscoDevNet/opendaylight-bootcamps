#-*- coding:utf-8 -*-
from flask import Blueprint

MOD_NAME = "push_route"
blue_print = Blueprint(MOD_NAME, MOD_NAME, template_folder="templates", static_folder="static")


@blue_print.before_request
def before_request():
    print '---in blue_print %s' % MOD_NAME

@blue_print.route("/")
def root_index():
    return "Mod Name:%s" % MOD_NAME

@blue_print.route("/test",  methods=["GET", "POST"])
def test():
    return "test"