#-*- coding:utf-8 -*-
from flask import Blueprint
import requests, json
from bf_config import *
from bf_lib import handle_response
from config import NETWORK_DEVICE

MOD_NAME = "info"
blue_print = Blueprint(MOD_NAME, MOD_NAME, template_folder="templates", static_folder="static")

def get_mounted_route():
    res = requests.get(GET_NODE_URL, headers=HEADERS, auth=('admin', 'admin'))
    res_json = handle_response(res)
    node_list = []
    controller_list = []
    for node in res_json['nodes']['node']:
        if 'controller' not in node['id']:
            node_list.append(node['id'])
        else:
            controller_list.append(node['id'])

    return node_list, controller_list

def get_route_ip(device_name):
    return NETWORK_DEVICE['network_device'][device_name]['address']

def get_controller_ip():
    return NETWORK_DEVICE['odl_server']['address']

@blue_print.before_request
def before_request():
    print '---in blue_print %s' % MOD_NAME

@blue_print.route("/")
def root_index():
    return "Mod Name:%s" % MOD_NAME

@blue_print.route("/test",  methods=["GET", "POST"])
def test():
    return "test"

@blue_print.route("/get_controller_info", methods=["GET"])
def get_controller_info():
    nl, cl = get_mounted_route()
    result = {'serverID': cl[0], 'serverIP': get_controller_ip(), 'reachability': 'true' if cl else 'false'}
    return json.dumps(result)

@blue_print.route("/get_route_info", methods=["GET"])
def get_route_info():
    nl, cl = get_mounted_route()
    result = []
    for node in nl:
        interface_url = GET_INT_URL % node
        res = requests.get(interface_url, headers=HEADERS, auth=('admin', 'admin'))
        res_json = handle_response(res)

        interfaces = res_json["interface-properties"]['data-nodes']['data-node'][0]['system-view']['interfaces']['interface']
        inters = []
        for inter in interfaces:
            if 'ethernet' in inter.get('type', 'test').lower():
                inters.append(inter.get('interface-name'))

        data = {'nodeID': node, 'nodeIP': get_route_ip(node), 'nodeInterfaces': inters}
        result.append(data)

    return json.dumps(result)

@blue_print.route("/get_static_route", methods=["GET"])
def get_static_route():
    nl, cl = get_mounted_route()
    result = []
    for node in nl:
        static_url = GET_ROUTE_URL % node
        res = requests.get(static_url, headers=HEADERS, auth=('admin', 'admin'))
        res_json = handle_response(res)

        prefixes = res_json['vrf-prefixes']['vrf-prefix']
        for prefix in prefixes:
            destip = '%s/%d' % (prefix['prefix'], prefix['prefix-length'])
            nextip = prefix['vrf-route']['vrf-next-hops']['next-hop-address'][0]['next-hop-address']
            result.append({'sourceNodeID': node, 'destIP': destip, 'targetNodeIP': nextip})


    return json.dumps(result)
