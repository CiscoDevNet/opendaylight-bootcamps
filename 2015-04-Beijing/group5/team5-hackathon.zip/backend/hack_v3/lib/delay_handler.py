#! /usr/bin/env python2.7
# -*-encoding:utf-8-*-

from multiprocessing import Queue
import os, time
from globalshare import pod5_queue
import logging
import heapq

logging.basicConfig(filename=os.path.join(os.getcwd(), 'handler_entry.log'), level=logging.DEBUG)
time_strategy_heap = []
link_strategy_list = []


def handler_entry():
    while True:
        if not pod5_queue.empty():
            value = pod5_queue.get(True)
            # TODO: handle value got from queue.
            handle_value_from_queue(value)
            time.sleep(1)
        else:
            # TODO: check whether an conditons reached ?
            check_and_send_strategy()
            time.sleep(1)


def handle_value_from_queue(element):
    if element['type'] == 'time':
        # element: [sourceNodeId, time, destNetwork, nexthopNode]
        the_timing = int(element['value'][1])
        the_route = [element['value'][0], element['value'][2], element['value'][3]]

        #we computing the timing
        the_timing = int(time.time() + the_timing * 60)
        heapq.heappush(time_strategy_heap, (the_timing, the_route))
    elif element['type'] == 'link':
        link_strategy_list.append(element['value'])
    else:
        logging.warning('unrecognized strategy type.')


def check_and_send_strategy():
    # check time_strategy_heap
    # time heap item: (time, [sourceNodeId, destNetwork, nexthopNode])
    if len(time_strategy_heap) > 0:
        cur_time = int(time.time())
        check_time = time_strategy_heap[0][0]
        if ( cur_time > check_time ):
            logging.debug("get a time strategy need put to routers. cur_time:%f check_time:%f" % (cur_time, check_time))
            heapq.heappop(time_strategy_heap)
        # TODO: Here will do a STATIC_ROUTE_POST.

        else:
            logging.debug("strategy No need to put to routes. cur_time:%f check_time:%f" % (cur_time, check_time))
    else:
        pass
