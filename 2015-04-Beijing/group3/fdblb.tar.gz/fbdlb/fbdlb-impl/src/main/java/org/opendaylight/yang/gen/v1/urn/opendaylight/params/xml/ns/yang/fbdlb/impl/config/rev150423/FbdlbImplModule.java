package org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.fbdlb.impl.config.rev150423;

import org.opendaylight.fbdlb.fbdlb_impl.FbdlbImpl;
import org.opendaylight.controller.md.sal.binding.api.DataBroker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FbdlbImplModule extends org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.fbdlb.impl.config.rev150423.AbstractFbdlbImplModule {

    private static final Logger log = LoggerFactory.getLogger(FbdlbImplModule.class);

    FbdlbImpl fbdlbImpl;

    public FbdlbImplModule(org.opendaylight.controller.config.api.ModuleIdentifier identifier, org.opendaylight.controller.config.api.DependencyResolver dependencyResolver) {
        super(identifier, dependencyResolver);
    }

    public FbdlbImplModule(org.opendaylight.controller.config.api.ModuleIdentifier identifier, org.opendaylight.controller.config.api.DependencyResolver dependencyResolver, org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.fbdlb.impl.config.rev150423.FbdlbImplModule oldModule, java.lang.AutoCloseable oldInstance) {
        super(identifier, dependencyResolver, oldModule, oldInstance);
    }

    @Override
    public void customValidation() {
        // add custom validation form module attributes here.
    }

    @Override
    public java.lang.AutoCloseable createInstance() {
        DataBroker dataService = getDataBrokerDependency();
        if (dataService == null)log.info("data broker is null");
        fbdlbImpl = new FbdlbImpl(dataService);
        fbdlbImpl.start();
        final class CloseResources implements AutoCloseable {
            @Override
            public void close() throws Exception {
                if(fbdlbImpl != null) {
                    fbdlbImpl.close();
                }
                log.info("fbdlbImpl (instance {}) torn down.", this);
            }
        }
        AutoCloseable ret = new CloseResources();
        log.info("fbdlbImpl (instance {}) initialized.", ret);
        return ret;
    }

}
