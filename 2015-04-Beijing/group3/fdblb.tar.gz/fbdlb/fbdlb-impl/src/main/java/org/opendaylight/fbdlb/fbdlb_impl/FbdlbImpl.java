package org.opendaylight.fbdlb.fbdlb_impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.*;
import org.apache.http.HttpResponse;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.common.util.concurrent.CheckedFuture;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;

import org.opendaylight.yang.gen.v1.urn.opendaylight.fbdlb.rev150423.Interfaces;
import org.opendaylight.yang.gen.v1.urn.opendaylight.fbdlb.rev150423.interfaces.Interface;
import org.opendaylight.yang.gen.v1.urn.opendaylight.fbdlb.rev150423.interfaces.InterfaceKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.fbdlb.rev150423.interfaces.InterfaceBuilder;
import org.opendaylight.controller.md.sal.binding.api.DataBroker;
import org.opendaylight.controller.md.sal.binding.api.WriteTransaction;
import org.opendaylight.controller.md.sal.common.api.data.LogicalDatastoreType;
import org.opendaylight.yangtools.yang.binding.InstanceIdentifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FbdlbImpl{
    DataBroker dataServer;

    private static final Logger log = LoggerFactory.getLogger(FbdlbImpl.class);
    private static final String TOPOLOGY_NAME = "flow:1";
    private List<String> nodeIdList;
    public static String getInputPackets(String jsonString) throws JSONException {
        JSONObject jsonObject = new JSONObject(jsonString);
        String inputPackets = jsonObject.getJSONObject("ipv4-network")
                        .getJSONObject("nodes")
                        .getJSONArray("node")
                        .getJSONObject(0)
                        .getJSONObject("statistics")
                        .getJSONObject("traffic")
                        .getJSONObject("ipv4-stats")
                        .getString("input-packets");
        return inputPackets;
    }
private void submit(final WriteTransaction writeTx) {

            final CheckedFuture writeTxResultFuture = writeTx.submit();

            Futures.addCallback(writeTxResultFuture, new FutureCallback() {

                @Override

                public void onSuccess(Object o) {

                    log.debug("write successful for tx :{}",

                            writeTx.getIdentifier());

                }

                @Override

                public void onFailure(Throwable throwable) {

                    log.error("write transaction {} failed",

                            writeTx.getIdentifier(), throwable.getCause());

                }

            }); 

        }
    public FbdlbImpl(DataBroker dataServer){
        this.dataServer = dataServer;
        nodeIdList = new ArrayList<String>();
        nodeIdList.add("iosxrv-1");
        nodeIdList.add("iosxrv-2");
        nodeIdList.add("iosxrv-3");
        nodeIdList.add("iosxrv-4");
    }
    public void start(){
DefaultHttpClient httpClient = new DefaultHttpClient();
            for(int i = 0; i<nodeIdList.size();i++){
                String nodeId = nodeIdList.get(i);
                try {
                    Credentials creds = new UsernamePasswordCredentials("admin","admin");
                    HttpGet getRequest = new HttpGet("http://192.168.255.2:8181/restconf/operational/opendaylight-inventory:nodes/node/"+nodeId+"/yang-ext:mount/Cisco-IOS-XR-ipv4-io-oper:ipv4-network");
                    getRequest.addHeader("accept", "application/json");
                    getRequest.addHeader(BasicScheme.authenticate(creds, "UTF8", false));
                    HttpResponse response = httpClient.execute(getRequest);
                    if (response.getStatusLine().getStatusCode() != 200) {
                        throw new RuntimeException("Failed : HTTP error code : "+ response.getStatusLine().getStatusCode());
                    }
                    BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));
                    String output;
                    while ((output = br.readLine()) != null) {
                        try {
                            String inputPackets = getInputPackets(output);
                            if(!inputPackets.contains("input-packets"))continue;
                            InstanceIdentifier<Interface> IF_IID = InstanceIdentifier
                                .builder(Interfaces.class).child(Interface.class, new InterfaceKey(nodeId+"-"+i)).build();
                            Interface IF = new InterfaceBuilder().setInterfaceId(nodeId+"-"+i).setCurrentWorkload(Long.parseLong(inputPackets)).build();
                            final WriteTransaction tx = dataServer.newWriteOnlyTransaction();
                            if (tx == null)return;
                            try {
                                tx.put(LogicalDatastoreType.CONFIGURATION, IF_IID, IF, true);
                            } catch (Exception e) {
                            }
                            submit(tx);
                        } catch (JSONException e) {
                        }
                    }
                } catch (ClientProtocolException e) {
                } catch (IOException e) {
                }
            }
            httpClient.getConnectionManager().shutdown();
 
    }
    public void close(){

    }
}
