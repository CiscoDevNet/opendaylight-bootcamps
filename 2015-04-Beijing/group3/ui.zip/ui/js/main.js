var IOSXRV_IMAGE="image/iosxrv.png";
var CTRL_IMAGE="image/controller.png";
var SERVER_IMAGE="image/server.png";
var UNKNOWN_IMAGE="image/unknown.png";
var NODE_TEMPLATE="<table class=\"nodedetail\">"+
    "<tr><td>id</td><td><%=id%></td></tr>"
    +"</table>"
var nodeTemplate=_.template(NODE_TEMPLATE);

var mouseDown = 0;
var mouseX=0;
var mouseY=0;
var width=1000;
var height=600;
var Topology=function(){
    this.json=null;
    this.id=null;
    this.ctrlNode={
    };
    this.switchNodes=[];
    
    this.idToSwitch={};
    this.nameToSwitch={};

    this.links=[];
    this.switchNameToServer={};
    this.content=function(){
        var allServer=[];
        _.each(this.switchNameToServer,function(serverSet,switchName){
            _.each(serverSet,function(serverObj){
                allServer.push(serverObj);
            });
        });
        return [{content:"Topology-Id : "+this.id,expand:this.serverLinks},
                {content:"Controller ",expand:this.ctrlNode},
                {content:"Switches ("+this.switchNodes.length+")",expand:this.switchNodes},
                {content:"Hosts ("+allServer.length+")",expand:allServer}]
    }
}
Topology.prototype={
    reGet:function(callback){
        var topo=this;
        api.getTopology(function(json){
            var topoJson=json["network-topology"]["topology"][0];
            topo.id=topoJson["topology-id"],
            topo.json=topoJson;
            _.each(topoJson["node"],function(nodeJson){
                var node={
                    id:nodeJson["node-id"],
                    json:nodeJson,
                    content:function(){
                        if(node.type=="controller"){
                            return [{content:"Id : "+this.id}];
                        }else{
                            return [{content:"Id : "+this.id}]
                        }
                    },
                    title:function(){
                        return "Switch : "+this.id;
                    }
                };
                if(node.id=="controller-config"){
                    node.type="controller";
                    topo.ctrlNode=node;
                }else{
                    node.type="switch";
                    node.index=topo.switchNodes.length;
                    topo.switchNodes.push(node);
                    topo.idToSwitch[node.id]=node;
                }
            });
            if(typeof(callback)=="function"){
                callback();
            }else{
                console.log("finish topology getting without callback");
            }
        });
    },
    reGetNodeDetail:function(callback){
        var topo=this;
        var count=0;
        _.each(this.switchNodes,function(switchNode){
            api.getNode(switchNode.id,function(json){
                // parse interface 
                var ifJson=json["Cisco-IOS-XR-ifmgr-cfg:interface-configurations"]["interface-configuration"];
                var ifList=[];
                _.each(ifJson,function(oneIfJson){
                    var oneIf={
                        active:oneIfJson["active"],
                        description:oneIfJson["description"],
                        name:oneIfJson["interface-name"],
                        content:function(){
                            return [{content:"Interface-Name : "+this.name},
                                    {content:"Description : "+this.description},
                                   ];
                        },
                        title:function(){
                            return "Interface : "+this.name;
                        }
                    }
                    ifList.push(oneIf);
                });
                // add detail
                var detail={
                    configName:json["Cisco-IOS-XR-shellutil-cfg:host-name"],
                    ifList:ifList,
                    content:function(){
                        if(this.type=="switch"){
                            return [{content:"Id : "+this.id},
                                    {content:"Config-Name : "+this.configName},
                                    {content:"Interface ("+this.ifList.length+")",expand:this.ifList}
                                   ];
                        }else{
                        }
                    },
                    title:function(){
                        return "Switch : "+this.id;
                    }
                }
                _.extend(switchNode,detail);
                topo.nameToSwitch[switchNode.configName]=switchNode;
                topo.computeLinks();
                callback();
            });
            // after all request, checkLinks
        },this);
    },
    computeLinks:function(){
        _.each(this.switchNodes,function(switchNode){
            //doing
            _.each(switchNode.ifList,function(oneIf){
                if(oneIf.description){
                    if(oneIf.description.indexOf("to")==0){
                        var neighborName=_.last(oneIf.description.split(" "));
                        if(neighborName.indexOf("server")>=0){
                            var serverSet=this.switchNameToServer[switchNode.configName];
                            if(!serverSet){
                                serverSet=[];
                                this.switchNameToServer[switchNode.configName]=serverSet;
                            }
                            if(_.some(serverSet,function(serverObj){
                                return serverObj.configName==neighborName;
                            })){
                                return ;
                            }else{
                                serverSet.push({
                                    configName:neighborName,
                                    parentName:switchNode.configName,
                                    type:"server",
                                    content:function(){
                                        return [{content:"Config-Name : "+this.configName},
                                                {content:"Connected-Switch : "+this.parentName}
                                               ];
                                    },
                                    title:function(){
                                        return "Server "+this.configName;
                                    }
                                });
                            }
                        }else{
                            var neighborSwitch=this.nameToSwitch[neighborName];
                            if(neighborSwitch){
                                this.links.push([switchNode.configName,neighborSwitch.configName]);
                            }
                        }
                    }else{
                        //console.log("other interface : "+oneIf.description);
                    }
                }
            },this);
        },this);
        // remove link repeated
        var linkDict={}
        _.each(this.links,function(aLink){
            var src=aLink[0];
            var dst=aLink[1]
            if(src<dst){
                linkDict[src]=linkDict[src]||{};
                linkDict[src][dst]=true;
            }else{
                linkDict[dst]=linkDict[dst]||{};
                linkDict[dst][src]=true;
            }
        });
        this.links=[];
        _.each(linkDict,function(dstDict,src){
            _.each(dstDict,function(flag,dst){
                this.links.push([src,dst]);
            },this);
        },this);
    }
}
function d3draw(topo){
    width=$(".ui-tabs-nav").width();
    var nodes=[];
    var links=[];
    // global var for test
    sthNodes=nodes;
    sthLinks=links;
    // add controller node
    var ctrlNode= {
        x:40,
        y:120,
        weight:1,
        fixed:true,
        nodeObj:topo.ctrlNode
    };
    nodes.push(ctrlNode);
    // add switch nodes
    var switchNodes=[];
    _.each(topo.switchNodes,function(element,index){
        var drawNode={
            x:index*40,
            y:240,
            weight:1,
            fixed:false,
            nodeObj:element
        }
        nodes.push(drawNode);
        switchNodes.push(drawNode);
    });
    // add server node
    var tempCount=0;
    _.each(topo.switchNameToServer,function(serverSet,switchName){
        _.each(serverSet,function(serverObj){
            tempCount++;
            var drawNode={
                x:40*(tempCount),
                y:360,
                weight:1,
                fixed:false,
                nodeObj:serverObj
            };
            nodes.push(drawNode);
        });
    });
    // add links 
    // add link between controller and switches
    _.each(switchNodes,function(element,index){
        links.push({
            source:element,
            target:ctrlNode,
            clazz:"dash",
            distance:300
        });
    });
    // add link between switch and switch
    _.each(topo.links,function(element,index){
        var srcName=element[0];
        var dstName=element[1];
        var twoNode=_.filter(nodes,function(aNode){
            return aNode.nodeObj.configName==srcName
                ||aNode.nodeObj.configName==dstName;
        });
        if(twoNode.length==2){
            links.push({
                source:twoNode[0],
                target:twoNode[1],
                clazz:"solid",
                distance:200
            });
        }
    });
    // add link between switch and server
    _.each(topo.switchNameToServer,function(serverSet,switchName){
        var switchNode=_.filter(nodes,function(aNode){
            return aNode.nodeObj.configName==switchName;
        })[0];
        _.each(serverSet,function(serverObj){
            var serverNode=_.filter(nodes,function(aNode){
                if(aNode.nodeObj.type=="server"){
                    return aNode.nodeObj.configName==serverObj.configName
                        &&aNode.nodeObj.parentName==switchName;
                }else{
                    return false;
                }
            })[0];
            links.push({
                source:switchNode,
                target:serverNode,
                clazz:"solid",
                distance:50
            });
        });
    });
    // d3 draw
    var force=d3.layout.force().charge(-500).linkDistance(function(aLink){
        return Math.random()*aLink.distance/5.0+aLink.distance*4.0/5;
    }).size([width,height]);
    force.nodes(nodes).links(links).start();
    $("#topology").empty()
    var svg=d3.select("#topology").append("svg").attr("width",width+"px").attr("height",height);
    var linkDraw=svg.selectAll("line").data(links).enter()
        .append("line").attr("class",function(d){return d.clazz;});
    var nodeDraw=svg.selectAll("g").data(nodes).enter()
        .append("g").call(force.drag);
    
    nodeDraw.append("image").attr("xlink:href", function(d){
        if(d.nodeObj.type=="controller"){
            return CTRL_IMAGE;
        }else if(d.nodeObj.type=="switch"){
            return IOSXRV_IMAGE;
        }else if(d.nodeObj.type=="server"){
            return SERVER_IMAGE;
        }
    }).attr("width",function(d){
        if(d.nodeObj.type=="server"){return 30;}else {return 40;}
    }).attr("height",function(d){
        if(d.nodeObj.type=="server"){return 30;}else {return 40;}
    }).attr("x",function(d){
        if(d.nodeObj.type=="server"){return -15;}else {return -30}
    }).attr("y",function(d){
        if(d.nodeObj.type=="server"){return -15;}else {return -30;}
    });
    
    nodeDraw.append("text").attr("dx",20).attr("dy",".35em").text(function(d){
        var nodeObj=d.nodeObj;
        if(nodeObj.type=="controller"){
            return nodeObj.id;
        }else{
            return nodeObj.configName;
        }
    });
    force.on("tick",function(){
        linkDraw.attr("x1", function(d) { return d.source.x; })
            .attr("y1", function(d) { return d.source.y; })
            .attr("x2", function(d) { return d.target.x; })
            .attr("y2", function(d) { return d.target.y; });
        nodeDraw.attr("transform",function(d){return "translate("+d.x+","+d.y+")";});
    });
    
    var inItem=0;
    nodeDraw.on("mouseenter",function(n){
    });
    nodeDraw.on("mouseleave",function(e){
    });
    var checked=false;
    $("#checkbox").on("click",function(e){
        if(checked){
            d3.selectAll("g").each(function(d){
                if(d.nodeObj.type=="switch"){
                    d.fixed=false;
                }
            });
            checked=false;
        }else{
            d3.selectAll("g").each(function(d){
                if(d.nodeObj.type=="switch"){
                    d.fixed=true;
                }
            });
            checked=true;
        }
    })
}
function tableShow(topology){
    $("ul#resources").empty();
    var makeLine=function(inner,level){
        var a$=$("<a></a>");
        if(inner.expand){
            a$.text(" + "+inner.content);
        }else{
            a$.text(inner.content);
        }
        var li$=$("<li></li>").addClass("resource").append(
            $("<div></div>").addClass("heading").append(
                $(["<h1></h1>","<h2></h2>","<h3></h3>","<h4></h4>","<h5></h5>"][level-1]).append(a$)
            )
        );
        var expanded=false;
        var liList=[];
        li$.myClose=function(){
            if(inner.expand){
                a$.text(" + "+inner.content);
            }
            _.each(liList,function(aLi){
                aLi.myClose();
                aLi.remove();
            });
            expanded=false;
            return;
        }
        li$.on("click",function(){
            a$.text(" - "+inner.content);
            if(expanded){
                li$.myClose();
                return;
            }
            if(inner.expand){
                a$.text(" - "+inner.content);
            }
            if(_.isArray(inner.expand)){
                var thisLi$=li$;
                _.each(inner.expand,function(arrayItem){
                    var lineInner={content:arrayItem.title(),expand:arrayItem};
                    var newLi$=makeLine(lineInner,level+1);
                    thisLi$.after(newLi$);
                    thisLi$=newLi$;
                    liList.push(newLi$);
                });
                expanded=true;
            }else if(_.isObject(inner.expand)){
                var thisLi$=li$;
                _.each(inner.expand.content(),function(inner){
                    var newLi$=makeLine(inner,level+1);
                    thisLi$.after(newLi$);
                    thisLi$=newLi$;
                    liList.push(newLi$);
                });
                expanded=true;
            }else{
            }
        });
        return li$;
    }
    _.each(topology.content(),function(line){
        var li$=makeLine(line,1);
        $("ul#resources").append(li$);
    });
    /*
    _.each(topology.content(),function(line){
        addLine(line,1);
    });*/
    /*
    var addLine=function(inner,level){
        var a$=$("<a></a>").append(inner.content);
        var li$=$("<li></li>").addClass("resource").append(
            $("<div></div>").addClass("heading").append(
                $(["<h1></h1>","<h2></h2>","<h3></h3>","<h3></h3>","<h3></h3>"][level-1]).append(a$)
            )
        );
        if(_.isObject(inner.expand)){
            li$.on("click",function(){
                li$.after(addLine(expand.content(),level+1));
            });
        }else if(_.isObject(inner.expand)){
            li$.on("click",function(){
                li$.after(addLine(expand.content(),level+1));
            });
        }
        $("ul#resources").append(
        )
    }*/
}
function graphRefresh(){
    $("#table").hide();
    $("#graph").show();
    d3draw(topology);
}
function tableRefresh(){
    $("#graph").hide();
    $("#table").show();
    tableShow(topology);
}
$(document).ready(function(){
    width=$(".ui-tabs-nav").width();
    if(window.location.hash.length>=4){
        CTRL_ADDR=window.location.hash.substr(1)+":8181";
    }
    $("#table").hide();
    document.body.onmousedown = function() { 
        ++mouseDown;
    }
    document.body.onmouseup = function() {
        --mouseDown;
    }
    document.body.onmousemove=function(e){
        mouseX=e.x;
        mouseY=e.y;
    }
    topology=new Topology();
    topology.reGet(function(){
        d3draw(topology);
        topology.reGetNodeDetail(function(){
            d3draw(topology);
        });
    });
    $("#tabs ul li").on("mouseenter",function(e){
        $(e.target).closest("li").addClass("ui-state-hover");
    });
    $("#tabs ul li").on("mouseleave",function(e){
        $(e.target).closest("li").removeClass("ui-state-hover");
    });
    var showType="graph";
    $("#graphTab").closest("li").addClass("ui-tabs-active ui-state-active");
    $("#graphTab").on("click",function(e){
        if(showType=="graph"){
            return ;
        }else{
            // show as graph
            graphRefresh();
            $(e.target).closest("li").addClass("ui-tabs-active ui-state-active")
            $("#tableTab").closest("li").removeClass("ui-tabs-active ui-state-active")
            showType="graph";
        }
    });
    $("#tableTab").on("click",function(e){
        if(showType=="table"){
            return ;
        }else{
            // show as graph
            tableRefresh();
            $(e.target).closest("li").addClass("ui-tabs-active ui-state-active")
            $("#graphTab").closest("li").removeClass("ui-tabs-active ui-state-active")
            showType="table";
        }
    });
});