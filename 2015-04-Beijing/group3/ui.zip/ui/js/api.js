var CTRL_ADDR="192.168.255.4:8181";
var api={
    getAuth:function(){
        var username="admin";
        var password="admin";
        var hash = btoa(username+":"+password);
        return "Basic "+hash;
    },
    getUrl:function(url,success,error){
        $.ajax({
            type:"GET",
            url:url,
            dataType:"json",
            headers:{
                "Authorization":api.getAuth(),
            },
            success:function(json){
                if(typeof(success)=="function"){
                    success(json);
                }else{
                    alert("not a callable parameter");
                }
            },
            error:function(data){
                if(typeof(error)=="function"){
                    error(data);
                }
            }
        });
    },
    getTopology:function(success,error){
        var url="http://"+CTRL_ADDR+"/restconf/operational/network-topology:network-topology/";
        api.getUrl(url,success,error);
    },
    getMounted:function(){
    },
    getNode:function(nodeId,success,error){
        var url="http://"+CTRL_ADDR+"/restconf/config/opendaylight-inventory:nodes/node/"+nodeId+"/yang-ext:mount";
        api.getUrl(url,success,error);
    },
    getNodeInterface:function(nodeId,success,error){
        var url="http://"+CTRL_ADDR+"/restconf/operational/opendaylight-inventory:nodes/node/"+nodeId+"/yang-ext:mount/Cisco-IOS-XR-ifmgr-cfg:interface-configurations";
        api.getUrl(url,success,error);
    }
}