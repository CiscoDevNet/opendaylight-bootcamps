import os
os.system("python -m SimpleHTTPServer 8888");
