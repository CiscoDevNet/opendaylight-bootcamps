config = {
 'network_device': {'xrvr-1':{
                     'address': '172.16.131.122',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'xrvr-2':{
                     'address': '172.16.131.121',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'xrvr-3':{
                     'address': '172.16.131.120',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'},
                    'xrvr-4':{
                     'address': '172.16.131.123',
                     'port': 830,
                     'password': 'cisco',
                     'username': 'cisco'}},
 'odl_server': {'address': '192.168.255.4',
                'port': 8181,
                'password': 'admin',
                'username': 'admin'}}
