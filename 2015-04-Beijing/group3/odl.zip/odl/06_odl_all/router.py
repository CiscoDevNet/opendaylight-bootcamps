#!/usr/bin/env python
# -*- coding: utf-8 -*-
# by yangxufeng.zhao

from __future__ import print_function as _print_function
from importlib import import_module
from pydoc import plain
from pydoc import render_doc as doc
import os
from urllib import quote_plus
from basics.interpreter import sys_exit
from basics.acl import acl_create_port_grant, inventory_acl, _error_message
from basics.odl_http import odl_http_post,odl_http_delete, odl_http_get


def add__acl(device_name):
    _acl_url_template = 'config/opendaylight-inventory:nodes/node/%s/yang-ext:mount/Cisco-IOS-XR-ipv4-acl-cfg:ipv4-acl-and-prefix-list/'

    _acl_content_template = '''{
  "Cisco-IOS-XR-ipv4-acl-cfg:accesses": {
    "access": [
      {
        "access-list-name": "ODL",
        "access-list-entries": {
          "access-list-entry": [
            {
              "sequence-number": 10,
              "source-network": {
                "source-wild-card-bits": "0.255.255.255",
                "source-address": "10.0.2.0"
              },
              "next-hop": {
                "next-hop-1": {
                  "next-hop": "10.0.0.30"
                },
                "next-hop-type": "regular-next-hop"
              },
              "grant": "permit"
            }
          ]
        }
      }
    ]
  }
}'''
    # device_name = 'xrvr-1'
    url_suffix = _acl_url_template % quote_plus(device_name)
    request_content = _acl_content_template
    response = odl_http_post(url_suffix, 'application/json', request_content, expected_status_code=[204, 409])
    if response.status_code != 204:
        raise Exception(_error_message(response.json()))

def del_acl(device_name):
    pass


def assert_acl_exist(device_name, acl_name):
    _acl_url_template = 'config/opendaylight-inventory:nodes/node/%s/yang-ext:mount/Cisco-IOS-XR-ipv4-acl-cfg:ipv4-acl-and-prefix-list/accesses/access/%s/'

    url_suffix = _acl_url_template % (quote_plus(device_name), quote_plus(acl_name))
    response = odl_http_get(url_suffix, 'application/json', expected_status_code=[200, 404])
    return response.status_code == 200

if __name__ == '__main__':
    add__acl('xrvr-1')