#!/usr/bin/env python2.7


"""the main function to detect the link failure and flow."""


from __future__ import print_function
import settings
from basics import topology
import cdp
import interface_monitor
import router
import acl

base_url = "http://192.168.255.4:8181"

def clear():
    """ clear the environment. """
    # 1. unmount all the devices
    mounted_list = topology.mounted_nodes()
    
    while mounted_list:
        print("mounted nodes:", topology.mounted_nodes())
        for dev in mounted_list:
            topology.dismount(dev)
        mounted_list = topology.mounted_nodes()
    print("all cleared in the environment!")       

def prepare():
    """ prepare for the environment """
    # 1. mount the device and check if the device is mounted
    unmounted_nodes = topology.unmounted_nodes()
    
    while unmounted_nodes:
        for dev in unmounted_nodes:
            device_config = settings.config['network_device'][dev]
            topology.mount(dev,
                           device_config['address'],
                           device_config['port'],
                           device_config['username'],
                           device_config['password'])
            unmounted_nodes = topology.unmounted_nodes()
    
    # 2. sleep for a while to wait all the devices coming up
    import time
    time.sleep(30)
    print("connected nodes:", topology.connected_nodes())


def main():
    print('config.network_devices:  ', settings.config['network_device'].keys())
#     clear()
#     prepare()
    cdp.setCdpStatus(True)
    print(interface_monitor.get_status("xrvr-3", "gigabitethernet0/0/0/2"))
    
    # add an acl to redirect host1 flow to the upper link
    router.add__acl("xrvr-1")
    acl.bind_acl("xrvr-1", "ODL", "gigabitEthernet 0/0/0/1")
    while True:
        if interface_monitor.get_status("xrvr-3", "gigabitethernet0/0/0/2") == "down":
            import time
            time.sleep(5)
            print("interface gigabitethernet0/0/0/2 down!")
            # TODO: when port down,change the routing policy
            pass
    
    
    
if __name__ == "__main__":
    main()
