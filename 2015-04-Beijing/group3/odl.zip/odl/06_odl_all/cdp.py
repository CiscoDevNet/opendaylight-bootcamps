#!/usr/bin/env python2.7

# Copyright 2015 Cisco Systems, Inc.
# 
# Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
# the License. You may obtain a copy of the License at
# 
# http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
# an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the License.


from __future__ import print_function
from basics import topology
from basics import odl_http
import json


def cdpRequestJSON(status):
    request_content = {
                       "Cisco-IOS-XR-cdp-cfg:cdp":{"enable": status}
                       }
    return json.dumps(request_content)

def setCdpStatus(status):
    # 1. enable CDP to all connected nodes
    __url_put_cdp = "config/opendaylight-inventory:nodes/node/{device}/yang-ext:mount/Cisco-IOS-XR-cdp-cfg:cdp/"
    connected_list = topology.connected_nodes()
    try:
        if connected_list:
            for dev in connected_list:
                odl_http.odl_http_put(__url_put_cdp.format(device = dev), 'application/json', cdpRequestJSON(status), expected_status_code=200)
    except:
        print("can't set CDP status")
        raise
