# Adding RPC api's to the YANG model and ToasterImpl

- purpose is to add RPC  api definitions to the toaster.yang file
- the RPCs java methods are implemented in toaster-impl/..../ToasterImpl.java
- restconf can be used to “call” the RPC api's
- the RPC methods in ToasterImpl.java are empty, they simply log a message for now, next chapter we implement them
