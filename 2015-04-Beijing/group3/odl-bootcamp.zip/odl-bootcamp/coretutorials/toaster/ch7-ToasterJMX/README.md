# Add JMX access to ToasterImpl.java

- purpose is to add jconcole management Runtime MX Bean access
- introduce management RPC's in toaster-impl-config.yang
- implement the JMX rpc's in ToasterImpl.java
