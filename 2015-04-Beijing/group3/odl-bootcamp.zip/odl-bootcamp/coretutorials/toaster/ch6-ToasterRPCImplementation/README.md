# Implement the RPC methods in ToasterImpl, add Notifications to toaster.yang and ToasterImpl

- purpose is to add actually implement the RPC java methods in ToasterImpl.java 
- restconf can be used to “call” the RPC api's
- introduce notifications to toaster.yang and ToasterImpl.java
