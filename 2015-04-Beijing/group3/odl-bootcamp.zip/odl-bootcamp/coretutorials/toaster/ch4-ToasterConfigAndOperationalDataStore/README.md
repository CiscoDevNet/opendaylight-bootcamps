# Write transactions to the config and operation date store using sync and async writes

- purpose is to show how to write to the data store programmatically in java
- two writes are performed, one to the operational data store, and the other to the config data store
- synchronous and asynchronous transactional database writes are illustrated
