package org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.hello.impl.rev141210;

public final class $YangModelBindingProvider implements org.opendaylight.yangtools.yang.binding.YangModelBindingProvider {

    public org.opendaylight.yangtools.yang.binding.YangModuleInfo getModuleInfo() {
        return $YangModuleInfoImpl.getInstance();
    }
}
