mdmerge -o ../doc/generated/en/01_register_nodes.md ../doc/src/en/01_register_nodes.md
mdmerge -o ../doc/generated/es/01_register_nodes.md ../doc/src/es/01_register_nodes.md

mdmerge -o ../doc/generated/en/02_interface_names.md ../doc/src/en/02_interface_names.md
mdmerge -o ../doc/generated/es/02_interface_names.md ../doc/src/es/02_interface_names.md

