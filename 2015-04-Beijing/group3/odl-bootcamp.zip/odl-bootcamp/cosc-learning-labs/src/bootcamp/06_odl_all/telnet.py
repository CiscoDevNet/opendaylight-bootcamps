#!/usr/bin/env python2.7

# Copyright 2015 Cisco Systems, Inc.
# 
# Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
# the License. You may obtain a copy of the License at
# 
# http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
# an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the License.


from __future__ import print_function
from basics import topology
from basics import odl_http
import json


def do_telnet(Host, username, password, finish, commands):  
    import telnetlib  
   
    # connect to telnet  
    tn = telnetlib.Telnet(Host, port=23, timeout=10)  
    tn.set_debuglevel(2)  
       
    tn.read_until('Username: ')  
    tn.write(username + '\n')  
      
    tn.read_until('Password: ')  
    tn.write(password + '\n')  
        
    tn.read_until(finish)  
    for command in commands:
        tn.write('%s\n' % command)
        tn.read_until(finish) 
    
#     tn.read_until(finish)  
    tn.close() # tn.write('exit\n')  
  
if __name__=='__main__':  
    Host = '172.16.131.122'
    username = 'admin'
    password = 'admin'
    finish = '#' 
    commands = ['show ip route']  
    do_telnet(Host, username, password, finish, commands)      
    
    
    
    