Enumere los nombres de los interfaces de Ethernet para cada dispositivo de la red.

<<(../../../src/learning_lab/02_interface_names.py)