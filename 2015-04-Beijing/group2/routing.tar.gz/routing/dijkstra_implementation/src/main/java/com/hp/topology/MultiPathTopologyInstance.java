package com.hp.topology;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;

import com.hp.routing.BroadcastTree;
import com.hp.routing.CostRoute;
import com.hp.routing.Link;
import com.hp.routing.NodePortTuple;
import com.hp.routing.Route;
import com.hp.routing.RouteId;

class LRUHashMap<K, V> extends LinkedHashMap<K, V> {

	private static final long serialVersionUID = 1L;

	private final int capacity;

	public LRUHashMap(int capacity) {
		super(capacity + 1, 0.75f, true);
		this.capacity = capacity;
	}

	protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
		return size() > capacity;
	}

}

public class MultiPathTopologyInstance extends TopologyInstance {
	public static final Integer defaultKNum = 2;
	public static final Double maxPercent = 2.0;
	protected Integer kNum;

	protected LRUHashMap<RouteId, CostRoute> pathcache;
	protected LRUHashMap<CostRoute, List<Path>> multiPathcache;

	public MultiPathTopologyInstance() {
		super();
		pathcache = new LRUHashMap<RouteId, CostRoute>(PATH_CACHE_SIZE);
		multiPathcache = new LRUHashMap<CostRoute, List<Path>>(PATH_CACHE_SIZE);
		// linkCost = new ConcurrentHashMap<Link, Integer>();
		kNum = defaultKNum;
	}

	public MultiPathTopologyInstance(Map<Long, Set<Short>> switchPorts,
			Map<NodePortTuple, Set<Link>> switchPortLinks,
			Set<NodePortTuple> broadcastDomainPorts) {
		super(switchPorts, switchPortLinks, broadcastDomainPorts);
		pathcache = new LRUHashMap<RouteId, CostRoute>(PATH_CACHE_SIZE);
		multiPathcache = new LRUHashMap<CostRoute, List<Path>>(PATH_CACHE_SIZE);
		// linkCost = new ConcurrentHashMap<Link, Integer>();
		kNum = defaultKNum;
	}

	public MultiPathTopologyInstance(Map<Long, Set<Short>> switchPorts,
			Set<NodePortTuple> blockedPorts,
			Map<NodePortTuple, Set<Link>> switchPortLinks,
			Set<NodePortTuple> broadcastDomainPorts,
			Set<NodePortTuple> tunnelPorts) {
		super(switchPorts, blockedPorts, switchPortLinks, broadcastDomainPorts,
				tunnelPorts);
		pathcache = new LRUHashMap<RouteId, CostRoute>(PATH_CACHE_SIZE);
		multiPathcache = new LRUHashMap<CostRoute, List<Path>>(PATH_CACHE_SIZE);
		// linkCost = new ConcurrentHashMap<Link, Integer>();
		kNum = defaultKNum;
	}

	@Override
	public void calculateShortestPathTreeInClusters() {
		linkCost.clear();
		pathcache.clear();
		destinationRootedTrees.clear();
		multiPathcache.clear();

		int tunnel_weight = switchPorts.size() + 1;

		for (NodePortTuple npt : tunnelPorts) {
			if (switchPortLinks.get(npt) == null)
				continue;
			for (Link link : switchPortLinks.get(npt)) {
				if (link == null)
					continue;
				linkCost.put(link, tunnel_weight);
			}
		}

		for (Long node : cluster.links.keySet()) {
			BroadcastTree tree = dijkstra(cluster, node, linkCost, true);
			destinationRootedTrees.put(node, tree);
		}

	}

	protected List<Route> getRoutes(long srcId, short srcPort, long dstId,
			short dstPort) {
		List<Route> result = new ArrayList<Route>();
		// Return null the route source and desitnation are the
		// same switchports.
		if (!(srcId == dstId && srcPort == dstPort)) {
			List<Route> routes;
			if (srcId != dstId) {
				routes = getRoutes(srcId, dstId);
			} else {
				// On the same switch, add only a null route.
				routes = new ArrayList<Route>();
				routes.add(null);
			}
			for (Route r : routes) {
				List<NodePortTuple> nptList;
				NodePortTuple npt;
				if (r != null) {
					nptList = new ArrayList<NodePortTuple>(r.getPath());
				} else {
					nptList = new ArrayList<NodePortTuple>();
				}
				npt = new NodePortTuple(srcId, srcPort);
				nptList.add(0, npt); // add src port to the front
				npt = new NodePortTuple(dstId, dstPort);
				nptList.add(npt); // add dst port to the end

				RouteId id = new RouteId(srcId, dstId);
				r = new Route(id, nptList);
				result.add(r);
			}
		}
		return result;
	}

	public  List<Route> getRoutes(long srcId, long dstId) {
		List<Route> routes = new ArrayList<Route>();
		List<Path> paths = null;
		CostRoute shortestRoute = getRoute(srcId, dstId);
		System.out.println("the srcSwitch "+srcId+" to dstSwitch "
		    +dstId+" shortestPath:"+shortestRoute.getPath());
		/*if (multiPathcache.containsKey(shortestRoute)) {
			paths = multiPathcache.get(shortestRoute);
		} else {*/
			paths = getMultiPaths(shortestRoute);
			//multiPathcache.put(shortestRoute, paths);
		//}
		for (Path path : paths) {
			routes.add(path.getCostRoute());
		}
		return routes;
	}

	protected List<Path> getMultiPaths(CostRoute shortestRoute) {
		List<Path> paths = new ArrayList<Path>();
		PriorityQueue<Path> pathQ = new PriorityQueue<Path>();
		Path spath = new Path(shortestRoute);
		paths.add(spath);
		Path path;

		while (paths.size() < kNum) {
			int devNodeIndex = getDevNodeIndex(paths);
			Long firstNode = paths.get(paths.size() - 1).getPath().get(0)
					.getSrc();
			List<Link> linkPath = paths.get(paths.size() - 1).getPath();

			if (cluster.links.containsKey(firstNode)) {
				// 对于从dev点前一个点开始，到终点的前一个点，寻找
				for (int i = devNodeIndex; i < linkPath.size(); i++) {
					Map<Long, Set<Link>> removedNodes = new HashMap<Long, Set<Link>>();
					Path np = new Path();
					// 删除sv上的点，顺便加入新路径
					for (int j = 0; j < i; j++) {
						Link link = linkPath.get(j);
						if (linkCost.get(link) == null) {
							np.addLink(link, 1);
						} else {
							np.addLink(link, linkCost.get(link));
						}
						removedNodes.put(link.getSrc(), cluster.getLinks()
								.remove(link.getSrc()));
					}
					// 擦除从v出发的边
					if (i == devNodeIndex) {
						for (int j = paths.size() - 1; j >= 0; j--) {
							if (paths.get(j).getPath().size() > i) {
								if (paths.get(j).getPath().get(i).getSrc() == linkPath
										.get(i).getSrc()) {
									boolean sameBranch = true;
									for (int k = i - 1; k >= 0; k--) {
										if (!paths.get(j).getPath().get(k)
												.equals(linkPath.get(k))) {
											sameBranch = false;
											break;
										}
									}
									if (sameBranch) {
										cluster.getLinks()
												.get(paths.get(j).getPath()
														.get(i).getDst())
												.remove(paths.get(j).getPath()
														.get(i));
									}
								}
							}
						}
						// int k = paths.size() - 1;
						// while(k >= 0 &&
						// paths.get(k).getPath().get(i).getSrc() ==
						// linkPath.get(i).getSrc()) {
						// c.getLinks().get(paths.get(k).getPath().get(i).getDst()).remove(paths.get(k).getPath().get(i));
						// k--;
						// }
					} else {
						cluster.getLinks().get(linkPath.get(i).getDst())
								.remove(linkPath.get(i));
					}
					// 做最短路，找出从v到t的最短路
					BroadcastTree bt = dijkstra(cluster,
							linkPath.get(linkPath.size() - 1).getDst(),
							linkCost, true);
					// 恢复从v出发的边
					if (i == devNodeIndex) {
						for (int j = paths.size() - 1; j >= 0; j--) {
							if (paths.get(j).getPath().size() > i) {
								if (paths.get(j).getPath().get(i).getSrc() == linkPath
										.get(i).getSrc()) {
									boolean sameBranch = true;
									for (int k = i - 1; k >= 0; k--) {
										if (!paths.get(j).getPath().get(k)
												.equals(linkPath.get(k))) {
											sameBranch = false;
											break;
										}
									}
									if (sameBranch) {
										cluster.getLinks()
												.get(paths.get(j).getPath()
														.get(i).getDst())
												.add(paths.get(j).getPath()
														.get(i));
									}
								}
							}
						}
						// int k = paths.size() - 1;
						// while(k >= 0 &&
						// paths.get(k).getPath().get(i).getSrc() ==
						// linkPath.get(i).getSrc()) {
						// c.getLinks().get(paths.get(k).getPath().get(i).getDst()).add(paths.get(k).getPath().get(i));
						// k--;
						// }
					} else {
						cluster.getLinks().get(linkPath.get(i).getDst())
								.add(linkPath.get(i));
					}
					// 恢复sv上的点
					for (Long k : removedNodes.keySet()) {
						cluster.getLinks().put(k, removedNodes.get(k));
					}
					Map<Long, Link> nexthoplinks = bt.getLinks();
					Long srcId = linkPath.get(i).getSrc();
					Long dstId = linkPath.get(linkPath.size() - 1).getDst();
					boolean connected = false;
					if ((nexthoplinks != null)
							&& (nexthoplinks.get(srcId) != null)) {
						connected = true;
						while (srcId != dstId) {
							Link link = nexthoplinks.get(srcId);
							if (linkCost.get(link) == null) {
								np.addLink(link, 1);
							} else {
								np.addLink(link, linkCost.get(link));
							}
							srcId = link.getDst();
						}
					}
					if (connected) {
						pathQ.add(np);
					}
				}
			}

			if (pathQ.peek() == null) {
				break;
			} else {
				path = pathQ.poll();
				if (path.getCost() <= spath.getCost() * maxPercent) {
					paths.add(path);
				} else {
					break;
				}
			}
		}
		// if(true) {
		// System.out.println("Paths FROM " +
		// shortestRoute.getPath().get(0).getNodeId() + " TO " +
		// shortestRoute.getPath().get(shortestRoute.getPath().size() -
		// 1).getNodeId() + " : " + paths.size());
		// }
		return paths;
	}

	public void deleteLink(Link l) {
		NodePortTuple srcPort = new NodePortTuple(l.getSrc(), l.getSrcPort());
		cluster.deleteLinksByPort(srcPort);
		NodePortTuple dstPort = new NodePortTuple(l.getDst(), l.getDstPort());
		cluster.deleteLinksByPort(dstPort);
	}

	public void addLink(Link l) {
		cluster.addLink(l);
	}

	/**
	 * 找到yum算法中的dev点（由于Path中存储的是Link，则dev点一定对应于Dst点）
	 * 
	 * @param paths
	 * @return
	 */
	private Integer getDevNodeIndex(List<Path> paths) {
		Integer devNodeIndex = null;
		if (paths.size() > 0) {
			if (paths.size() == 1) {
				devNodeIndex = 0;
			} else {
				Path pi = paths.get(paths.size() - 1);
				devNodeIndex = 0;
				for (int i = 0; i < paths.size() - 1; i++) {
					Path po = paths.get(i);
					for (int j = 0; j < po.getPath().size(); j++) {
						if (!pi.getPath().get(j).equals(po.getPath().get(j))) {
							if (j > devNodeIndex) {
								devNodeIndex = j;
							}
							break;
						}
					}
				}
				// Path po = paths.get(paths.size() - 2);
				// ListIterator<Link> iti = pi.getPath().listIterator();
				// ListIterator<Link> ito = po.getPath().listIterator();
				// devNodeIndex = -1;
				// while(iti.hasNext()) {
				// devNodeIndex ++;
				// Link li = iti.next();
				// if(ito.hasNext()) {
				// Link lo = ito.next();
				// if(!li.equals(lo)) {
				// break;
				// }
				// } else {
				// break;
				// }
				// }
			}
		}
		return devNodeIndex;
	}

	@Override
	protected CostRoute getRoute(long srcId, long dstId) {
		RouteId id = new RouteId(srcId, dstId);
		CostRoute result = null;
		if (pathcache.containsKey(id)) {
			result = pathcache.get(id);
		} else {
			result = buildroute(id, srcId, dstId);
			pathcache.put(id, result);
		}
		/*
		 * if (log.isTraceEnabled()) { log.trace("getRoute: {} -> {}", id,
		 * result); }
		 */
		return result;
	}

	public void resetTopoCache() {
		pathcache = new LRUHashMap<RouteId, CostRoute>(PATH_CACHE_SIZE);
		multiPathcache = new LRUHashMap<CostRoute, List<Path>>(PATH_CACHE_SIZE);
		destinationRootedTrees = new HashMap<Long, BroadcastTree>();
		clusterBroadcastTrees = new HashMap<Long, BroadcastTree>();
		clusterBroadcastNodePorts = new HashMap<Long, Set<NodePortTuple>>();
	}

	@Override
	protected CostRoute buildroute(RouteId id, long srcId, long dstId) {
		Route route = super.buildroute(id, srcId, dstId);
		Integer cost = 0;
		Integer w = 1;
		CostRoute result = null;

		if (linkCost != null && route != null) {
			Map<Long, Link> nexthoplinks = destinationRootedTrees.get(dstId)
					.getLinks();
			if ((nexthoplinks != null) && (nexthoplinks.get(srcId) != null)) {
				while (srcId != dstId) {
					Link link = nexthoplinks.get(srcId);
					if (linkCost == null || linkCost.get(link) == null) {
						w = 1;
					} else {
						w = linkCost.get(link);
					}
					srcId = nexthoplinks.get(srcId).getDst();
					cost += w;
				}
			}
			result = new CostRoute(route, cost);
		}
		return result;
	}

	public Integer getkNum() {
		return kNum;
	}

	public void setkNum(Integer kNum) {
		this.kNum = kNum;
	}

	// public void calculateLinkCost(Map<String, InterfaceStatistics>
	// ifNameIfStatMap, IFloodlightProviderService floodlightProvider) {
	// Map<Link, Double> linkTraffic = new HashMap<Link, Double>();
	// Map<Long, IOFSwitch> switches = floodlightProvider.getSwitches();
	// for(Set<Link> links : switchPortLinks.values()) {
	// for(Link l : links) {
	// if(!linkTraffic.containsKey(l)) {
	// if(switches.containsKey(l.getSrc())) {
	// IOFSwitch sw = switches.get(l.getSrc());
	// OFPhysicalPort port = sw.getPort(l.getSrcPort());
	// if(ifNameIfStatMap.containsKey(port.getName())) {
	// InterfaceStatistics ifStat = ifNameIfStatMap.get(port.getName());
	// linkTraffic.put(l, ifStat.getIfOutOctets());
	// }
	// }
	// }
	// }
	// }
	// Double totalCost = 0.0;
	// for(Double c : linkTraffic.values()) {
	// totalCost += c;
	// }
	// for(Link l : linkTraffic.keySet()) {
	// linkCost.put(l, 1 + ((Double) (costBase.doubleValue() *
	// linkTraffic.get(l) / totalCost)).intValue());
	// }
	// }

}
