package com.hp.routing;




public class NodePortTuple {
    public long nodeId; // switch DPID
    public short portId; // switch port id

    /**
     * Creates a NodePortTuple
     * @param nodeId The DPID of the switch
     * @param portId The port of the switch
     */
    public NodePortTuple(long nodeId, short portId) {
        this.nodeId = nodeId;
        this.portId = portId;
    }

    public NodePortTuple(long nodeId, int portId) {
        this.nodeId = nodeId;
        this.portId = (short) portId;
    }

    public long getNodeId() {
        return nodeId;
    }
    public void setNodeId(long nodeId) {
        this.nodeId = nodeId;
    }

    public short getPortId() {
        return portId;
    }
    public void setPortId(short portId) {
        this.portId = portId;
    }
    
    public String toString() {
        return "[sw=" + nodeId + ", port=" + new Short(portId) + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (nodeId ^ (nodeId >>> 32));
        result = prime * result + portId;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        NodePortTuple other = (NodePortTuple) obj;
        if (nodeId != other.nodeId)
            return false;
        if (portId != other.portId)
            return false;
        return true;
    }
    
    /**
     * API to return a String value formed wtih NodeID and PortID
     * The portID is a 16-bit field, so mask it as an integer to get full
     * positive value
     * @return
     */
    public String toKeyString() {
        return (nodeId+ "|" + (portId & 0xffff));
    }
}
