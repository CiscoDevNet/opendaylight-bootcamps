package com.hp.routing;

import java.util.List;


public class CostRoute extends Route {
	
	private Integer cost;

	public CostRoute(Long src, Long dst) {
		super(src, dst);
		cost = 0;
	}

	public CostRoute(RouteId id, List<NodePortTuple> switchPorts) {
		super(id, switchPorts);
		cost = 0;
	}
	
	public CostRoute(RouteId id, List<NodePortTuple> switchPorts, Integer cost) {
		super(id, switchPorts);
		this.cost = cost;
	}
	
	public CostRoute(Route route, Integer cost) {
		super(route.id, route.switchPorts);
		this.cost = cost;
	}

	public Integer getCost() {
		return cost;
	}

	public void setCost(Integer cost) {
		this.cost = cost;
	}
}
