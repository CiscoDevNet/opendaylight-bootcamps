package com.hp.topology;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.hp.topology.*;
import com.hp.routing.CostRoute;
import com.hp.routing.Link;
import com.hp.routing.NodePortTuple;
import com.hp.routing.RouteId;

public class Path implements Comparable<Path> {

	private List<Link> path;
	private Integer cost;
	
	public Path() {
		this.path = new ArrayList<Link>();
		this.cost = 0;
	}
	
	public Path(CostRoute shortestRoute) {
		this();
		Iterator<NodePortTuple> it = shortestRoute.getPath().iterator();
		NodePortTuple nptSrc, nptDst;
		while(it.hasNext()) {
			nptSrc = it.next();
			if(!it.hasNext()) {
				break;
			}
			nptDst = it.next();
			Link link = new Link(nptSrc.nodeId, nptSrc.portId, nptDst.nodeId, nptDst.portId);
			path.add(link);
		}
		this.cost = shortestRoute.getCost();
	}
	
	public CostRoute getCostRoute() {
		CostRoute cr = null;
		if(path.size() > 0) {
			RouteId id = new RouteId(path.get(0).getSrc(), path.get(path.size() - 1).getDst());
			NodePortTuple npt;
			LinkedList<NodePortTuple> switchPorts = new LinkedList<NodePortTuple>();
			for(Link link : path) {
				npt = new NodePortTuple(link.getSrc(), link.getSrcPort());
                switchPorts.addLast(npt);
                npt = new NodePortTuple(link.getDst(), link.getDstPort());
                switchPorts.addLast(npt);
			}
			cr = new CostRoute(id, switchPorts, cost);
		}
		return cr;
	}

	@Override
	public int compareTo(Path o) {
		if(this.cost == o.cost) {
			int devIndex = -1;
			for(int i = 0; i < this.path.size() && i < o.path.size(); i++) {
				if(!this.path.get(i).equals(o.path.get(i))) {
					devIndex = i;
					break;
				}
			}
			if(devIndex >= 0) {
				if(this.path.get(devIndex).getSrc() != o.path.get(devIndex).getSrc()) {
					return ((Long)this.path.get(devIndex).getSrc()).compareTo(o.path.get(devIndex).getSrc());
				} else if(this.path.get(devIndex).getDst() != o.path.get(devIndex).getDst()) {
					return ((Long)this.path.get(devIndex).getDst()).compareTo(o.path.get(devIndex).getDst());
				} else if(this.path.get(devIndex).getSrcPort() != o.path.get(devIndex).getSrcPort()) {
					return ((Short)this.path.get(devIndex).getSrcPort()).compareTo(o.path.get(devIndex).getSrcPort());
				} else {
					return ((Short)this.path.get(devIndex).getDstPort()).compareTo(o.path.get(devIndex).getDstPort());
				}
			} else {
				return this.path.size() - o.path.size();
			}
		}
        return this.cost - o.cost;
	}
	
	public void addLink(Link link, Integer cost) {
		this.path.add(link);
		this.cost += cost;
	}

	public List<Link> getPath() {
		return path;
	}
	
	public Integer getCost() {
		return cost;
	}
	
	public String toString() {
		String a = "";
		for(int i = 0; i < path.size(); i++) {
			Link link = path.get(i);
			a += String.valueOf(link.getSrc()) + "->";
		}
		a += String.valueOf(path.get(path.size() - 1).getDst());
		return "[" + a + "]";
//		return path.toString();
	}
	
	@Override
    public int hashCode() {
        final int prime = 5352;
        int result = 1;
        result = prime * result + ((cost == null) ? 0 : cost.hashCode());
        result = prime * result + ((path == null) ? 0 : path.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Path other = (Path) obj;
        if (cost == null) {
            if (other.cost != null)
                return false;
        } else if (!cost.equals(other.cost))
            return false;
        if (path == null) {
            if (other.path != null)
                return false;
        } else if (!path.equals(other.path))
            return false;
        return true;
    }
}

