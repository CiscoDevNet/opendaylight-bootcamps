#!/bin/python3

from sys import argv
import requests
import json

from naar.create_instance import listInstance
from naar.cfg_vport import listVport

def setupRoute(iid, route, vid):
    url = "http://localhost:8181/restconf/operations/naar-cfg:cfg-route"
    headers = { "Content-Type" : "application/json" }
    content = { "input" : { "out-vport-id" : vid, "route" : route, "instance-id" : iid }}
    content = json.dumps(content)
    response = requests.post(url, headers = headers, data = content, auth = ("admin", "admin"))

    if (response.status_code != 200):
        print(response.json())

if __name__ == '__main__':
    if (len(argv) < 4):
        print("Usage: setup_route.py <instance-id> <ip-prefix> <vport-id>")
    else:
        iid = argv[1]
        route = argv[2]
        vid = argv[3]
        setupRoute(iid, route, vid)
        listInstance()
        listVport()
