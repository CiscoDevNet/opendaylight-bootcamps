#!/bin/python3

from sys import argv
import requests
import json

def configureVport(vid, nid, iid):
    url = "http://localhost:8181/restconf/operations/naar-cfg:cfg-vport"
    headers = { "Content-Type" : "application/json" }
    content = { "input" : { "vport-id" : vid, "node-id" : nid, "interface-id" : iid }}
    content = json.dumps(content)
    response = requests.post(url, headers = headers, data = content, auth = ("admin", "admin"))

    if (response.status_code != 200):
        print(response.json())

def listVport():
    url = "http://localhost:8181/restconf/operational/naar-oper:vports"
    response = requests.get(url, auth = ("admin", "admin"))
    print(response.json())

if __name__ == '__main__':
    if (len(argv) < 4):
        print("Usage: cfg_vport.py <vport-id> <p-node-id> <p-interface-id>")
    else:
        vid = argv[1]
        nid = argv[2]
        iid = argv[3]
        configureVport(vid, nid, iid)
        listVport()
