#!/bin/python3

from sys import argv
import requests
import json

from naar.create_instance import listInstance
from naar.cfg_vport import listVport

def bindVport(iid, vid):
    url = "http://localhost:8181/restconf/operations/naar-cfg:bind-vport"
    headers = { "Content-Type" : "application/json" }
    content = { "input" : { "vport-id" : vid, "instance-id" : iid }}
    content = json.dumps(content)
    response = requests.post(url, headers = headers, data = content, auth = ("admin", "admin"))

    if (response.status_code != 200):
        print(response.json())

if __name__ == '__main__':
    if (len(argv) < 3):
        print("Usage: bind-vport.py <instance-id> <vport-id>")
    else:
        iid = argv[1]
        vid = argv[2]
        bindVport(iid, vid)
        listInstance()
        listVport()
