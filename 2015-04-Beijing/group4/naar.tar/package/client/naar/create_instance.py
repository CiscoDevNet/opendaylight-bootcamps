#!/bin/python3

from sys import argv
import requests
import json

def createInstance(iid):
    url = "http://localhost:8181/restconf/operations/naar-cfg:create-instance"
    headers = { "Content-Type" : "application/json" }
    content = { "input" : { "instance-id" : iid }}
    content = json.dumps(content)
    response = requests.post(url, headers = headers, data = content, auth = ("admin", "admin"))

    if (response.status_code != 200):
        print(response.json())

def listInstance():
    url = "http://localhost:8181/restconf/operational/naar-oper:instances"
    response = requests.get(url, auth = ("admin", "admin"))
    print(response.json())

if __name__ == '__main__':
    if (len(argv) < 2):
        print("Usage: create_instance.py <instance-id>")
    else:
        iid = argv[1]
        createInstance(iid)
        listInstance()
