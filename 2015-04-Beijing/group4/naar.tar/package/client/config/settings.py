#!/bin/python3

server = {
    "ip" : "127.0.0.1",
    "port" : "8181"
}
