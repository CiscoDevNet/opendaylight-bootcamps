package org.opendaylight.bootcamp.impl;

import java.io.BufferedReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.ietf.inet.types.rev100924.IpPrefix;

import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.rev150422.NaarId;

public class FakeConf {

    private static final Logger LOG = LoggerFactory.getLogger(FakeConf.class);

    public void setupVPath(NaarId src, NaarId dst, IpPrefix route, Integer vlan, boolean firstRun) {
        LOG.info("Build vpath from {} to {} for route {}: vlan {}", src, dst, route, vlan);
        //TODO call python scripts to actually setup the path

        String cmd[] = {
            "python3.4",
            "helper/mdsal.py",
            src.getValue(),
            dst.getValue(),
            new String(route.getValue()),
            vlan.toString()
        };
        try {
            Process process = Runtime.getRuntime().exec(cmd);
        } catch (Exception e) {
            LOG.warn("Failed to execute commands: {}", e);
        }
    }

    public void configVport(NaarId vport, String router, String inf) {
        LOG.info("configure vport {}: <{}, {}>", vport, router, inf);

        String cmd[] = {
            "python3.4",
            "helper/mdsal.py",
            vport.getValue(),
            router,
            inf
        };
        try {
            Process process = Runtime.getRuntime().exec(cmd);
        } catch (Exception e) {
            LOG.warn("Failed to execute commands: {}", e);
        }
     }
}
