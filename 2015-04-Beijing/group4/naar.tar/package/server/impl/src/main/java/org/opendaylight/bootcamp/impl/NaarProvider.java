/*
 * Copyright(C) ODL Bootcamp Beijing Group No.4 and others.  All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package org.opendaylight.bootcamp.impl;

import org.opendaylight.controller.sal.binding.api.BindingAwareBroker.ProviderContext;
import org.opendaylight.controller.sal.binding.api.BindingAwareBroker.RpcRegistration;
import org.opendaylight.controller.sal.binding.api.BindingAwareProvider;

import org.opendaylight.controller.md.sal.binding.api.DataBroker;
import org.opendaylight.controller.md.sal.binding.api.ReadWriteTransaction;
import org.opendaylight.controller.md.sal.binding.api.WriteTransaction;
import org.opendaylight.controller.md.sal.common.api.data.LogicalDatastoreType;

import com.google.common.base.Optional;
import com.google.common.util.concurrent.AsyncFunction;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.Future;

import org.opendaylight.yangtools.yang.binding.InstanceIdentifier;
import org.opendaylight.yangtools.yang.binding.RpcService;
import org.opendaylight.yangtools.yang.common.RpcResult;
import org.opendaylight.yangtools.yang.common.RpcResultBuilder;

import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.ietf.inet.types.rev100924.IpPrefix;

import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.rev150422.NaarId;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.oper.rev150422.Instances;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.oper.rev150422.instances.Instance;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.oper.rev150422.instances.InstanceBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.oper.rev150422.instances.InstanceKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.oper.rev150422.instances.instance.Vroute;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.oper.rev150422.instances.instance.VrouteBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.oper.rev150422.instances.instance.VrouteKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.oper.rev150422.instances.instance.VportIndex;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.oper.rev150422.instances.instance.VportIndexBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.oper.rev150422.instances.instance.VportIndexKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.oper.rev150422.InstancesBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.oper.rev150422.vports.Vport;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.oper.rev150422.vports.VportBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.oper.rev150422.vports.VportKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.oper.rev150422.Vports;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.oper.rev150422.VportsBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.cfg.rev150422.NaarCfgService;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.cfg.rev150422.BindVportInput;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.cfg.rev150422.CfgVportInput;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.cfg.rev150422.CfgRouteInput;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.naar.cfg.rev150422.CreateInstanceInput;

public class NaarProvider implements NaarCfgService, BindingAwareProvider, AutoCloseable {

    protected static final class Message {
        public static final String FAIL_TO_BIND
                    = "Failed to bind vport {} to instance {}";

        public static final String FAIL_TO_BIND_NOVPORT
                    = FAIL_TO_BIND + ": vport doesn't exist";

        public static final String FAIL_TO_BIND_VPORTBOUND
                    = FAIL_TO_BIND + ": vport is already bount to an instance";

        public static final String FAIL_TO_BIND_NOINSTANCE
                    = FAIL_TO_BIND + ": instance doesn't exist";
    };

    private static final Logger LOG = LoggerFactory.getLogger(NaarProvider.class);

    private FakeConf fconf = new FakeConf();

    private ProviderContext context = null;

    private DataBroker db = null;

    private RpcRegistration<NaarCfgService> rpcReg = null;

    public static final InstanceIdentifier<Instances> NAAR_OPER_INSTANCES
            = InstanceIdentifier.builder(Instances.class).build();

    public static final InstanceIdentifier<Vports> NAAR_OPER_VPORTS
            = InstanceIdentifier.builder(Vports.class).build();

    private int vlan = 0;

    private Integer generateVlanId() {
        vlan = vlan + 1;
        return new Integer(vlan);
    }

    private Instances emptyInstanceContainer() {
        return new InstancesBuilder().build();
    }

    private Vports emptyVportContainer() {
        return new VportsBuilder().build();
    }

    private void initializeNaaRService() {
        WriteTransaction tx = db.newWriteOnlyTransaction();

        tx.put(LogicalDatastoreType.OPERATIONAL, NAAR_OPER_INSTANCES, emptyInstanceContainer());
        tx.put(LogicalDatastoreType.OPERATIONAL, NAAR_OPER_VPORTS, emptyVportContainer());

        Futures.addCallback(tx.submit(), new FutureCallback<Void>() {
            @Override
            public void onSuccess(final Void result) {
                LOG.info("NaaR service successfully activated");
            }

            @Override
            public void onFailure(final Throwable t) {
                LOG.error("NaaR initialization failed: {}", t);
            }
        });
    }

    @Override
    public void onSessionInitiated(ProviderContext session) {
        LOG.info("NaarProvider Session Initiated");
        this.context = session;

        try {
            db = session.getSALService(DataBroker.class);
            rpcReg = session.addRpcImplementation(NaarCfgService.class, this);

            initializeNaaRService();
        } catch (Exception e) {
            LOG.warn("Failed to register rpc implementatoin");
            db = null;
            rpcReg = null;
        }
    }

    @Override
    public void close() throws Exception {
        LOG.info("NaarProvider Closed");
        if (rpcReg != null)
            rpcReg.close();
    }

    protected InstanceIdentifier<VportIndex> getInstanceVportIID(NaarId id, NaarId vid) {
        InstanceKey ik = new InstanceKey(id);
        VportIndexKey vik = new VportIndexKey(vid);

        InstanceIdentifier<VportIndex> iid = InstanceIdentifier.builder(Instances.class)
                                                .child(Instance.class, ik)
                                                .child(VportIndex.class, vik).build();
        return iid;
    }

    @Override
    public Future<RpcResult<Void>> bindVport(BindVportInput input) {
        LOG.info("Get bind-vport input {}", input);

        final NaarId id = input.getInstanceId();
        final NaarId vid = input.getVportId();

        final InstanceIdentifier<Instance> iIID = getInstanceIID(id);
        final InstanceIdentifier<Vport> vIID = getVportIID(vid);
        final InstanceIdentifier<VportIndex> viIID = getInstanceVportIID(id, vid);

        final ReadWriteTransaction rwt = db.newReadWriteTransaction();

        ListenableFuture<Optional<Vport>> readVportFuture
                = rwt.read(LogicalDatastoreType.OPERATIONAL, vIID);
        return Futures.transform(readVportFuture, new AsyncFunction<Optional<Vport>, RpcResult<Void>>() {
            @Override
            public ListenableFuture<RpcResult<Void>> apply(Optional<Vport> _vport) {
                if (!_vport.isPresent()) {
                    LOG.info(Message.FAIL_TO_BIND_NOVPORT, vid, id);
                    return RpcResultBuilder.<Void>failed().buildFuture();
                }
                final Vport vport = _vport.get();
                if (vport.getOwner() != null) {
                    LOG.info(Message.FAIL_TO_BIND_VPORTBOUND, vid, id);
                    return RpcResultBuilder.<Void>failed().buildFuture();
                }

                ListenableFuture<Optional<Instance>> readInstanceFuture
                        = rwt.read(LogicalDatastoreType.OPERATIONAL, iIID);
        
                return Futures.transform(readInstanceFuture, new AsyncFunction<Optional<Instance>, RpcResult<Void>>() {
                    @Override
                    public ListenableFuture<RpcResult<Void>> apply(Optional<Instance> _instance) {
                        if (!_instance.isPresent()) {
                            LOG.info(Message.FAIL_TO_BIND_VPORTBOUND, vid, id);
                            return RpcResultBuilder.<Void>failed().buildFuture();
                        }
                        Instance instance = _instance.get();

                        Vport _new = new VportBuilder(vport).setOwner(id).build();
                        VportIndex vidx = new VportIndexBuilder().setVportId(vid).build();

                        rwt.put(LogicalDatastoreType.OPERATIONAL, vIID, _new);
                        rwt.put(LogicalDatastoreType.OPERATIONAL, viIID, vidx);

                        if (instance.getVroute() != null) {
                            for (Vroute route: instance.getVroute()) {
                                fconf.setupVPath(vid, route.getDstVportId(), route.getRoute(), instance.getVlanId(), true);
                            }
                        }

                        Futures.addCallback(rwt.submit(), new FutureCallback<Void>() {
                            @Override
                            public void onSuccess(final Void result) {
                                LOG.info("Bind vport {} to instance {} successfully", vid, id);
                            }

                            @Override
                            public void onFailure(final Throwable t) {
                                LOG.info("Failed to bind vport {} to instance {}: {}", vid, id, t);
                            }
                        });
                        return RpcResultBuilder.<Void>success().buildFuture();
                    }
                });
            }
        });
    }

    protected InstanceIdentifier<Vroute> getInstanceVrouteIID(NaarId id, IpPrefix route) {
        InstanceKey ik = new InstanceKey(id);
        VrouteKey rk = new VrouteKey(route);

        InstanceIdentifier<Vroute> rIID = InstanceIdentifier.builder(Instances.class)
                                                .child(Instance.class, ik)
                                                .child(Vroute.class, rk).build();
        return rIID;
    }

    protected boolean routable(Instance instance, NaarId vport) {
        boolean _routable = false;
        if (instance.getVportIndex() == null) {
            return _routable;
        }
        for (VportIndex vidx: instance.getVportIndex()) {
            if (vport.equals(vidx.getVportId())) {
                _routable = true;
                break;
            }
        }
        return _routable;
    }

    @Override
    public Future<RpcResult<Void>> cfgRoute(CfgRouteInput input) {
        LOG.debug("Get cfgRoute input {}", input);

        final NaarId iid = input.getInstanceId();
        final IpPrefix route = input.getRoute();
        final NaarId vport = input.getOutVportId();

        final InstanceIdentifier<Instance> iIID = getInstanceIID(iid);
        final InstanceIdentifier<Vroute> rIID = getInstanceVrouteIID(iid, route);

        final ReadWriteTransaction rwt = db.newReadWriteTransaction();
        
        ListenableFuture<Optional<Instance>> readInstanceFuture
                    = rwt.read(LogicalDatastoreType.OPERATIONAL, iIID);
        
        return Futures.transform(readInstanceFuture, new AsyncFunction<Optional<Instance>, RpcResult<Void>>() {
            @Override
            public ListenableFuture<RpcResult<Void>> apply(Optional<Instance> _instance) {
                if (!_instance.isPresent()) {
                    return RpcResultBuilder.<Void>failed().buildFuture();
                }
                Instance instance = _instance.get();

                Vroute vroute = new VrouteBuilder()
                                        .setRoute(route)
                                        .setDstVportId(vport).build();

                if (!routable(instance, vport)) {
                    return RpcResultBuilder.<Void>failed().buildFuture();
                }
                for (VportIndex vidx: instance.getVportIndex()) {
                    if (vport.equals(vidx.getVportId()))
                        continue;
                    fconf.setupVPath(vidx.getVportId(), vport, route, instance.getVlanId(), true);
                }

                rwt.put(LogicalDatastoreType.OPERATIONAL, rIID, vroute);
                Futures.addCallback(rwt.submit(), new FutureCallback<Void>() {
                    @Override
                    public void onSuccess(final Void result) {
                        LOG.info("Successfully setup route {} --> {} for instance {}",
                                    route, vport, iid);
                    }

                    @Override
                    public void onFailure(Throwable t) {
                        LOG.info("Failed to setup route {} --> {} for instance {}: {}",
                                    route, vport, iid, t);
                    }
                });

                return RpcResultBuilder.<Void>success().buildFuture();
            }
        });
    }

    protected InstanceIdentifier<Vport> getVportIID(NaarId id) {
        VportKey vk = new VportKey(id);
        InstanceIdentifier<Vport> vid = InstanceIdentifier.builder(Vports.class)
                                            .child(Vport.class, vk).build();
        return vid;
    }

    @Override
    public Future<RpcResult<Void>> cfgVport(CfgVportInput input) {
        LOG.debug("Get input {}", input);

        final NaarId vid = input.getVportId();
        final String nid = input.getNodeId();
        final String nif = input.getInterfaceId();

        InstanceIdentifier<Vport> iid = getVportIID(vid);
        Vport vport = new VportBuilder(input).build();

        WriteTransaction tx = db.newWriteOnlyTransaction();
        tx.put(LogicalDatastoreType.OPERATIONAL, iid, vport);

        Futures.addCallback(tx.submit(), new FutureCallback<Void>() {
            @Override
            public void onSuccess(final Void result) {
                LOG.info("Vport {} is configured successfully", vid);
                fconf.configVport(vid, nid, nif);
            }

            @Override
            public void onFailure(Throwable t) {
                LOG.info("Failed to configure Vport {}: {}", vid, t);
            }
        });

        return RpcResultBuilder.<Void>success().buildFuture();
    }

    protected InstanceIdentifier<Instance> getInstanceIID(NaarId id) {
        InstanceKey ik = new InstanceKey(id);
        InstanceIdentifier<Instance> iid = InstanceIdentifier.builder(Instances.class)
                                            .child(Instance.class, ik).build();
        return iid;
    }

    @Override
    public Future<RpcResult<Void>> createInstance(CreateInstanceInput input) {
        LOG.debug("Get input {}", input);

        final NaarId id = input.getInstanceId();
        final InstanceIdentifier<Instance> iid = getInstanceIID(id);
        final ReadWriteTransaction rwt = db.newReadWriteTransaction();

        ListenableFuture<Optional<Instance>> readFuture
                    = rwt.read(LogicalDatastoreType.OPERATIONAL, iid);

        return Futures.transform(readFuture, new AsyncFunction<Optional<Instance>, RpcResult<Void>>() {
            @Override
            public ListenableFuture<RpcResult<Void>> apply(Optional<Instance> old) {
                if (old.isPresent()) {
                    return RpcResultBuilder.<Void>failed().buildFuture();
                }

                Integer vlan = generateVlanId();
                Instance instance = new InstanceBuilder()
                                            .setInstanceId(id)
                                            .setVlanId(vlan).build();
 
                rwt.put(LogicalDatastoreType.OPERATIONAL, iid, instance);

                Futures.addCallback(rwt.submit(), new FutureCallback<Void>() {
                    @Override
                    public void onSuccess(final Void result) {
                        LOG.info("Instance {} created", id);
                    }

                    @Override
                    public void onFailure(Throwable t) {
                        LOG.info("Failed to create instance {}: {}", id, t);
                    }
                });
                return RpcResultBuilder.<Void>success().buildFuture();
            }
        });
    }
}
