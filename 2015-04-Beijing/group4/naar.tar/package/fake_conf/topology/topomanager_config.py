config = {
 'network_device': ['iosxrv-1',
                    'iosxrv-2',
                    'iosxrv-3',
                    'iosxrv-4'
                    ],
 'odl_server': {'address': '192.168.255.5',
                'port': 8181,
                'password': 'admin',
                'username': 'admin'}
}
