#!/bin/python3.4

from sys import argv
import os

if __name__ == '__main__':
    os.system('echo {} > result'.format(argv))
