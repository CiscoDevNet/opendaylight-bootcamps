#!/bin/python3.4

from control.initenv import get_env, restore_env
import topomanager
import json
from sys import argv

def init():
    config = get_env()

    config["mdsal"] = {}
    config["mdsal"]["vpath"] = {}
    config["mdsal"]["vport"] = {}

    restore_env(config)


def config_vport(vport, router, interface):
    config = get_env()

    config['mdsal']['vport'][vport] = { 'vport' : vport, 'router' : router, 'nif' : interface }
    config['mdsal']['vpath'][vport] = {}

    restore_env(config)

def setup_vrf(prouter, vlan):
    router = prouter['router']
    interface = prouter['nif']
    print("setup vrf {} on <{}: {}>".format(vlan, router, interface))
    pass

def setup_vlan(src, dst, vlan):
    from_r = src['router']
    from_i = src['nif']
    to_r = dst['router']
    to_i = dst['nif']
    print("setup vlan {} between <{}: {}> and <{}: {}>".format(vlan, from_r, from_i, to_r, to_i))
    pass

def router_on_path(name, in_if, out_if):
    _in = { 'router' : name, 'nif' : in_if }
    _out = { 'router' : name, 'nif' : out_if }
    return { 'in' : _in, 'out' : _out }
 
def get_path(src, dst):
    config = get_env()

    g = topomanager.Graph()

    vport1 = config['mdsal']['vport'][src]
    vport2 = config['mdsal']['vport'][dst]

    path = g.calc_path(vport1['router'], vport2['router'])

    _path = []
    name = vport1['router']
    in_if = vport1['nif']
    for r in path:
        _path.append(router_on_path(name, in_if, r['localinterface']))
        in_if = r['endinterface']
        name = r['name']
    _path.append(router_on_path(vport2['router'], in_if, vport2['nif']))

    return _path

def setup_path(src, dst, vlan):
    config = get_env()
    
    path = get_path(src, dst)

    if dst in config['mdsal']['vpath'][src]:
        return

    for p in path:
        setup_vrf(p['in'], vlan)
        setup_vrf(p['out'], vlan)

    for i in range(1, len(path)):
        setup_vlan(path[i-1]['out'], path[i]['in'], vlan)

    config['mdsal']['vpath'][src][dst] = vlan

    restore_env(config)

def setup_vrf_route(prouter, route, vlan):
    pass

def add_route(src, dst, route, vlan):
    setup_path(src, dst, vlan)

    config = get_env()
    path = get_path(src, dst)

    for p in path:
        setup_vrf_route(p['in'], route, vlan)
        setup_vrf_route(p['out'], route, vlan)

    restore_env(config)

def test():
    config_vport('vp1', 'iosxrv-2', 'GigabitEthernet0/0/0/2')
    config_vport('vp2', 'iosxrv-3', 'GigabitEthernet0/0/0/1')
    setup_path('vp1', 'vp2', 1)

    print(get_env()['mdsal'])

if __name__ == '__main__':
    if (len(argv) == 1):
        init()
    elif (len(argv) == 2):
        print(get_env()['mdsal'])
    elif (len(argv) == 4):
        config_vport(argv[1], argv[2], argv[3])
    elif (len(argv) == 5):
        add_route(argv[1], argv[2], argv[3], argv[4])
    else:
        test()

