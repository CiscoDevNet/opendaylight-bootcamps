# ODL vRouter

## Background 

In a provider network where its enterprise users want to connect their private
networks together while isolating the traffic from each other, we would like to
implement such an application to suffice the requirement. 

## Solution

We provide a *virtual router* application for the users of the provider network.
The users can then create a *virtual router*, connect their private networks to
it and finally configure static routes.

According to the discussion this morning, we would use VRF to manage the virtual
networks and the ingress port for every private network would be configured
manually (probably in a static file).

## Contacts (In alphabetical order)

Kai GAO `<gaok12@mails.tsinghua.edu.cn>`
Yingbin WANG `<yingbin.wangyb@alibaba-inc.com>`
Yu ZHANG `<zhangyu09@baidu.com>`
