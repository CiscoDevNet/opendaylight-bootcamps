#!/usr/bin/env python3.4

''' init env:
    xrv node: name, ip
    user: name, interface, vport
    xrv topology: node, interface
'''

from __future__ import print_function as _print_function
import json
import os
from control.baseenv import get_default_config

def alloc_unused_vrf_id(config):
    if len(config['vrf']['unused']) == 0:
        return None

    id = config['vrf']['unused'][0]
    del config['vrf']['unused'][0]

    return id

def free_vrf_id(config, vrf_id):
    config['vrf']['unused'].append(int(vrf_id))

if __name__ == "__main__":
    config = get_default_config()

    vrf_id = alloc_unused_vrf_id(config)
    print(vrf_id)
    print(config)

    free_vrf_id(config, vrf_id)
    print(config)

