#!/usr/bin/env python3.4

''' direct api
'''

from __future__ import print_function as _print_function
import json
import os
import getopt
import sys
from control.initenv import init_env
import vrerrorcode
from vrerrorcode import print_error_info
from control import vrouter
from control import vport

def usage():
    print("Common Usage: --action $action")
    print("Action Usage:")
    print("    init")
    print("    create_vourter:  --user $user --vrouter $name")
    print("    destroy_vourter: --user $user --vrouter $name")
    print("    list_vourter:    --user $user")
    print("    bind_vport:      --user $user --vrouter $name --vport $name")
    print("    unbind_vport:    --user $user --vrouter $name --vport $name")
    print("    list_vport:      --user $user")
    print("    add_route:       --user $user --vrouter $name --dest $dest --mask $mask --vport $name")
    print("    delete_route:    --user $user --vrouter $name --dest $dest --mask $mask")
    print("    list_route:      --user $user --vrouter $name")
    sys.exit(-1)

if __name__ == "__main__":

    action = None
    user = None
    vr_name = None
    vport_name = None
    dest = None
    mask = None

    try:
        opts, args = getopt.getopt(sys.argv[1:], "", ['action=', 'user=', 'vrouter=', 'vport=', 'dest=', 'mask=' ])
        for a, o in opts:
            if a  == '--action':
                action = o
            if a  == '--user':
                user = o
            if a  == '--vrouter':
                vr_name = o
            if a  == '--vport':
                vport_name = o
            if a  == '--dest':
                dest = o
            if a  == '--mask':
                mask = o

    except getopt.GetoptError, err:
        print(err)
        exit(-1)

    if not action:
        usage()

    if action == "init":
        init_env()
    elif action == "create_vrouter":
        if not user or not vr_name:
            usage()
        vrouter.create_vrouter(user, vr_name)
    elif action == "destroy_vrouter":
        if not user or not vr_name:
            usage()
        vrouter.destroy_vrouter(user, vr_name)
    elif action == "list_vrouter":
        if not user:
            usage()
        vrouter.list_vrouter(user)
    elif action == "bind_vport":
        if not user or not vr_name or not vport_name:
            usage()
        vport.bind_vport(user, vr_name, vport_name)
    elif action == "unbind_vport":
        if not user or not vr_name or not vport_name:
            usage()
        vport.unbind_vport(user, vr_name, vport_name)
    elif action == "list_vport":
        if not user:
            usage()
        vport.list_vport(user)
    elif action == "add_route":
        if not user or not vr_name or not vport_name or not dest or not mask:
            usage()
        vrouter.add_vrouter_route(user, vr_name, dest, mask, vport_name)
    elif action == "delete_route":
        if not user or not vr_name or not dest or not mask:
            usage()
        vrouter.delete_vrouter_route(user, vr_name, dest, mask)
    elif action == "list_route":
        if not user or not vr_name:
            usage()
        vrouter.list_vrouter_route(user, vr_name)
    else:
        usage()

