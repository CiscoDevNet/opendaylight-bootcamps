#!/usr/bin/env python3.4

''' vrouter ops
'''

from __future__ import print_function as _print_function
import json
import os
from control.initenv import init_env, get_env, restore_env
import vrerrorcode
from vrerrorcode import print_error_info
import odl.odl_vrf as odl_vrf
import odl.odl_if as odl_if
import model.m_vrf as m_vrf
from topomanager import Graph

def create_vrouter(user, vr_name):
    config = get_env()

    if config['user'].get(user) is None:
        error = vrerrorcode.USER_NOT_EXIST
        print_error_info(error)
        return error

    #TODO: need to check vrouter user
    if config['vrouter'].get(vr_name) is not None:
        error = vrerrorcode.VROUTER_EXIST
        print_error_info(error)
        return error

    vrf_id = m_vrf.alloc_unused_vrf_id(config)
    if vrf_id is None:
        error = vrerrorcode.VRF_ID_ALLOC_FAILED
        print_error_info(error)
        return error

    vrf_name = "VRF-%s" % vrf_id
    vlan_id = vrf_id

    config['vrouter'][vr_name] = {}
    config['vrouter'][vr_name]['reserved_subnet'] = "10.10.0.0/16"
    config['vrouter'][vr_name]['vrf_id'] = vrf_id
    config['vrouter'][vr_name]['vrf_name'] = vrf_name
    config['vrouter'][vr_name]['vlan_id'] = vlan_id
    config['vrouter'][vr_name]['user'] = user
    config['vrouter'][vr_name]['route'] = []
    config['vrouter'][vr_name]['vport'] = []
    config['vrouter'][vr_name]['subnet'] = [
    {
        'subnet': '10.10.0.0',
        'mask': 30,
        'netmask': '255.255.255.252',
        'src_ip': '10.10.0.1',
        'dst_ip': '10.10.0.2'
    },
    {
        'subnet': '10.10.0.4',
        'mask': 30,
        'netmask': '255.255.255.252',
        'src_ip': '10.10.0.5',
        'dst_ip': '10.10.0.6'
    },
    {
        'subnet': '10.10.0.8',
        'mask': 30,
        'netmask': '255.255.255.252',
        'src_ip': '10.10.0.9',
        'dst_ip': '10.10.0.10'
    },
    {
        'subnet': '10.10.0.12',
        'mask': 30,
        'netmask': '255.255.255.252',
        'src_ip': '10.10.0.13',
        'dst_ip': '10.10.0.14'
    },
    {
        'subnet': '10.10.0.16',
        'mask': 30,
        'netmask': '255.255.255.252',
        'src_ip': '10.10.0.17',
        'dst_ip': '10.10.0.18'
    },
    {
        'subnet': '10.10.0.20',
        'mask': 30,
        'netmask': '255.255.255.252',
        'src_ip': '10.10.0.21',
        'dst_ip': '10.10.0.22'
    },
    {
        'subnet': '10.10.0.23',
        'mask': 30,
        'netmask': '255.255.255.252',
        'src_ip': '10.10.0.24',
        'dst_ip': '10.10.0.25'
    },
    {
        'subnet': '10.10.0.27',
        'mask': 30,
        'netmask': '255.255.255.252',
        'src_ip': '10.10.0.28',
        'dst_ip': '10.10.0.29'
    },
    ]

    restore_env(config)
    return vrerrorcode.SUCCESS

def destroy_vrouter(user, vr_name):
    config = get_env()

    if config['user'].get(user) is None:
        error = vrerrorcode.USER_NOT_EXIST
        print_error_info(error)
        return error

    #TODO: need to check vrouter user
    if config['vrouter'].get(vr_name) is None:
        error = vrerrorcode.VROUTER_NOT_EXIST
        print_error_info(error)
        return error

    if len(config['vrouter'].get(vr_name).get('vport')) != 0:
        error = vrerrorcode.VROUTER_HAS_VPORT
        print_error_info(error)
        return error

    if len(config['vrouter'].get(vr_name).get('route')) != 0:
        error = vrerrorcode.VROUTER_HAS_ROUTE
        print_error_info(error)
        return error

    m_vrf.free_vrf_id(config, config['vrouter'][vr_name]['vrf_id'])
    del config['vrouter'][vr_name]

    restore_env(config)
    return vrerrorcode.SUCCESS

def list_vrouter(user):
    config = get_env()

    vlist = []
    for vr_name in config['vrouter'].keys():
        if config['vrouter'][vr_name]['user'] == user:
            print(config['vrouter'][vr_name])
            vlist.append(config['vrouter'][vr_name])

    return vlist

def add_vrouter_route(user, vr_name, dest, mask, vport):
    config = get_env()

    if config['user'].get(user) is None:
        error = vrerrorcode.USER_NOT_EXIST
        print_error_info(error)
        return error

    #TODO: need to check vrouter user
    if config['vrouter'].get(vr_name) is None:
        error = vrerrorcode.VROUTER_NOT_EXIST
        print_error_info(error)
        return error

    #TODO: need to check vport user
    if config['vport'].get(vport) is None:
        error = vrerrorcode.VPORT_NOT_EXIST
        print_error_info(error)
        return error

    if config['vport'].get(vport).get('vrouter') is None:
        error = vrerrorcode.VPORT_IS_UNBINDED
        print_error_info(error)
        return error

    #TODO: check same route

    for from_vport in config['vrouter'][vr_name]['vport']:
        if from_vport == vport:
            continue

        graph = Graph(config['node'].keys())
        path = graph.calc_path(config['vport'][from_vport]['node_name'], config['vport'][vport]['node_name'])
        print("graph calc path:" + config['vport'][from_vport]['node_name'] + " " + config['vport'][vport]['node_name'])
        print(path)
        if path is None:
            print("get path failed")
            return vrerrorcode.IERR

        src_node = config['vport'][from_vport]['node_name']
        for connect in path:
            print("show connect")
            print(connect)
            src_if = connect['localinterface']
            dst_node = connect['name']
            dst_if = connect['endinterface']

            cn1 = "%s-%s-%s" % (src_node, dst_node, config['vrouter'][vr_name]['vrf_name'])
            cn2 = "%s-%s-%s" % (dst_node, src_node, config['vrouter'][vr_name]['vrf_name'])

            connect = None
            if config['connect'].get(cn1) is not None:
                connect = config['connect'].get(cn1)
            if config['connect'].get(cn2) is not None:
                connect = config['connect'].get(cn2)

            if connect is None:
                print("connect info not exist")
                return vrerrorcode.IERR

            nexthop = None
            if connect['src_node'] == src_node:
                nexthop = connect['subnet']['dst_ip']
            if connect['src_node'] == dst_node:
                nexthop = connect['subnet']['src_ip']

            if nexthop is None:
                print("connect info not match")
                return vrerrorcode.IERR

            res = odl_vrf.add_route(config, src_node, config['vrouter'][vr_name]['vrf_name'], dest, mask, nexthop)
            print(res)

            src_node = dst_node

    node = config['vport'][vport]['node_name']
    subnet = config['vport'][vport]['subnet']
    res = odl_vrf.add_route(config, node, config['vrouter'][vr_name]['vrf_name'], dest, mask, subnet['dst_ip'])
    print(res)

    config['vrouter'][vr_name]['route'].append({
        'dest': dest,
        'mask': mask,
        'vport': vport
    })

    restore_env(config)
    return vrerrorcode.SUCCESS

def delete_vrouter_route(user, vr_name, dest, mask):
    config = get_env()

    if config['user'].get(user) is None:
        error = vrerrorcode.USER_NOT_EXIST
        print_error_info(error)
        return error

    #TODO: need to check vrouter user
    if config['vrouter'].get(vr_name) is None:
        error = vrerrorcode.VROUTER_NOT_EXIST
        print_error_info(error)
        return error

    my_route = None
    for route in config['vrouter'][vr_name]['route']:
        if route['dest'] == dest and route['mask'] == mask:
            my_route = route

    if my_route is None:
        error = vrerrorcode.ROUTE_NOT_EXIST
        print_error_info(error)
        return error

    vport = my_route['vport']
    for from_vport in config['vrouter'][vr_name]['vport']:
        if from_vport == vport:
            continue

        graph = Graph(config['node'].keys())
        path = graph.calc_path(config['vport'][from_vport]['node_name'], config['vport'][vport]['node_name'])
        print("graph calc path:" + config['vport'][from_vport]['node_name'] + " " + config['vport'][vport]['node_name'])
        print(path)
        if path is None:
            print("get path failed")
            return vrerrorcode.IERR

        src_node = config['vport'][from_vport]['node_name']
        for connect in path:
            print("show connect")
            print(connect)
            src_if = connect['localinterface']
            dst_node = connect['name']
            dst_if = connect['endinterface']

            res = odl_vrf.delete_route(config, src_node, config['vrouter'][vr_name]['vrf_name'], dest, mask)
            print(res)

            src_node = dst_node

    node = config['vport'][vport]['node_name']
    res = odl_vrf.delete_route(config, node, config['vrouter'][vr_name]['vrf_name'], dest, mask)
    print(res)

    config['vrouter'][vr_name]['route'].remove(my_route)

    restore_env(config)
    return vrerrorcode.SUCCESS

def list_vrouter_route(user, vr_name):
    config = get_env()

    if config['vrouter'][vr_name] is None:
        return None

    vlist = []
    if config['vrouter'][vr_name]['user'] == user:
        print(config['vrouter'][vr_name]['route'])
        return config['vrouter'][vr_name]['route']
    return None

if __name__ == "__main__":
    init_env()

    user = "wyb1"
    vr_name = "vrouter1"

    from control.vport import bind_vport, unbind_vport

    list_vrouter(user)
    create_vrouter(user, vr_name)
    list_vrouter(user)

    bind_vport(user, vr_name, "vport1")
    bind_vport(user, vr_name, "vport4")

    list_vrouter_route(user, vr_name)
    add_vrouter_route(user, vr_name, "10.11.0.0", 16, "vport1")
    list_vrouter_route(user, vr_name)
    delete_vrouter_route(user, vr_name, "10.11.0.0", 16)
    list_vrouter_route(user, vr_name)

    unbind_vport(user, vr_name, "vport1")
    unbind_vport(user, vr_name, "vport4")

    destroy_vrouter(user, vr_name)
    list_vrouter(user)

