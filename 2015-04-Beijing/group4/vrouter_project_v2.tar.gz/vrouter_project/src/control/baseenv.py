#!/usr/bin/env python3.4

''' base env
'''

from __future__ import print_function as _print_function
import json
import os

config_file_name = "init.json"

def get_default_config():
    config_path = os.environ["CONFIGPATH"]
    configfile = open('%s/%s' % (config_path, config_file_name), 'r')
    config = json.load(configfile)
    configfile.close()
    return config

if __name__ == "__main__":
    config = get_default_config()
    print(config)

