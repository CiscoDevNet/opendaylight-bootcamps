#!/usr/bin/env python3.4

''' topology
'''

from __future__ import print_function as _print_function
import json
import os
from control.baseenv import get_default_config

def get_topology(config):
    return None

def get_path(config, from_node, to_node):
    return None

if __name__ == "__main__":
    config = get_default_config()
    get_topology(config)
    get_path(config, "iosxrv-1", "iosxrv-4")

