#!/usr/bin/env python3.4

''' init env:
    xrv node: name, ip
    user: name, interface, vport
    xrv topology: node, interface
'''

from __future__ import print_function as _print_function
import json
import os
from control.baseenv import get_default_config
from topomanager import Graph

tmp_file_name = "/tmp/vrouter.json"

def init_env():
    config = get_default_config()

    graph = Graph(config['node'].keys())
    topo = graph.get_topology()
    print("get topology")
    print(topo)
    if topo is not None:
        config['topology'] = topo

    tofile = open(tmp_file_name, 'w')
    outstr = json.dumps(config, ensure_ascii = False)
    tofile.write(outstr.strip().encode('utf-8'))
    tofile.close()

def get_env():
    configfile = open(tmp_file_name, 'r')
    config = json.load(configfile)
    configfile.close()

    return config

def restore_env(config):
    tofile = open(tmp_file_name, 'w')
    outstr = json.dumps(config, ensure_ascii = False)
    tofile.write(outstr.strip().encode('utf-8'))
    tofile.close()

if __name__ == "__main__":
    init_env()
    config = get_env()
    print(config)
    restore_env(config)

