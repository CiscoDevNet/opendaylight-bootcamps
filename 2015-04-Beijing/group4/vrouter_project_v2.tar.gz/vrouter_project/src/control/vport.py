#!/usr/bin/env python3.4

''' vport ops
'''

from __future__ import print_function as _print_function
import json
import os
from control.initenv import init_env, get_env, restore_env
from control.topology import get_path
import odl.odl_vrf as odl_vrf
import odl.odl_if as odl_if
import vrerrorcode
from vrerrorcode import print_error_info
from topomanager import Graph

def bind_vport(user, vr_name, vport):
    config = get_env()

    if config['user'].get(user) is None:
        error = vrerrorcode.USER_NOT_EXIST
        print_error_info(error)
        return error

    #TODO: need to check vrouter user
    if config['vrouter'].get(vr_name) is None:
        error = vrerrorcode.VROUTER_NOT_EXIST
        print_error_info(error)
        return error

    #TODO: need to check vport user
    if config['vport'].get(vport) is None:
        error = vrerrorcode.VPORT_NOT_EXIST
        print_error_info(error)
        return error

    if config['vport'].get(vport).get('vrouter') is not None:
        error = vrerrorcode.VPORT_IS_BINDED
        print_error_info(error)
        return error

    for to_vport in config['vrouter'][vr_name]['vport']:
        if to_vport == vport:
            continue

        graph = Graph(config['node'].keys())
        path = graph.calc_path(config['vport'][vport]['node_name'], config['vport'][to_vport]['node_name'])
        print("graph calc path:" + config['vport'][vport]['node_name'] + " " + config['vport'][to_vport]['node_name'])
        print(path)
        if path is None:
            print("get path failed")
            return vrerrorcode.IERR

        src_node = config['vport'][vport]['node_name']
        for connect in path:
            print("show connect")
            print(connect)
            src_if = connect['localinterface']
            dst_node = connect['name']
            dst_if = connect['endinterface']

            cn1 = "%s-%s-%s" % (src_node, dst_node, config['vrouter'][vr_name]['vrf_name'])
            cn2 = "%s-%s-%s" % (dst_node, src_node, config['vrouter'][vr_name]['vrf_name'])

            if config['connect'].get(cn1) is not None or config['connect'].get(cn2) is not None:
                continue

            if len(config['vrouter'][vr_name]['subnet']) == 0:
                print("vrouter subnet full")
                return vrerrorcode.IERR

            subnet = config['vrouter'][vr_name]['subnet'][0]
            del config['vrouter'][vr_name]['subnet'][0]

            res = odl_vrf.create_vrf(config, src_node, config['vrouter'][vr_name]['vrf_name'])
            print(res)
            res = odl_vrf.create_vrf(config, dst_node, config['vrouter'][vr_name]['vrf_name'])
            print(res)
            res = odl_if.create_vlan_if(config, src_node, src_if, subnet['src_ip'], subnet['netmask'], config['vrouter'][vr_name]['vlan_id'], config['vrouter'][vr_name]['vrf_name'])
            print(res)
            res = odl_if.create_vlan_if(config, dst_node, dst_if, subnet['dst_ip'], subnet['netmask'], config['vrouter'][vr_name]['vlan_id'], config['vrouter'][vr_name]['vrf_name'])
            print(res)

            config['connect'][cn1] = {
                'src_node': src_node,
                'src_if': src_if,
                'dst_node': dst_node,
                'dst_if': dst_if,
                'subnet': subnet,
                'vrouter': vr_name
            }
            src_node = dst_node

    subnet = config['vrouter'][vr_name]['subnet'][0]
    del config['vrouter'][vr_name]['subnet'][0]

    src_node = config['vport'][vport]['node_name']
    src_if = config['vport'][vport]['if_name']
    res = odl_vrf.create_vrf(config, src_node, config['vrouter'][vr_name]['vrf_name'])
    print(res)
    res = odl_if.clear_if(config, src_node, src_if)
    print(res)
    res = odl_if.bind_vrf(config, src_node, src_if, config['vrouter'][vr_name]['vrf_name'])
    print(res)
    res = odl_if.bind_ipv4addr(config, src_node, src_if, subnet['src_ip'], subnet['netmask'])
    print(res)

    config['vrouter'][vr_name]['vport'].append(vport)
    config['vport'][vport]['vrouter'] = vr_name
    config['vport'][vport]['subnet'] = subnet

    restore_env(config)

    return vrerrorcode.SUCCESS

def unbind_vport(user, vr_name, vport):
    config = get_env()

    if config['user'].get(user) is None:
        error = vrerrorcode.USER_NOT_EXIST
        print_error_info(error)
        return error

    #TODO: need to check vrouter user
    if config['vrouter'].get(vr_name) is None:
        error = vrerrorcode.VROUTER_NOT_EXIST
        print_error_info(error)
        return error

    #TODO: need to check vport user
    if config['vport'].get(vport) is None:
        error = vrerrorcode.VPORT_NOT_EXIST
        print_error_info(error)
        return error

    if config['vport'].get(vport).get('vrouter') is None:
        error = vrerrorcode.VPORT_IS_UNBINDED
        print_error_info(error)
        return error

    #TODO: need to check vport not route ref cnt

    #TODO: need to diff path and vrf change, then destroy change
    for to_vport in config['vrouter'][vr_name]['vport']:
        if to_vport == vport:
            continue

        graph = Graph(config['node'].keys())
        path = graph.calc_path(config['vport'][vport]['node_name'], config['vport'][to_vport]['node_name'])
        print("graph calc path:" + config['vport'][vport]['node_name'] + " " + config['vport'][to_vport]['node_name'])
        print(path)
        if path is None:
            print("get path failed")
            return vrerrorcode.IERR

        src_node = config['vport'][vport]['node_name']
        for connect in path:
            print("show connect")
            print(connect)
            src_if = connect['localinterface']
            dst_node = connect['name']
            dst_if = connect['endinterface']

            cn1 = "%s-%s-%s" % (src_node, dst_node, config['vrouter'][vr_name]['vrf_name'])
            cn2 = "%s-%s-%s" % (dst_node, src_node, config['vrouter'][vr_name]['vrf_name'])

            connect = None
            if config['connect'].get(cn1) is not None:
                connect = config['connect'].get(cn1)
            if config['connect'].get(cn2) is not None:
                connect = config['connect'].get(cn2)

            if connect is None:
                continue

            res = odl_if.clear_if(config, src_node, src_if, config['vrouter'][vr_name]['vlan_id'])
            print(res)
            res = odl_if.clear_if(config, dst_node, dst_if, config['vrouter'][vr_name]['vlan_id'])
            print(res)
            res = odl_if.destroy_vlan_if(config, src_node, src_if, config['vrouter'][vr_name]['vlan_id'])
            print(res)
            res = odl_if.destroy_vlan_if(config, dst_node, dst_if, config['vrouter'][vr_name]['vlan_id'])
            print(res)
            res = odl_vrf.destroy_vrf(config, src_node, config['vrouter'][vr_name]['vrf_name'])
            print(res)
            res = odl_vrf.destroy_vrf(config, dst_node, config['vrouter'][vr_name]['vrf_name'])
            print(res)

            config['vrouter'][vr_name]['subnet'].append(connect['subnet'])
            if config['connect'].get(cn1) is not None:
                del config['connect'][cn1]
            if config['connect'].get(cn2) is not None:
                del config['connect'][cn2]

            src_node = dst_node

    src_node = config['vport'][vport]['node_name']
    src_if = config['vport'][vport]['if_name']
    res = odl_if.clear_if(config, src_node, src_if)
    print(res)

    subnet = config['vport'][vport]['subnet']
    config['vrouter'][vr_name]['vport'].remove(vport)
    del config['vport'][vport]['vrouter']
    del config['vport'][vport]['subnet']

    restore_env(config)

    return vrerrorcode.SUCCESS

def list_vport(user):
    config = get_env()

    if config['user'].get(user) is None:
        error = vrerrorcode.USER_NOT_EXIST
        print_error_info(error)
        return error

    vlist = {}
    for vport_name in config['vport'].keys():
        if config['vport'][vport_name]['user_name'] != user:
            continue

        if config['vport'][vport_name].get('subnet') is not None:
            config['vport'][vport_name]['gw_ip'] = config['vport'][vport_name]['subnet']['src_ip']
            config['vport'][vport_name]['local_ip'] = config['vport'][vport_name]['subnet']['dst_ip']

        print("vport name [" + vport_name + "]")
        print(config['vport'][vport_name])
        vlist[vport_name] = (config['vport'][vport_name])
    return vlist

if __name__ == "__main__":
    init_env()

    user = "wyb1"
    vr_name = "vrouter1"

    from control.vrouter import create_vrouter, destroy_vrouter

    create_vrouter(user, vr_name)

    list_vport(user)
    bind_vport(user, vr_name, "vport1")
    bind_vport(user, vr_name, "vport4")
    list_vport(user)
    unbind_vport(user, vr_name, "vport1")
    unbind_vport(user, vr_name, "vport4")
    list_vport(user)

    destroy_vrouter(user, vr_name)

