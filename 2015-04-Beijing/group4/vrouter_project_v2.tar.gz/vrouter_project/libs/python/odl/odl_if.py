#!/usr/bin/env python3.4

''' interface operations:
    create vlan if
    destroy vlan if
    if bind ipv4 address 
    if unbind ipv4 address
    if bind vrf 
    clear if info: ipv4 address, vrf, ...
'''

from __future__ import print_function as _print_function
from lxml import etree
from collections import namedtuple
from basics.odl_http import odl_http_get, odl_http_post, odl_http_put, odl_http_delete
import time

wait_times = 5

_url_inventory = 'config/opendaylight-inventory:nodes'
_url_inventory_node = _url_inventory + '/node/%s'

_url_if = _url_inventory_node + '/yang-ext:mount/Cisco-IOS-XR-ifmgr-cfg:interface-configurations'
_url_if_node = _url_if + '/interface-configuration/act/%s'

_url_ipv4addr = _url_if_node + '/ipv4-network/addresses/primary'

_request_content_create_vlan_if_template = '''<?xml version="1.0"?>
<interface-configuration xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-ifmgr-cfg">
<active>act</active>
<interface-name>%s</interface-name>
<interface-mode-non-physical>default</interface-mode-non-physical>
<ipv4-network xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-ipv4-io-cfg">
<addresses>
<primary>
<address>%s</address>
<netmask>%s</netmask>
</primary>
</addresses>
</ipv4-network>
<vlan-sub-configuration xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-l2-eth-infra-cfg">
<vlan-identifier>
<first-tag>%s</first-tag>
<vlan-type>vlan-type-dot1q</vlan-type>
</vlan-identifier>
</vlan-sub-configuration>
</interface-configuration>
'''

_request_content_create_vlan_if_vrf_template = '''<?xml version="1.0"?>
<interface-configuration xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-ifmgr-cfg">
<active>act</active>
<interface-name>%s</interface-name>
<interface-mode-non-physical>default</interface-mode-non-physical>
<ipv4-network xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-ipv4-io-cfg">
<addresses>
<primary>
<address>%s</address>
<netmask>%s</netmask>
</primary>
</addresses>
</ipv4-network>
<vlan-sub-configuration xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-l2-eth-infra-cfg">
<vlan-identifier>
<first-tag>%s</first-tag>
<vlan-type>vlan-type-dot1q</vlan-type>
</vlan-identifier>
</vlan-sub-configuration>
<vrf xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-infra-rsi-cfg">%s</vrf>
</interface-configuration>
'''

_request_content_bind_ipv4addr_template = '''<?xml version="1.0"?>
<interface-configuration xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-ifmgr-cfg">
<active>act</active>
<interface-name>%s</interface-name>
<ipv4-network xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-ipv4-io-cfg">
<addresses>
<primary>
<address>%s</address>
<netmask>%s</netmask>
</primary>
</addresses>
</ipv4-network>
</interface-configuration>
'''

_request_content_bind_vrf_template = '''<?xml version="1.0"?>
<interface-configuration xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-ifmgr-cfg">
<active>act</active>
<interface-name>%s</interface-name>
<vrf xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-infra-rsi-cfg">%s</vrf>
</interface-configuration>
'''

_request_content_clear_if_template = '''<?xml version="1.0"?>
<interface-configuration xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-ifmgr-cfg">
<active>act</active>
<interface-name>%s</interface-name>
<description>interface</description>
<cdp xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-cdp-cfg">
<enable />
</cdp>
</interface-configuration>
'''

_request_content_clear_vlan_if_template = '''<?xml version="1.0"?>
<interface-configuration xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-ifmgr-cfg">
<active>act</active>
<interface-name>%s</interface-name>
<interface-mode-non-physical>default</interface-mode-non-physical>
<vlan-sub-configuration xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-l2-eth-infra-cfg">
<vlan-identifier>
<first-tag>%s</first-tag>
<vlan-type>vlan-type-dot1q</vlan-type>
</vlan-identifier>
</vlan-sub-configuration>
</interface-configuration>
'''

def create_vlan_if(config, node_name, if_name, ip, netmask, vlan_id, vrf_name=None):
    print("create vlan if")
    request_url = _url_if % (node_name)
    tmp_if_name = "%s.%s" % (if_name, vlan_id)
    if vrf_name is None:
        request_content = _request_content_create_vlan_if_template % (tmp_if_name, ip, netmask, vlan_id)
    else:
        request_content = _request_content_create_vlan_if_vrf_template % (tmp_if_name, ip, netmask, vlan_id, vrf_name)
    print(request_url)
    print(request_content)
    res = None
    for a in range(0,wait_times):
        try:
            res = odl_http_post(config, request_url, 'application/xml', request_content, expected_status_code=[204, 409])
            time.sleep(1)
            if res.status_code in [204, 409]:
                break
        except Exception as e:
            print(e)
            time.sleep(1)
    return res

def destroy_vlan_if(config, node_name, if_name, vlan_id):
    print("destroy vlan if")
    tmp_if_name = "%s.%s" % (if_name.replace("/", "%2F"), vlan_id)
    request_url = _url_if_node %(node_name, tmp_if_name)
    print(request_url)
    res = None
    for a in range(0,wait_times):
        try:
            res = odl_http_delete(config, request_url, 'application/xml', expected_status_code=[200, 404])
            time.sleep(1)
            if res.status_code in [204, 404]:
                break
        except Exception as e:
            print(e)
            time.sleep(1)
    return res

def list_if(config, node_name):
    print("list if")
    request_url = _url_if %(node_name)
    print(request_url)
    res = None
    for a in range(0,wait_times):
        try:
            res = odl_http_get(config, request_url, 'application/json')
            time.sleep(1)
            if res.status_code in [200]:
                break
        except Exception as e:
            print(e)
            time.sleep(1)
    return res

def bind_ipv4addr(config, node_name, if_name, ip, netmask, vlan_id=None):
    print("bind ipv4 addr")
    request_url = _url_if % (node_name)
    tmp_if_name = if_name
    if vlan_id is not None:
        tmp_if_name = "%s.%s" % (tmp_if_name, vlan_id)
    request_content = _request_content_bind_ipv4addr_template % (tmp_if_name, ip, netmask)
    print(request_url)
    print(request_content)
    res = None
    for a in range(0,wait_times):
        try:
            res = odl_http_post(config, request_url, 'application/xml', request_content, expected_status_code=204)
            time.sleep(1)
            if res.status_code in [204]:
                break
        except Exception as e:
            print(e)
            time.sleep(1)
    return res

def unbind_ipv4addr(config, node_name, if_name, vlan_id=None):
    print("unbind ipv4 addr")
    tmp_if_name = if_name.replace("/", "%2F")
    if vlan_id is not None:
        tmp_if_name = "%s.%s" % (tmp_if_name, vlan_id)
    request_url = _url_ipv4addr % (node_name, tmp_if_name)
    print(request_url)
    res = None
    for a in range(0,wait_times):
        try:
            res = odl_http_delete(config, request_url, 'application/xml', expected_status_code=[200, 404])
            time.sleep(1)
            if res.status_code in [200, 404]:
                break
        except Exception as e:
            print(e)
            time.sleep(1)
    return res

def bind_vrf(config, node_name, if_name, vrf_name, vlan_id=None):
    print("bind vrf")
    request_url = _url_if % (node_name)
    tmp_if_name = if_name
    if vlan_id is not None:
        tmp_if_name = "%s.%s" % (tmp_if_name, vlan_id)
    request_content = _request_content_bind_vrf_template % (tmp_if_name, vrf_name)
    print(request_url)
    print(request_content)
    res = None
    for a in range(0,wait_times):
        try:
            res = odl_http_post(config, request_url, 'application/xml', request_content, expected_status_code=204)
            time.sleep(1)
            if res.status_code in [204]:
                break
        except Exception as e:
            print(e)
            time.sleep(1)
    return res

def clear_if(config, node_name, if_name, vlan_id=None):
    print("clear if")
    content_tmp_if_name = if_name
    tmp_if_name = if_name.replace("/", "%2F")
    if vlan_id is not None:
        tmp_if_name = "%s.%s" % (tmp_if_name, vlan_id)
        content_tmp_if_name = "%s.%s" % (content_tmp_if_name, vlan_id)

    request_url = _url_if_node % (node_name, tmp_if_name)
    if vlan_id is None:
        request_content = _request_content_clear_if_template % (content_tmp_if_name)
    else:
        request_content = _request_content_clear_vlan_if_template % (content_tmp_if_name, vlan_id)

    print(request_url)
    print(request_content)
    res = None
    for a in range(0,wait_times):
        try:
            res = odl_http_put(config, request_url, 'application/xml', request_content, expected_status_code=[200])
            time.sleep(1)
            if res.status_code in [200]:
                break
        except Exception as e:
            print(e)
            time.sleep(1)
    return res

if __name__ == "__main__":
    config = {
    'odl_server': {'address': '192.168.255.5',
                   'port': 8181,
                   'password': 'admin',
                   'username': 'admin'}}

    node_name = "iosxrv-4"
    if_name = "GigabitEthernet0/0/0/0"
    vlan_id = 100
    vrf_name = "VRF-%s" % vlan_id

    from odl.odl_vrf import create_vrf, destroy_vrf

    res = list_if(config, node_name)
    print(res.json())
    time.sleep(5)
    print()

    res = create_vrf(config, node_name, vrf_name)
    print(res)
    time.sleep(5)
    print()

    res = bind_ipv4addr(config, node_name, if_name, "10.10.0.1", "255.255.255.252")
    print(res)
    time.sleep(5)
    print()

    res = list_if(config, node_name)
    print(res.json())
    time.sleep(5)
    print()

    res = unbind_ipv4addr(config, node_name, if_name)
    print(res)
    time.sleep(5)
    print()

    res = bind_vrf(config, node_name, if_name, vrf_name)
    print(res)
    time.sleep(5)
    print()

    res = list_if(config, node_name)
    print(res.json())
    time.sleep(5)
    print()

    res = clear_if(config, node_name, if_name)
    print(res)
    time.sleep(5)
    print()

    res = list_if(config, node_name)
    print(res.json())
    time.sleep(5)
    print()

    res = create_vlan_if(config, node_name, if_name, "10.10.0.2", "255.255.255.252", vlan_id, vrf_name)
    print(res)
    time.sleep(5)
    print()

    res = bind_ipv4addr(config, node_name, if_name, "10.10.0.1", "255.255.255.252", vlan_id)
    print(res)
    time.sleep(5)
    print()

    res = list_if(config, node_name)
    print(res.json())
    time.sleep(5)
    print()

    res = unbind_ipv4addr(config, node_name, if_name, vlan_id)
    print(res)
    time.sleep(5)
    print()

    res = bind_vrf(config, node_name, if_name, vrf_name, vlan_id)
    print(res)
    time.sleep(5)
    print()

    res = list_if(config, node_name)
    print(res.json())
    time.sleep(5)
    print()

    res = clear_if(config, node_name, if_name, vlan_id)
    print(res)
    time.sleep(5)
    print()

    res = destroy_vlan_if(config, node_name, if_name, vlan_id)
    print(res)
    time.sleep(5)
    print()

    res = destroy_vrf(config, node_name, vrf_name)
    print(res)
    time.sleep(5)
    print()

    res = list_if(config, node_name)
    print(res.json())
    time.sleep(5)
    print()

