#!/usr/bin/env python3.4

''' vrf operations:
    create vrf
    destroy vrf
    add route
    delete route
'''

from __future__ import print_function as _print_function
from lxml import etree
from collections import namedtuple
from basics.odl_http import odl_http_get, odl_http_post, odl_http_put, odl_http_delete
import time

wait_times = 5

_url_inventory = 'config/opendaylight-inventory:nodes'
_url_inventory_node = _url_inventory + '/node/%s'

_url_vrf = _url_inventory_node + '/yang-ext:mount/Cisco-IOS-XR-infra-rsi-cfg:vrfs'
_url_vrf_node = _url_vrf + '/vrf/%s'

_url_route = _url_inventory_node + '/yang-ext:mount/Cisco-IOS-XR-ip-static-cfg:router-static/vrfs'
_url_route_node = _url_route + '/vrf/%s/address-family/vrfipv4/vrf-unicast/vrf-prefixes/vrf-prefix/%s/%s'

_request_content_create_vrf_template = '''<?xml version="1.0"?>
<vrf xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-infra-rsi-cfg">
<vrf-name>%s</vrf-name>
<afs>
<af>
<af-name>ipv4</af-name>
<saf-name>unicast</saf-name>
<topology-name>default</topology-name>
<create />
</af>
</afs>
<create />
</vrf>
'''

_request_content_add_route_template = '''<?xml version="1.0"?>
<vrf xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-ip-static-cfg">
<vrf-name>%s</vrf-name>
<address-family>
<vrfipv4>
<vrf-unicast>
<vrf-prefixes>
<vrf-prefix>
<prefix>%s</prefix>
<prefix-length>%s</prefix-length>
<vrf-route>
<vrf-next-hops>
<next-hop-address>
<next-hop-address>%s</next-hop-address>
</next-hop-address>
</vrf-next-hops>
</vrf-route>
</vrf-prefix>
</vrf-prefixes>
</vrf-unicast>
</vrfipv4>
</address-family>
</vrf>
'''

def add_route(config, node_name, vrf_name, dest, mask, nexthop):
    print("add route")
    request_url = _url_route % (node_name)
    request_content = _request_content_add_route_template % (vrf_name, dest, mask, nexthop)
    print(request_url)
    print(request_content)
    res = None
    for a in range(0,wait_times):
        try:
            res = odl_http_post(config, request_url, 'application/xml', request_content, expected_status_code=[204, 409])
            time.sleep(1)
            if res.status_code in [204, 409]:
                break
        except Exception as e:
            print(e)
            time.sleep(1)
    return res

def delete_route(config, node_name, vrf_name, dest, mask):
    print("delete route")
    request_url = _url_route_node %(node_name, vrf_name, dest, mask)
    print(request_url)
    res = None
    for a in range(0,wait_times):
        try:
            res = odl_http_delete(config, request_url, 'application/xml', expected_status_code=[200, 404])
            time.sleep(1)
            if res.status_code in [200, 404]:
                break
        except Exception as e:
            print(e)
            time.sleep(1)
    return res

def list_route(config, node_name):
    print("list route")
    request_url = _url_route % (node_name)
    print(request_url)
    res = None
    for a in range(0,wait_times):
        try:
            res = odl_http_get(config, request_url, 'application/json')
            time.sleep(1)
            if res.status_code in [200]:
                break
        except Exception as e:
            print(e)
            time.sleep(1)
    return res

def create_vrf(config, node_name, vrf_name):
    print("create vrf")
    request_url = _url_vrf % (node_name)
    request_content = _request_content_create_vrf_template % (vrf_name)
    print(request_url)
    print(request_content)
    res = None
    for a in range(0,wait_times):
        try:
            res = odl_http_post(config, request_url, 'application/xml', request_content, expected_status_code=[204,409])
            time.sleep(1)
            if res.status_code in [204, 409]:
                break
        except Exception as e:
            print(e)
            time.sleep(1)
    return res

def destroy_vrf(config, node_name, vrf_name):
    print("destroy vrf")
    request_url = _url_vrf_node %(node_name, vrf_name)
    print(request_url)
    res = None
    for a in range(0,wait_times):
        try:
            res = odl_http_delete(config, request_url, 'application/xml', expected_status_code=[200, 404])
            time.sleep(1)
            if res.status_code in [200, 404]:
                break
        except Exception as e:
            print(e)
            time.sleep(1)
    return res

def list_vrf(config, node_name):
    print("list vrf")
    request_url = _url_vrf % (node_name)
    print(request_url)
    res = None
    for a in range(0,wait_times):
        try:
            res = odl_http_get(config, request_url, 'application/json', expected_status_code=[200, 404])
            time.sleep(1)
            if res.status_code in [200, 404]:
                break
        except Exception as e:
            print(e)
            time.sleep(1)
    return res

if __name__ == "__main__":
    config = {
    'odl_server': {
        'address': '192.168.255.5',
        'port': 8181,
        'password': 'admin',
        'username': 'admin'
    }}

    node_name = "iosxrv-4"
    vrf_name = "VRF-102"

    res = list_vrf(config, node_name)
    print(res.json())
    time.sleep(5)
    print()

    res = list_route(config, node_name)
    print(res.json())
    time.sleep(5)
    print()

    res = create_vrf(config, node_name, vrf_name)
    print(res)
    time.sleep(5)
    print()

    res = list_vrf(config, node_name)
    print(res.json())
    time.sleep(5)
    print()

    res = add_route(config, node_name, vrf_name, "10.11.0.0", "16", "10.10.0.1")
    print(res)
    time.sleep(5)
    print()

    res = list_route(config, node_name)
    print(res.json())
    time.sleep(5)
    print()

    res = delete_route(config, node_name, vrf_name, "10.11.0.0", "16")
    print(res)
    time.sleep(5)
    print()

    res = destroy_vrf(config, node_name, vrf_name)
    print(res)
    time.sleep(5)
    print()

