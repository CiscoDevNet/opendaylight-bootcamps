#!/usr/bin/env python3.4                             
#get the topology from cdp
#calc the path from one router to another
#
import requests
import json
import logging
import topomanager_config
import time

try:
    from urllib import quote_plus
except ImportError:
    from urllib.parse import quote_plus


logger = logging.getLogger(__name__)

class Graph():
    def __init__(self, nodes = topomanager_config.config['network_device'], debug = False):
        self.nodes = nodes
        self.topology = {}
        #url for cdp request
        self.url_template = 'http://192.168.255.5:8181/restconf/operational/network-topology:network-topology/topology/topology-netconf/node/%s/yang-ext:mount/Cisco-IOS-XR-cdp-oper:cdp'
        
        #set up the log level and format
        streamformat = "%(levelname)s (%(module)s:%(lineno)d) %(message)s"
        if debug:
            logging.basicConfig(level = logging.DEBUG, format = streamformat)
        else:
            logging.basicConfig(level = logging.WARNING, format = streamformat)
        
    def get_topology(self):
        """get topology of our network by getting information from cdp"""
        for node in self.nodes:
            #get each node's neighbor
            url = self.url_template % quote_plus(node)
            
            odl_server = topomanager_config.config['odl_server']
           
            method = 'get'
            headers = {}
            headers['Accept'] = None
            headers['Content-Type'] = "application/json"

            #try 5 times every 1 second, because we always get 400 or 500 error
            for i in range(0, 5):
                response = requests.request(method, url, headers = headers, auth = (odl_server['username'], odl_server['password']))
                if response.status_code == 200:
                    break
                time.sleep(1)
            #after 5 times try, we failed to call cdp api,warning and return
            if response.status_code != 200:
                logger.warning('can not get node %s'%node)
                return {}
            
            jsonret = json.loads(response.text)
            logger.debug('response %s'%jsonret)
            neighbor = []
            #parse the return json
            for elem in jsonret['cdp']['nodes']['node'][0]['neighbors']['summaries']['summary']:
                logger.debug('elem %s'%elem)
                neighbor_elem = {}
                neighbor_elem['name'] = elem['cdp-neighbor'][0]['device-id']

                neighbor_elem['endinterface'] = elem['cdp-neighbor'][0]['port-id']
                neighbor_elem['localinterface'] = elem['cdp-neighbor'][0]['receiving-interface-name']
                neighbor.append(neighbor_elem)
                logger.debug("neighbor %s neighbor_who %s"%(neighbor,neighbor_elem))
                
            self.topology[node] = neighbor
            time.sleep(1)

        logger.debug('we got the topology %s'%self.topology)
        return self.topology

    def calc_path(self, source, dest):
        """get the path from source to dest"""
        """
        if source == "iosxrv-1" and dest == "iosxrv-4":
            path = [
            {
                'localinterface': 'GigabitEthernet0/0/0/2',
                'endinterface': 'GigabitEthernet0/0/0/1',
                'name': 'iosxrv-2'
            },
            {
                'localinterface': 'GigabitEthernet0/0/0/0',
                'endinterface': 'GigabitEthernet0/0/0/1',
                'name': 'iosxrv-4'
            }
            ]
            return path

        if source == "iosxrv-1" and dest == "iosxrv-2":
            path = [
            {
                'localinterface': 'GigabitEthernet0/0/0/2',
                'endinterface': 'GigabitEthernet0/0/0/1',
                'name': 'iosxrv-2'
            }
            ]
            return path

        if source == "iosxrv-1" and dest == "iosxrv-3":
            path = [
            {
                'localinterface': 'GigabitEthernet0/0/0/1',
                'endinterface': 'GigabitEthernet0/0/0/0',
                'name': 'iosxrv-3'
            }
            ]
            return path

        if source == "iosxrv-2" and dest == "iosxrv-1":
            path = [
            {
                'localinterface': 'GigabitEthernet0/0/0/1',
                'endinterface': 'GigabitEthernet0/0/0/2',
                'name': 'iosxrv-1'
            }
            ]
            return path


        if source == "iosxrv-2" and dest == "iosxrv-3":
            path = [
            {
                'localinterface': 'GigabitEthernet0/0/0/1',
                'endinterface': 'GigabitEthernet0/0/0/2',
                'name': 'iosxrv-1'
            },
            {
                'localinterface': 'GigabitEthernet0/0/0/1',
                'endinterface': 'GigabitEthernet0/0/0/0',
                'name': 'iosxrv-3'
            }
            ]
            return path

        if source == "iosxrv-2" and dest == "iosxrv-4":
            path = [
            {
                'localinterface': 'GigabitEthernet0/0/0/0',
                'endinterface': 'GigabitEthernet0/0/0/1',
                'name': 'iosxrv-4'
            }
            ]
            return path

        if source == "iosxrv-3" and dest == "iosxrv-1":
            path = [
            {
                'localinterface': 'GigabitEthernet0/0/0/0',
                'endinterface': 'GigabitEthernet0/0/0/1',
                'name': 'iosxrv-1'
            }
            ]
            return path

        if source == "iosxrv-3" and dest == "iosxrv-2":
            path = [
            {
                'localinterface': 'GigabitEthernet0/0/0/0',
                'endinterface': 'GigabitEthernet0/0/0/1',
                'name': 'iosxrv-1'
            },
            {
                'localinterface': 'GigabitEthernet0/0/0/2',
                'endinterface': 'GigabitEthernet0/0/0/1',
                'name': 'iosxrv-2'
            }
            ]
            return path

        if source == "iosxrv-3" and dest == "iosxrv-4":
            path = [
            {
                'localinterface': 'GigabitEthernet0/0/0/2',
                'endinterface': 'GigabitEthernet0/0/0/0',
                'name': 'iosxrv-1'
            }
            ]
            return path

        if source == "iosxrv-4" and dest == "iosxrv-1":
            path = [
            {
                'localinterface': 'GigabitEthernet0/0/0/1',
                'endinterface': 'GigabitEthernet0/0/0/0',
                'name': 'iosxrv-2'
            },
            {
                'localinterface': 'GigabitEthernet0/0/0/1',
                'endinterface': 'GigabitEthernet0/0/0/2',
                'name': 'iosxrv-1'
            }
            ]
            return path

        if source == "iosxrv-4" and dest == "iosxrv-2":
            path = [
            {
                'localinterface': 'GigabitEthernet0/0/0/1',
                'endinterface': 'GigabitEthernet0/0/0/0',
                'name': 'iosxrv-2'
            }
            ]
            return path

        if source == "iosxrv-4" and dest == "iosxrv-3":
            path = [
            {
                'localinterface': 'GigabitEthernet0/0/0/0',
                'endinterface': 'GigabitEthernet0/0/0/2',
                'name': 'iosxrv-3'
            }
            ]
            return path

        return None
        """

        for retry in range(0, 3):
            topology = self.get_topology()
            if topology is not None:
                break
        if retry == 3:
            logger.warning('kidding me ? three times error. check odl!')
            return None
        if dest not in self.nodes or source not in self.nodes:
            logger.warning('please insert valid source and dest')
            return None

        ret = []
        for neigh in self.topology[source]:
            if neigh['name'] == dest:
                ret.append(neigh)
                return ret

        queue = []
        order = []
        visited = {}

        def dfs():
            while len(queue):
                node  = queue.pop(0)
                visited[node] = True
                #import pdb; pdb.set_trace()
                if node == dest:
                    return
                for n in self.topology[node]:
                    if (not n['name'] in visited.keys() ) and (not n['name'] in queue):
                        queue.insert(0, n['name'])
                        order.append(n['name'])
                        #break

        queue.append(source)
        order.append(source)
        dfs()
        #order.remove(source)
        logger.debug('order %s, visited %s'%(order, visited.keys()))
        for node in list(set(self.nodes) - set(visited.keys())):
            order.remove(node)

        order.remove(source)
        base = self.topology[source]
        for each in order:
            for name in base:
                if name['name'] == each:
                    ret.append(name)
            base = self.topology[each]

        return ret

def main():
    test = Graph(['iosxrv-3','iosxrv-1','iosxrv-2','iosxrv-4'], False)
    #test = Graph(['iosxrv-3'], True)
    ret = test.get_topology()

    if ret:
        print('topology pass')
        print(ret)
    else:
        print("topology error")
    ret = test.calc_path('iosxrv-2', 'iosxrv-3')
    
    if ret:
        print('get path pass')
        print(ret)
    else:
        print("get path error")

if __name__ == '__main__':
    main()



