#!/usr/bin/env python3.4

from __future__ import print_function as _print_function

SUCCESS = 0

IERR = 1

USER_NOT_EXIST = 101

VROUTER_EXIST = 201
VROUTER_NOT_EXIST = 202
VROUTER_HAS_VPORT = 203
VROUTER_HAS_ROUTE = 204

ROUTE_EXIST = 301
ROUTE_NOT_EXIST = 302

VPORT_NOT_EXIST = 401
VPORT_BIND_FAILED = 402
VPORT_IS_BINDED = 403
VPORT_IS_UNBINDED = 404

VRF_ID_ALLOC_FAILED = 501

def print_error_info(num):
    print("error")

