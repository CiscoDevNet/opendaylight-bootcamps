#!/bin/bash

profile_file=`readlink -f $BASH_SOURCE`
profile_dir=`dirname $profile_file`
main_dir=`dirname $profile_dir`

export BASEPATH=$main_dir
export PYTHONPATH=$PYTHONPATH:$main_dir/src:$main_dir/libs/python
export CONFIGPATH=$main_dir/config/
export SHELLLIBPATH=$main_dir/libs/shell

