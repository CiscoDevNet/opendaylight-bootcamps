#!/bin/bash

exam_dir=`dirname $0`
cur_dir=`dirname $exam_dir`

tmp=`echo $cur_dir | cut -b 1`
if [ "$tmp" = "/" ] ; then
    main_dir=$cur_dir
else
    main_dir=`pwd`/$cur_dir
fi

sh $main_dir/client/api_direct.sh --action delete_route --user wyb2 --vrouter vrouter2 --dest 10.11.0.0 --mask 16
sh $main_dir/client/api_direct.sh --action delete_route --user wyb2 --vrouter vrouter2 --dest 10.12.0.0 --mask 16
sh $main_dir/client/api_direct.sh --action unbind_vport --user wyb2 --vrouter vrouter2 --vport vport2
sh $main_dir/client/api_direct.sh --action unbind_vport --user wyb2 --vrouter vrouter2 --vport vport3
sh $main_dir/client/api_direct.sh --action destroy_vrouter --user wyb2 --vrouter vrouter2

sh $main_dir/client/api_direct.sh --action delete_route --user wyb1 --vrouter vrouter1 --dest 10.11.0.0 --mask 16
sh $main_dir/client/api_direct.sh --action delete_route --user wyb1 --vrouter vrouter1 --dest 10.12.0.0 --mask 16
sh $main_dir/client/api_direct.sh --action unbind_vport --user wyb1 --vrouter vrouter1 --vport vport1
sh $main_dir/client/api_direct.sh --action unbind_vport --user wyb1 --vrouter vrouter1 --vport vport4
sh $main_dir/client/api_direct.sh --action destroy_vrouter --user wyb1 --vrouter vrouter1

