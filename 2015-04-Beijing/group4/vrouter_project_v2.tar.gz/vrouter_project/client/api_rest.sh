#!/bin/bash

client_dir=`dirname $0`
cur_dir=`dirname $client_dir`

tmp=`echo $cur_dir | cut -b 1`
if [ "$tmp" = "/" ] ; then
    main_dir=$cur_dir
else
    main_dir=`pwd`/$cur_dir
fi

export BASEPATH=$main_dir
export PYTHONPATH=$PYTHONPATH:$main_dir/src:$main_dir/libs/python
export CONFIGPATH=$main_dir/config/
export SHELLLIBPATH=$main_dir/libs/shell

python $BASEPATH/src/api/rest/main.py $@

